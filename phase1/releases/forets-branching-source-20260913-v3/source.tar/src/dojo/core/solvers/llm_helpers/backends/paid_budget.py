"""One USD10 campaign ledger under the user's CNY100 authorization.

Only identifiers and charges, never credentials/prompts. All unresolved requests
retain their full reservation, including cancellation, HTTP errors and crashes.
Integer nano-USD avoids floating point budget drift. No automatic reinitialize.
"""
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import time
from contextlib import closing
from decimal import Decimal, ROUND_CEILING

MODEL = 'qwen/qwen3-coder-flash'
UNIT = 10**9
RESERVE = 700000000
PROVIDER = dict(only=['alibaba'], allow_fallbacks=False, require_parameters=True,
                max_price=dict(prompt=0.65, completion=2.6, request=0))
AUTH = dict(version=1, currency='USD', total=10*UNIT, user_cny_cap=100,
            conservative_cny_per_usd=8, fee_multiplier='1.10',
            accounted_cny_ceiling='88.00', model=MODEL, provider=PROVIDER,
            reservation=RESERVE, context_tokens=1000000, output_tokens=8192,
            run_limit=1_100_000_000, route_limit=1_200_000_000,
            serial_transport_per_worker=True)
AUTH.update(version=2, total=1818775548, predecessor_cost=318775548,
    incremental_cap=1500000000, predecessor_authorization='c274cfc456296b85a8cb2b85ba9f66d28f738132462119e6fbb7f58d6c2e5c1e',
    accounted_cny_ceiling='16.0052248224', experiment='environment-context-seed10')
AUTH.update({'version': 4, 'total': 3122344104, 'incremental_cap': 2000000000, 'predecessor_authorization': '581f1c378636728df93c6502a4e45513847eed29b86de5a577309d72967f21b5', 'predecessor_accounted': 1122344104, 'predecessor_settled': 422344104, 'predecessor_calls': 55, 'predecessor_unresolved': 1, 'run_limit': 1500000000, 'experiment': 'review-type-repair-seed11', 'accounted_cny_ceiling': '27.4766281152'})
AUTH.update({'version': 5, 'total': 3274500927, 'incremental_cap': 2000000000, 'predecessor_authorization': '4bbac52d02eb1109aded9aeca4d73cd670fb7893afe5988973ace34a7204d98e', 'predecessor_accounted': 1274500927, 'predecessor_settled': 574500927, 'predecessor_calls': 117, 'predecessor_unresolved': 1, 'run_limit': 1500000000, 'route_limit': 1500000000, 'model': 'qwen/qwen3-coder-flash', 'reservation': 700000000, 'context_tokens': 1000000, 'output_tokens': 8192, 'experiment': 'future-seed12-qwen3-coder-flash', 'accounted_cny_ceiling': '28.8156081576'})
AUTH.update({'version': 7, 'total': 4942593566, 'incremental_cap': 3500000000, 'run_limit': 4000000000, 'route_limit': 4000000000, 'predecessor_authorization': '69e6d156ea7ec0f172edf3f46f432661c1da8ca0c1249301212ac59bac209fbe', 'predecessor_accounted': 1442593566, 'predecessor_settled': 742593566, 'predecessor_calls': 185, 'predecessor_unresolved': 1, 'experiment': 'contextual-judge-e2e-seed13', 'logical_request_cap': 100, 'judge_model': 'qwen/qwen3-coder-plus', 'judge_reservation': 2600000000, 'accounted_cny_ceiling': '43.4948233808'})
AUTH.update({'version': 8, 'total': 5714760245, 'incremental_cap': 3500000000, 'run_limit': 4000000000, 'route_limit': 4000000000, 'predecessor_authorization': 'f38b37f695e122d8f5df7a26fe781b80952708d8701dec22ab9dbca17ad70613', 'predecessor_accounted': 2214760245, 'predecessor_settled': 814760245, 'predecessor_calls': 214, 'predecessor_unresolved': 2, 'experiment': 'contextual-smallpool-repair-seed14', 'accounted_cny_ceiling': '50.2898901560'})
AUTH.update({'version': 9, 'total': 5907137235, 'incremental_cap': 3500000000, 'run_limit': 4000000000, 'route_limit': 4000000000, 'predecessor_authorization': 'd42e129a04210bd56c981c393d2890e0b50b1d98755027893ad3fa6c3127e93a', 'predecessor_accounted': 2407137235, 'predecessor_settled': 1007137235, 'predecessor_calls': 284, 'predecessor_unresolved': 2, 'experiment': 'contextual-same-version-seed15', 'accounted_cny_ceiling': '51.9828076680'})
AUTH.update({'version': 10, 'total': 6227324583, 'incremental_cap': 3500000000, 'predecessor_authorization': '4d66bef41f5ad23d64a8e6f26350a25486eb65bbde5c416a531879d6b48925ca', 'predecessor_accounted': 2727324583, 'predecessor_settled': 1327324583, 'predecessor_calls': 402, 'predecessor_unresolved': 2, 'experiment': 'wallclock-development-seeds22-23', 'run_limit': 4000000000, 'route_limit': 4000000000, 'accounted_cny_ceiling': '54.8004563304'})
AUTH.update({'version': 11, 'total': 7553182076, 'incremental_cap': 4500000000, 'predecessor_authorization': '2129c34aa8758e9b5e2e07e98f6b2e9864fd9e896853c07c6b6333e98d716039', 'predecessor_accounted': 3053182076, 'predecessor_settled': 1653182076, 'predecessor_calls': 504, 'predecessor_unresolved': 2, 'experiment': 'parallel-wallclock-development-seeds24-25', 'serial_transport_per_worker': False, 'max_concurrent_generator_requests': 4, 'run_limit': 4000000000, 'route_limit': 4000000000, 'accounted_cny_ceiling': '66.4680022688'})
AUTH.update({'version': 12, 'total': 10000000000, 'incremental_cap': 6399138012, 'predecessor_authorization': 'c5c17a09ef3503be91b0e2ff0fa0873c833cb884f01f5c0f5820e14a40cdb4b4', 'predecessor_accounted': 3600861988, 'predecessor_settled': 2200861988, 'predecessor_calls': 658, 'predecessor_unresolved': 2, 'experiment': 'single-vote-e2e-seeds26-27', 'accounted_cny_ceiling': '88.00', 'run_limit': 4000000000, 'route_limit': 4000000000, 'concurrent_search_workers': 2})
AUTH.update({'version': 13, 'total': 10000000000, 'incremental_cap': 5902422065, 'predecessor_authorization': '81c286978ff9ff58f79d7e9f8029aab335686a2d15158c6f2462efc035ea3279', 'predecessor_accounted': 4097577935, 'predecessor_settled': 2697577935, 'predecessor_calls': 815, 'predecessor_unresolved': 2, 'experiment': 'common-start-e2e-seeds28-29', 'accounted_cny_ceiling': '88.00', 'run_limit': 4000000000, 'route_limit': 4000000000, 'concurrent_search_workers': 2})
AUTH.update({'version': 15, 'total': 10000000000, 'incremental_cap': 5437705319, 'predecessor_authorization': 'e59bbcbff5dc6616bf8771c8172ad0ed4de6354f6a3808112353568e339b6659', 'predecessor_accounted': 4562294681, 'predecessor_settled': 3162294681, 'predecessor_calls': 985, 'predecessor_unresolved': 2, 'experiment': 'execute-two-e2e-seeds30-31', 'pre_dispatch_wait_seconds': 90})
AUTH_RAW = json.dumps(AUTH, sort_keys=True, separators=(',', ':')).encode()
AUTH_SHA = hashlib.sha256(AUTH_RAW).hexdigest()


class BudgetStopped(RuntimeError):
    pass


def initialize(path, run_ids):
    raise RuntimeError("use exact cumulative ledger handover")
    path = Path(path)
    if len(run_ids) != 4 or len(set(run_ids)) != 4 or any(x in run_ids for x in ('route', 'closed_predecessor')):
        raise ValueError('exact four fresh scopes required')
    fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    os.close(fd)
    with closing(sqlite3.connect(path)) as db, db:
        db.executescript('''
          CREATE TABLE auth (digest TEXT NOT NULL, body TEXT NOT NULL, stopped INTEGER NOT NULL);
          CREATE TABLE scopes (scope TEXT PRIMARY KEY, cap INTEGER NOT NULL);
          CREATE TABLE calls (id TEXT PRIMARY KEY, scope TEXT NOT NULL, held INTEGER NOT NULL,
            cost INTEGER, state TEXT NOT NULL, created REAL NOT NULL);
        ''')
        db.execute('INSERT INTO auth VALUES (?,?,0)', (AUTH_SHA, AUTH_RAW.decode()))
        db.execute('INSERT INTO scopes VALUES (?,?)', ('closed_predecessor', 0))
        db.execute('INSERT INTO calls VALUES (?,?,?,?,?,?)',
            ('carried-124-settled-calls', 'closed_predecessor', 318775548, 318775548, 'settled', time.time()))
        db.executemany('INSERT INTO scopes VALUES (?,?)',
                       [('route', AUTH['route_limit'])] + [(x, AUTH['run_limit']) for x in run_ids])


def connect(path):
    path = Path(path)
    if not path.is_file() or path.is_symlink():
        raise BudgetStopped('existing campaign ledger required')
    db = sqlite3.connect(path.as_uri()+'?mode=rw', uri=True, timeout=15)
    try:
        db.execute('BEGIN IMMEDIATE')
        rows = db.execute('SELECT digest,body,stopped FROM auth').fetchall()
        if len(rows) != 1 or rows[0][:2] != (AUTH_SHA, AUTH_RAW.decode()):
            raise BudgetStopped('authorization drift')
        if rows[0][2]:
            raise BudgetStopped('campaign stopped')
        return db
    except BaseException:
        db.close()
        raise


def reserve(path, scope, attempt_id, amount=None):
    from dojo.solvers.fore_ts.wallclock import admit_request
    from dojo.solvers.fore_ts.reserve_backpressure import reserve_wait
    return reserve_wait(path, scope, attempt_id, RESERVE if amount is None else amount,
        connect=connect, authorize=admit_request, auth=AUTH, stopped_error=BudgetStopped)


async def reserve_async(path, scope, attempt_id, amount=None):
    from dojo.solvers.fore_ts.wallclock import admit_request
    from dojo.solvers.fore_ts.reserve_backpressure import reserve_async as wait
    return await wait(path, scope, attempt_id, RESERVE if amount is None else amount,
        connect=connect, authorize=admit_request, auth=AUTH, stopped_error=BudgetStopped)


def settle(path, attempt_id, usage):
    """Only explicit valid total account cost frees a reservation; never estimates."""
    value = usage.get('cost') if isinstance(usage, dict) else None
    cost = None
    if type(value) in (int, float, str):
        try:
            parsed = Decimal(str(value))
            if parsed.is_finite() and parsed >= 0:
                cost = int((parsed * UNIT).to_integral_value(rounding=ROUND_CEILING))
        except (ValueError, ArithmeticError):
            pass
    db = connect(path)
    try:
        row = db.execute('SELECT held,state FROM calls WHERE id=?', (attempt_id,)).fetchone()
        if not row or row[1] != 'unresolved':
            raise BudgetStopped('unknown or duplicate settlement')
        if cost is None:
            # Keep full liability and stop, rather than charging unknown as zero.
            db.execute('UPDATE auth SET stopped=1')
        else:
            db.execute('UPDATE calls SET held=?,cost=?,state=? WHERE id=?',
                       (cost, cost, 'settled', attempt_id))
            if cost > row[0]:
                db.execute('UPDATE auth SET stopped=1')
        db.commit()
    finally:
        db.close()
    if cost is None or cost > row[0]:
        raise BudgetStopped('missing charge or price bound violation')
    return cost / UNIT


def snapshot(path):
    with closing(sqlite3.connect(Path(path).as_uri()+'?mode=ro', uri=True)) as db:
        digest, body, stopped = db.execute('SELECT digest,body,stopped FROM auth').fetchone()
        if (digest, body) != (AUTH_SHA, AUTH_RAW.decode()):
            raise BudgetStopped('authorization drift')
        rows = db.execute('SELECT scope,COUNT(*),SUM(held),SUM(COALESCE(cost,0)), '
                          'SUM(state="unresolved") FROM calls GROUP BY scope ORDER BY scope').fetchall()
    return dict(authorization_sha256=digest, stopped=bool(stopped),
                accounted_usd=sum(r[2] for r in rows)/UNIT,
                settled_usd=sum(r[3] for r in rows)/UNIT,
                unresolved=sum(r[4] for r in rows), calls=sum(r[1] for r in rows),
                scopes=[dict(scope=r[0], calls=r[1], held_usd=r[2]/UNIT,
                             settled_usd=r[3]/UNIT, unresolved=r[4]) for r in rows])
