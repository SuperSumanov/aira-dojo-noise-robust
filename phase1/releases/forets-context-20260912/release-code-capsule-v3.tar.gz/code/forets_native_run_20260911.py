"""Fixed fresh-start exploration entry; no automatic submission or task replay."""
import argparse
from contextlib import redirect_stderr, redirect_stdout
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import sys

from forets_native_context_20260911 import ROOT, release
from forets_block_runtime_20260911 import execute_block, write_once


def verify_code(directory):
    record = json.loads((directory/'code-manifest.json').read_text())
    if not re.fullmatch('[0-9a-f]{40}', record.get('commit', '')):
        raise ValueError('code commit absent')
    for relative, digest in record['files'].items():
        path = directory/relative
        if path.is_symlink() or not path.resolve().is_relative_to(directory.resolve()):
            raise ValueError('code file escapes release')
        if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise ValueError('released code changed')
    return record['commit']


def static_ready(directory, block):
    from forets_block_controller_20260911 import inspect_draft
    from forets_e2e_critic_service import SOURCE
    from forets_stage_gate import prior_compatibility
    from forets_opencl_allowlist_20260911 import IMAGE
    commit = verify_code(directory)
    raw = (directory/'forets_native_e2e_release_20260911.json').read_bytes()
    spec = release(raw)
    actual, configs = inspect_draft(ROOT, block)
    if len(configs) != 4: raise ValueError('fixed full block required')
    if spec.get('critic_kind')!='in_worker_contextual_api':
        raise ValueError('wrong selector release')
    prior_compatibility('gpu28', IMAGE)
    if (ROOT/f'block-{block}.runtime').exists():
        raise ValueError('block already attempted; no automatic resume')
    batch_key=hashlib.sha256('\n'.join(sorted(actual.run_ids)).encode()).hexdigest()[:12]
    if (ROOT/'runs'/'srun_pool'/batch_key).exists():
        raise ValueError('pool already exists; do not resume or overwrite it')
    if not os.access(directory/'bin'/'singularity', os.X_OK):
        raise ValueError('adapter wrapper is not executable')
    return raw, commit


def route(directory, block):
    from forets_paid_route_20260911 import route as paid_route
    return paid_route(directory, block)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('mode',choices=('inspect','route','execute'))
    p.add_argument('--block',type=int,choices=(1,),required=True)
    args=p.parse_args();directory=Path(__file__).resolve().parent
    os.environ.update(PYTHON_DOTENV_DISABLED='1',PYTHONDONTWRITEBYTECODE='1')
    if args.mode=='route':return route(directory,args.block)
    raw,commit=static_ready(directory,args.block)
    if args.mode=='inspect':
        print(json.dumps(dict(status='STATIC_READY_NOT_SUBMITTED',block=args.block,commit=commit,
            historical_input_template='not_applicable_contextual_api',model_calls=0,api_calls=0)))
        return 0
    if (not os.environ.get('SLURM_JOB_ID','').isdigit()
            or os.environ.get('SLURM_STEP_ID','') not in ('','batch')):
        raise RuntimeError('dedicated batch allocation required before credentials')
    from forets_stage_gate import validate_route_receipt
    validate_route_receipt(ROOT/f'block-{args.block}.route.json',ROOT/'source')
    from forets_e2e_campaign import install_process_credential
    install_process_credential()
    status=execute_block(ROOT,args.block,raw,node='gpu28',controller_commit=commit)
    print(json.dumps(status),flush=True)
    return 0 if status['status']=='completed' else 1


if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as exc:
        print(json.dumps(dict(status='STOPPED',error_type=type(exc).__name__)),flush=True)
        raise SystemExit(2)
