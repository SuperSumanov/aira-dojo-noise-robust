import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import log_loss
import lightgbm as lgb
import os

# Set random seed for reproducibility
np.random.seed(16)

# Load data
train_df = pd.read_csv('/workspace/data/train.csv')
test_df = pd.read_csv('/workspace/data/test.csv')

# Separate features and target
feature_cols = [col for col in train_df.columns if col not in ['id', 'species']]
X = train_df[feature_cols]
y = train_df['species']

# Encode labels
label_encoder = LabelEncoder()
y_encoded = label_encoder.fit_transform(y)

# Split into train and validation sets
X_train, X_val, y_train, y_val = train_test_split(X, y_encoded, test_size=0.2, random_state=16, stratify=y_encoded)

# Prepare LightGBM datasets
train_data = lgb.Dataset(X_train, label=y_train)
val_data = lgb.Dataset(X_val, label=y_val, reference=train_data)

# Define parameters
params = {
    'objective': 'multiclass',
    'num_class': len(np.unique(y_encoded)),
    'metric': 'multi_logloss',
    'boosting_type': 'gbdt',
    'num_leaves': 31,
    'learning_rate': 0.05,
    'feature_fraction': 0.9,
    'bagging_fraction': 0.8,
    'bagging_freq': 5,
    'verbose': -1,
    'random_state': 16
}

# Train model with early stopping
model = lgb.train(
    params,
    train_data,
    valid_sets=[val_data],
    callbacks=[lgb.early_stopping(stopping_rounds=50, verbose=False), lgb.log_evaluation(period=0)],
    num_boost_round=1000
)

# Predict on validation set to check performance
y_pred_val = model.predict(X_val, num_iteration=model.best_iteration)
val_logloss = log_loss(y_val, y_pred_val)
print(f'Validation Log Loss: {val_logloss}')

# Prepare test predictions
X_test = test_df[feature_cols]
test_predictions = model.predict(X_test, num_iteration=model.best_iteration)

# Create submission dataframe
submission_df = pd.DataFrame(test_predictions, columns=label_encoder.classes_)
submission_df['id'] = test_df['id']
submission_df = submission_df[['id'] + list(label_encoder.classes_)]

# Save to CSV
submission_df.to_csv('/workspace/submission.csv', index=False)
print('Submission file created successfully.')