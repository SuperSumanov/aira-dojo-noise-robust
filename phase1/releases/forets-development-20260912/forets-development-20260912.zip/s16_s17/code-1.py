# Seed setup
import numpy as np
np.random.seed(16)

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from lightgbm import LGBMClassifier
import os

# Read the data
train_data = pd.read_csv('/workspace/data/train.csv')
test_data = pd.read_csv('/workspace/data/test.csv')
sample_submission = pd.read_csv('/workspace/data/sample_submission.csv')

# Prepare features and target
feature_columns = [col for col in train_data.columns if col != 'id' and col != 'species']
X = train_data[feature_columns]
y = train_data['species']

# Encode the target variable
label_encoder = LabelEncoder()
y_encoded = label_encoder.fit_transform(y)

# Split the training data for internal validation
X_train, X_val, y_train, y_val = train_test_split(X, y_encoded, test_size=0.2, random_state=16, stratify=y_encoded)

# Prepare test features
X_test = test_data[feature_columns]

# Initialize the model
model = LGBMClassifier(
    objective='multiclass',
    num_class=len(label_encoder.classes_),
    random_state=16,
    n_estimators=500,
    learning_rate=0.05,
    max_depth=10,
    min_child_samples=10,
    subsample=0.8,
    colsample_bytree=0.8,
    verbosity=-1
)

# Fit the model with early stopping
model.fit(
    X_train, y_train,
    eval_set=[(X_val, y_val)],
    callbacks=[
        model.early_stopping(stopping_rounds=50, verbose=False),
        model.log_evaluation(period=0)
    ]
)

# Make predictions on test set
predictions_proba = model.predict_proba(X_test)

# Create submission dataframe
submission_df = pd.DataFrame(predictions_proba, columns=label_encoder.classes_)
submission_df.insert(0, 'id', test_data['id'])

# Write the submission file
submission_df.to_csv('/workspace/submission.csv', index=False)