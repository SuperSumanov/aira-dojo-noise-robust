# Spaceship Titanic Prediction
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import accuracy_score
from lightgbm import LGBMClassifier
import warnings
warnings.filterwarnings('ignore')

# Set random seed
np.random.seed(16)

# Load data
train_df = pd.read_csv('/workspace/data/train.csv')
test_df = pd.read_csv('/workspace/data/test.csv')

# Feature engineering function
def process_features(df):
    df = df.copy()
    
    # Extract deck, cabin number, and side from Cabin
    df['Deck'] = df['Cabin'].apply(lambda x: x.split('/')[0] if pd.notnull(x) else x)
    df['Side'] = df['Cabin'].apply(lambda x: x.split('/')[2] if pd.notnull(x) else x)
    df['CabinNum'] = df['Cabin'].apply(lambda x: int(x.split('/')[1]) if pd.notnull(x) else x)
    
    # Group info from PassengerId
    df['GroupId'] = df['PassengerId'].apply(lambda x: x.split('_')[0])
    df['GroupSize'] = df['GroupId'].map(df['GroupId'].value_counts())
    
    # Total spending
    luxury_cols = ['RoomService', 'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck']
    df['TotalSpending'] = df[luxury_cols].sum(axis=1)
    df['HasSpending'] = df['TotalSpending'] > 0
    
    # Age groups
    df['AgeGroup'] = pd.cut(df['Age'], bins=[0, 10, 20, 30, 40, 50, 100], labels=['Child', 'Young', 'Adult', 'Middle', 'Senior', 'Elderly'])
    
    # Fill missing values
    df['HomePlanet'].fillna(df['HomePlanet'].mode()[0], inplace=True)
    df['Destination'].fillna(df['Destination'].mode()[0], inplace=True)
    df['CryoSleep'].fillna(False, inplace=True)
    df['VIP'].fillna(False, inplace=True)
    df['Age'].fillna(df['Age'].median(), inplace=True)
    df['Deck'].fillna(df['Deck'].mode()[0], inplace=True)
    df['Side'].fillna(df['Side'].mode()[0], inplace=True)
    df['CabinNum'].fillna(df['CabinNum'].median(), inplace=True)
    
    # Fill spending columns with 0
    for col in luxury_cols:
        df[col].fillna(0, inplace=True)
    
    return df

# Process features
train_processed = process_features(train_df)
test_processed = process_features(test_df)

# Select features for modeling
feature_columns = [
    'HomePlanet', 'CryoSleep', 'Destination', 'Age', 'VIP', 'RoomService', 
    'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck', 'Deck', 'Side', 'CabinNum',
    'GroupSize', 'TotalSpending', 'HasSpending', 'AgeGroup'
]

# Prepare X and y
X = train_processed[feature_columns]
y = train_processed['Transported']

# Encode categorical variables
label_encoders = {}
categorical_columns = ['HomePlanet', 'Destination', 'Deck', 'Side', 'AgeGroup']

for col in categorical_columns:
    le = LabelEncoder()
    X[col] = le.fit_transform(X[col].astype(str))
    label_encoders[col] = le

# Apply same encoding to test set
for col in categorical_columns:
    test_processed[col] = label_encoders[col].transform(test_processed[col].astype(str))

X_test = test_processed[feature_columns]

# Split training data for validation
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=16, stratify=y)

# Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_val_scaled = scaler.transform(X_val)
X_test_scaled = scaler.transform(X_test)

# Train model
model = LGBMClassifier(
    n_estimators=1000,
    learning_rate=0.05,
    max_depth=7,
    num_leaves=31,
    subsample=0.8,
    colsample_bytree=0.8,
    random_state=16,
    verbosity=-1
)

# Fit with early stopping
model.fit(
    X_train_scaled, y_train,
    eval_set=[(X_val_scaled, y_val)],
    callbacks=[
        model.early_stopping(stopping_rounds=50, verbose=False),
        model.log_evaluation(period=0)
    ]
)

# Predictions on validation set
y_val_pred = model.predict(X_val_scaled)
val_accuracy = accuracy_score(y_val, y_val_pred)
print(f'Validation Accuracy: {val_accuracy:.4f}')

# Final predictions on test set
test_predictions = model.predict(X_test_scaled)

# Create submission file
submission = pd.DataFrame({
    'PassengerId': test_df['PassengerId'],
    'Transported': test_predictions.astype(bool)
})

submission.to_csv('/workspace/submission.csv', index=False)
print('Submission file created successfully.')