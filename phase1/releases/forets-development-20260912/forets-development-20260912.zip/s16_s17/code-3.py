import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import lightgbm as lgb
import warnings
warnings.filterwarnings('ignore')

# Set random seed
np.random.seed(16)

# Load data
train_df = pd.read_csv('/workspace/data/train.csv')
train_df['Transported'] = train_df['Transported'].astype(int)
test_df = pd.read_csv('/workspace/data/test.csv')

# Feature engineering
train_df['Group'] = train_df['PassengerId'].str.split('_').str[0]
test_df['Group'] = test_df['PassengerId'].str.split('_').str[0]

# Extract cabin features
train_df[['Cabin_deck', 'Cabin_num', 'Cabin_side']] = train_df['Cabin'].str.split('/', expand=True)
test_df[['Cabin_deck', 'Cabin_num', 'Cabin_side']] = test_df['Cabin'].str.split('/', expand=True)

# Fill missing values
train_df['Age'].fillna(train_df['Age'].median(), inplace=True)
test_df['Age'].fillna(test_df['Age'].median(), inplace=True)

# Fill categorical columns with mode
for col in ['HomePlanet', 'CryoSleep', 'Destination', 'VIP', 'Cabin_deck', 'Cabin_side']:
    if col in train_df.columns:
        mode_val = train_df[col].mode()[0] if not train_df[col].mode().empty else 'Unknown'
        train_df[col].fillna(mode_val, inplace=True)
        test_df[col].fillna(mode_val, inplace=True)

# Fill numerical columns with median
numerical_cols = ['RoomService', 'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck']
for col in numerical_cols:
    if col in train_df.columns:
        median_val = train_df[col].median()
        train_df[col].fillna(median_val, inplace=True)
        test_df[col].fillna(median_val, inplace=True)

# Create new features
train_df['TotalSpent'] = train_df[numerical_cols].sum(axis=1)
test_df['TotalSpent'] = test_df[numerical_cols].sum(axis=1)

train_df['IsAlone'] = (train_df['Group'].duplicated(keep=False) == False).astype(int)
test_df['IsAlone'] = (test_df['Group'].duplicated(keep=False) == False).astype(int)

# Select features for modeling
feature_cols = ['HomePlanet', 'CryoSleep', 'Destination', 'Age', 'VIP', 'RoomService', 
                'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck', 'TotalSpent', 'IsAlone', 
                'Cabin_deck', 'Cabin_side']

# Prepare data
X = train_df[feature_cols]
y = train_df['Transported']

# Split data for validation
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=16, stratify=y)

# Preprocessing
preprocessor = ColumnTransformer(
    transformers=[
        ('num', StandardScaler(), ['Age', 'RoomService', 'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck', 'TotalSpent']),
        ('cat', OneHotEncoder(sparse_output=False, handle_unknown='ignore'), ['HomePlanet', 'CryoSleep', 'Destination', 'VIP', 'Cabin_deck', 'Cabin_side', 'IsAlone'])
    ]
)

X_train_processed = preprocessor.fit_transform(X_train)
X_val_processed = preprocessor.transform(X_val)

# Train LightGBM model with early stopping
lgb_train = lgb.Dataset(X_train_processed, label=y_train)
lgb_val = lgb.Dataset(X_val_processed, label=y_val, reference=lgb_train)

params = {
    'objective': 'binary',
    'metric': 'binary_logloss',
    'boosting_type': 'gbdt',
    'num_leaves': 31,
    'learning_rate': 0.05,
    'feature_fraction': 0.9,
    'verbose': -1
}

model = lgb.train(
    params,
    lgb_train,
    valid_sets=[lgb_val],
    callbacks=[lgb.early_stopping(stopping_rounds=50, verbose=False), lgb.log_evaluation(period=0)],
    num_boost_round=1000
)

# Predict on validation set
y_pred_proba = model.predict(X_val_processed)
y_pred = (y_pred_proba > 0.5).astype(int)

# Calculate validation accuracy
val_accuracy = accuracy_score(y_val, y_pred)
print(f'Validation Accuracy: {val_accuracy:.4f}')

# Prepare test data
X_test = test_df[feature_cols]
X_test_processed = preprocessor.transform(X_test)

# Make predictions
test_pred_proba = model.predict(X_test_processed)
test_pred = (test_pred_proba > 0.5).astype(bool)

# Create submission
submission = pd.DataFrame({
    'PassengerId': test_df['PassengerId'],
    'Transported': test_pred
})

# Write submission file
submission.to_csv('/workspace/submission.csv', index=False)