# Seed setup
import numpy as np
np.random.seed(17)

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb

# Read data
train_df = pd.read_csv('/workspace/data/train.csv')
test_df = pd.read_csv('/workspace/data/test.csv')

# Prepare features
feature_cols = [col for col in train_df.columns if col.startswith(('margin_', 'shape_', 'texture_'))]
X = train_df[feature_cols].values
y = train_df['species'].values

# Encode target
label_encoder = LabelEncoder()
y_encoded = label_encoder.fit_transform(y)

classes = label_encoder.classes_
num_classes = len(classes)

# Split for validation
X_train, X_val, y_train, y_val = train_test_split(X, y_encoded, test_size=0.2, random_state=17, stratify=y_encoded)

# Prepare LightGBM datasets
train_data = lgb.Dataset(X_train, label=y_train)
val_data = lgb.Dataset(X_val, label=y_val, reference=train_data)

# Set parameters
params = {
    'objective': 'multiclass',
    'num_class': num_classes,
    'metric': 'multi_logloss',
    'boosting_type': 'gbdt',
    'num_leaves': 127,
    'learning_rate': 0.05,
    'feature_fraction': 0.9,
    'bagging_fraction': 0.8,
    'bagging_freq': 5,
    'verbose': -1,
    'random_state': 17
}

# Train model with early stopping
model = lgb.train(
    params,
    train_data,
    valid_sets=[val_data],
    num_boost_round=1000,
    callbacks=[
        lgb.early_stopping(stopping_rounds=50, verbose=False),
        lgb.log_evaluation(period=0)
    ]
)

# Final model training on full data
train_full = lgb.Dataset(X, label=y_encoded)
final_model = lgb.train(
    params,
    train_full,
    num_boost_round=model.best_iteration if hasattr(model, 'best_iteration') else 500
)

# Predict on test data
X_test = test_df[feature_cols].values
predictions = final_model.predict(X_test)

# Create submission DataFrame
submission_df = pd.DataFrame(predictions, columns=classes)
submission_df.insert(0, 'id', test_df['id'])

# Write submission
submission_df.to_csv('/workspace/submission.csv', index=False)