import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import log_loss
import lightgbm as lgb
import xgboost as xgb
import catboost as cb

# Set random seed
np.random.seed(17)

# Load data
train_df = pd.read_csv('/workspace/data/train.csv')
test_df = pd.read_csv('/workspace/data/test.csv')

# Prepare features and target
feature_cols = [col for col in train_df.columns if col not in ['id', 'species']]
X = train_df[feature_cols]
y = train_df['species']

# Encode labels
label_encoder = LabelEncoder()
y_encoded = label_encoder.fit_transform(y)

# Split into train and validation sets
X_train, X_val, y_train, y_val = train_test_split(X, y_encoded, test_size=0.2, random_state=17, stratify=y_encoded)

# Train LightGBM model with early stopping
lgb_train = lgb.Dataset(X_train, y_train)
lgb_val = lgb.Dataset(X_val, y_val, reference=lgb_train)

params = {
    'objective': 'multiclass',
    'num_class': len(np.unique(y_encoded)),
    'metric': 'multi_logloss',
    'boosting_type': 'gbdt',
    'num_leaves': 31,
    'learning_rate': 0.05,
    'feature_fraction': 0.9,
    'bagging_fraction': 0.8,
    'bagging_freq': 5,
    'verbose': -1,
    'random_state': 17
}

model = lgb.train(
    params,
    lgb_train,
    valid_sets=[lgb_train, lgb_val],
    valid_names=['train', 'valid'],
    num_boost_round=1000,
    callbacks=[lgb.early_stopping(stopping_rounds=50, verbose=False),
               lgb.log_evaluation(period=0)]
)

# Predict on validation set to check performance
y_pred_val = model.predict(X_val, num_iteration=model.best_iteration)
val_logloss = log_loss(y_val, y_pred_val)
print(f'Validation Log Loss: {val_logloss}')

# Prepare test predictions
X_test = test_df[feature_cols]
test_predictions = model.predict(X_test, num_iteration=model.best_iteration)

# Create submission dataframe
submission_df = test_df[['id']].copy()
for i, species in enumerate(label_encoder.classes_):
    submission_df[species] = test_predictions[:, i]

# Write submission file
submission_df.to_csv('/workspace/submission.csv', index=False)