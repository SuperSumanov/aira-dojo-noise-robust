import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import lightgbm as lgb
import warnings
warnings.filterwarnings('ignore')

# Set random seed
np.random.seed(17)

# Load data
train_df = pd.read_csv('/workspace/data/train.csv')
train_df['Transported'] = train_df['Transported'].astype(int)
test_df = pd.read_csv('/workspace/data/test.csv')

# Feature engineering
# Extract group information from PassengerId
train_df['Group'] = train_df['PassengerId'].str.split('_').str[0].astype(int)
test_df['Group'] = test_df['PassengerId'].str.split('_').str[0].astype(int)

# Create family size feature
train_df['FamilySize'] = train_df.groupby('Group')['Group'].transform('count')
test_df['FamilySize'] = test_df.groupby('Group')['Group'].transform('count')

# Cabin features
train_df[['CabinDeck', 'CabinNum', 'CabinSide']] = train_df['Cabin'].str.split('/', expand=True)
test_df[['CabinDeck', 'CabinNum', 'CabinSide']] = test_df['Cabin'].str.split('/', expand=True)

# Convert CabinNum to numeric
train_df['CabinNum'] = pd.to_numeric(train_df['CabinNum'], errors='coerce')
test_df['CabinNum'] = pd.to_numeric(test_df['CabinNum'], errors='coerce')

# Fill missing values in numeric columns
numeric_features = ['Age', 'RoomService', 'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck', 'CabinNum']
for col in numeric_features:
    if col in train_df.columns:
        train_df[col] = train_df[col].fillna(train_df[col].median())
        test_df[col] = test_df[col].fillna(test_df[col].median())

# Fill missing categorical values
categorical_features = ['HomePlanet', 'Destination', 'CabinDeck', 'CabinSide']
for col in categorical_features:
    if col in train_df.columns:
        train_df[col] = train_df[col].fillna('Unknown')
        test_df[col] = test_df[col].fillna('Unknown')

# Encode categorical variables
le_dict = {}
for col in ['HomePlanet', 'Destination', 'CabinDeck', 'CabinSide']:
    if col in train_df.columns:
        le = LabelEncoder()
        train_df[col + '_encoded'] = le.fit_transform(train_df[col])
        test_df[col + '_encoded'] = le.transform(test_df[col])
        le_dict[col] = le

# Select features for modeling
feature_columns = [
    'Age', 'RoomService', 'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck',
    'CabinNum', 'FamilySize', 'HomePlanet_encoded', 'Destination_encoded',
    'CabinDeck_encoded', 'CabinSide_encoded'
]

# Prepare data
X_train = train_df[feature_columns]
y_train = train_df['Transported']
X_test = test_df[feature_columns]

# Split training data for validation
X_train_split, X_val_split, y_train_split, y_val_split = train_test_split(
    X_train, y_train, test_size=0.2, random_state=17, stratify=y_train
)

# LightGBM model
lgb_train = lgb.Dataset(X_train_split, y_train_split)
lgb_val = lgb.Dataset(X_val_split, y_val_split, reference=lgb_train)

params = {
    'objective': 'binary',
    'metric': 'binary_logloss',
    'boosting_type': 'gbdt',
    'num_leaves': 31,
    'learning_rate': 0.05,
    'feature_fraction': 0.9,
    'bagging_fraction': 0.8,
    'bagging_freq': 5,
    'verbose': -1,
    'random_state': 17
}

model = lgb.train(
    params,
    lgb_train,
    valid_sets=[lgb_train, lgb_val],
    valid_names=['train', 'valid'],
    num_boost_round=1000,
    callbacks=[
        lgb.early_stopping(stopping_rounds=50, verbose=False),
        lgb.log_evaluation(period=0)
    ]
)

# Predict on test set
y_pred_proba = model.predict(X_test)
y_pred = (y_pred_proba > 0.5).astype(int)

# Create submission
submission = pd.DataFrame({
    'PassengerId': test_df['PassengerId'],
    'Transported': y_pred.astype(bool)
})

# Save submission
submission.to_csv('/workspace/submission.csv', index=False)