# Spaceship Titanic Prediction
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import accuracy_score
from lightgbm import LGBMClassifier
import warnings
warnings.filterwarnings('ignore')

# Set random seed
np.random.seed(17)

# Load the data
train_df = pd.read_csv('/workspace/data/train.csv')
test_df = pd.read_csv('/workspace/data/test.csv')

# Create features from existing columns
def preprocess_features(df):
    df_copy = df.copy()
    
    # Extract deck, number, side from Cabin
    df_copy[['Deck', 'Num', 'Side']] = df_copy['Cabin'].str.split('/', expand=True)
    
    # Extract group and group size from PassengerId
    df_copy['Group'] = df_copy['PassengerId'].apply(lambda x: x.split('_')[0])
    df_copy['GroupSize'] = df_copy['Group'].map(df_copy['Group'].value_counts())
    
    # Extract last name from Name
    df_copy['LastName'] = df_copy['Name'].apply(lambda x: x.split()[-1] if pd.notnull(x) else x)
    df_copy['FamilySize'] = df_copy['LastName'].map(df_copy['LastName'].value_counts())
    
    # Total spending
    luxury_cols = ['RoomService', 'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck']
    df_copy['TotalSpending'] = df_copy[luxury_cols].sum(axis=1)
    
    # Count missing expenses
    df_copy['NumMissingExpenses'] = df_copy[luxury_cols].isnull().sum(axis=1)
    
    # Fill missing values
    df_copy['HomePlanet'].fillna(df_copy['HomePlanet'].mode()[0], inplace=True)
    df_copy['Destination'].fillna(df_copy['Destination'].mode()[0], inplace=True)
    df_copy['Age'].fillna(df_copy['Age'].median(), inplace=True)
    df_copy['CryoSleep'].fillna(False, inplace=True)
    df_copy['VIP'].fillna(False, inplace=True)
    df_copy['Cabin'].fillna('Unknown/0/Unknown', inplace=True)
    df_copy['Deck'].fillna('Unknown', inplace=True)
    df_copy['Side'].fillna('Unknown', inplace=True)
    df_copy['Num'].fillna('0', inplace=True)
    df_copy['Name'].fillna('Unknown Unknown', inplace=True)
    df_copy['LastName'].fillna('Unknown', inplace=True)
    
    # Fill numeric expenses with median
    for col in luxury_cols:
        df_copy[col].fillna(df_copy[col].median(), inplace=True)
    
    return df_copy

# Preprocess both datasets
train_processed = preprocess_features(train_df)
test_processed = preprocess_features(test_df)

# Select features for modeling
features = [
    'HomePlanet', 'CryoSleep', 'Destination', 'Age', 'VIP',
    'RoomService', 'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck',
    'Deck', 'Side', 'GroupSize', 'FamilySize', 'TotalSpending', 'NumMissingExpenses'
]

# Prepare the feature matrix X and target y
X = train_processed[features].copy()
y = train_processed['Transported']

# Encode categorical variables
label_encoders = {}
categorical_columns = ['HomePlanet', 'Destination', 'Deck', 'Side']

for col in categorical_columns:
    le = LabelEncoder()
    # Fit on combined data to ensure consistent encoding
    combined_values = pd.concat([X[col], test_processed[col]]).astype(str)
    le.fit(combined_values)
    
    X[col] = le.transform(X[col].astype(str))
    label_encoders[col] = le

# Encode boolean columns
X['CryoSleep'] = X['CryoSleep'].astype(int)
X['VIP'] = X['VIP'].astype(int)

# Prepare test data
X_test = test_processed[features].copy()
for col in categorical_columns:
    X_test[col] = label_encoders[col].transform(X_test[col].astype(str))

X_test['CryoSleep'] = X_test['CryoSleep'].astype(int)
X_test['VIP'] = X_test['VIP'].astype(int)

# Standardize numerical features
scaler = StandardScaler()
numerical_columns = ['Age', 'RoomService', 'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck', 'GroupSize', 'FamilySize', 'TotalSpending', 'NumMissingExpenses']
X[numerical_columns] = scaler.fit_transform(X[numerical_columns])
X_test[numerical_columns] = scaler.transform(X_test[numerical_columns])

# Split training data for validation
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=17, stratify=y)

# Train model with early stopping
model = LGBMClassifier(
    n_estimators=1000,
    learning_rate=0.05,
    max_depth=7,
    num_leaves=63,
    min_child_samples=20,
    subsample=0.8,
    colsample_bytree=0.8,
    random_state=17,
    objective='binary'
)

# Fit with early stopping
model.fit(
    X_train, y_train,
    eval_set=[(X_val, y_val)],
    callbacks=[
        model.early_stopping(stopping_rounds=50, verbose=False),
        model.log_evaluation(period=0)
    ]
)

# Make predictions on validation set
val_predictions = model.predict(X_val)
val_accuracy = accuracy_score(y_val, val_predictions)
print(f"Validation Accuracy: {val_accuracy:.4f}")

# Final prediction on test set
final_predictions = model.predict(X_test)

# Prepare submission
submission = pd.DataFrame({
    'PassengerId': test_processed['PassengerId'],
    'Transported': final_predictions.astype(bool)
})

# Save submission file
submission.to_csv('/workspace/submission.csv', index=False)
print("Submission saved to /workspace/submission.csv")