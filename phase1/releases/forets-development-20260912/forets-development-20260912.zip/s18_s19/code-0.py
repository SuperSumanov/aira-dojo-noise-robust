import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import log_loss
import lightgbm as lgb
import xgboost as xgb
import catboost as cb

def load_and_preprocess_data():
    # Load training data
    train_df = pd.read_csv('/workspace/data/train.csv')
    test_df = pd.read_csv('/workspace/data/test.csv')
    
    # Separate features and target
    feature_columns = [col for col in train_df.columns if col not in ['id', 'species']]
    X = train_df[feature_columns]
    y = train_df['species']
    
    # Encode labels
    label_encoder = LabelEncoder()
    y_encoded = label_encoder.fit_transform(y)
    
    # Split into train and validation sets
    X_train, X_val, y_train, y_val = train_test_split(X, y_encoded, test_size=0.2, random_state=18, stratify=y_encoded)
    
    return X_train, X_val, y_train, y_val, test_df, label_encoder

def train_models(X_train, X_val, y_train, y_val):
    models = {}
    
    # LightGBM
    train_data = lgb.Dataset(X_train, label=y_train)
    val_data = lgb.Dataset(X_val, label=y_val, reference=train_data)
    
    params = {
        'objective': 'multiclass',
        'num_class': len(np.unique(y_train)),
        'metric': 'multi_logloss',
        'boosting_type': 'gbdt',
        'num_leaves': 31,
        'learning_rate': 0.05,
        'feature_fraction': 0.9,
        'bagging_fraction': 0.8,
        'bagging_freq': 5,
        'verbose': -1,
        'random_state': 18
    }
    
    model_lgb = lgb.train(
        params,
        train_data,
        valid_sets=[val_data],
        num_boost_round=1000,
        callbacks=[lgb.early_stopping(stopping_rounds=50, verbose=False),
                   lgb.log_evaluation(period=0)]
    )
    models['lightgbm'] = model_lgb
    
    # XGBoost
    model_xgb = xgb.XGBClassifier(
        n_estimators=1000,
        max_depth=6,
        learning_rate=0.05,
        random_state=18,
        verbosity=0
    )
    model_xgb.fit(X_train, y_train, 
                 eval_set=[(X_val, y_val)],
                 early_stopping_rounds=50,
                 verbose=False)
    models['xgboost'] = model_xgb
    
    # CatBoost
    model_cb = cb.CatBoostClassifier(
        iterations=1000,
        depth=6,
        learning_rate=0.05,
        random_state=18,
        verbose=False,
        loss_function='MultiClass'
    )
    model_cb.fit(X_train, y_train,
                eval_set=(X_val, y_val),
                early_stopping_rounds=50)
    models['catboost'] = model_cb
    
    return models

def predict_with_models(models, X_test, label_encoder):
    predictions = {}
    
    # Get predictions from each model
    for name, model in models.items():
        if name == 'lightgbm':
            pred = model.predict(X_test)
        elif name == 'xgboost':
            pred = model.predict_proba(X_test)
        else:  # catboost
            pred = model.predict_proba(X_test)
        
        predictions[name] = pred
    
    return predictions

def ensemble_predictions(predictions):
    # Simple averaging of predictions
    ensemble_pred = np.mean(list(predictions.values()), axis=0)
    return ensemble_pred

# Main execution
if __name__ == "__main__":
    # Set random seed for reproducibility
    np.random.seed(18)
    
    # Load and preprocess data
    X_train, X_val, y_train, y_val, test_df, label_encoder = load_and_preprocess_data()
    
    # Train models
    models = train_models(X_train, X_val, y_train, y_val)
    
    # Make predictions on test set
    feature_columns = [col for col in test_df.columns if col != 'id']
    X_test = test_df[feature_columns]
    
    predictions = predict_with_models(models, X_test, label_encoder)
    
    # Ensemble predictions
    final_predictions = ensemble_predictions(predictions)
    
    # Create submission file
    species_names = label_encoder.classes_
    submission_df = pd.DataFrame(final_predictions, columns=species_names)
    submission_df.insert(0, 'id', test_df['id'])
    
    # Save to submission.csv
    submission_df.to_csv('/workspace/submission.csv', index=False)