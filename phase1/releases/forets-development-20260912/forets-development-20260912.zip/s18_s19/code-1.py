# Seed setup
import numpy as np
np.random.seed(18)

# Load libraries
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import log_loss
import lightgbm as lgb

# Read the data
train_df = pd.read_csv('/workspace/data/train.csv')
test_df = pd.read_csv('/workspace/data/test.csv')
sample_submission = pd.read_csv('/workspace/data/sample_submission.csv')

# Separate features and target
feature_cols = [col for col in train_df.columns if col != 'id' and col != 'species']
X = train_df[feature_cols]
y = train_df['species']
X_test = test_df[feature_cols]

test_ids = test_df['id']

# Encode target variable
label_encoder = LabelEncoder()
y_encoded = label_encoder.fit_transform(y)
n_classes = len(label_encoder.classes_)

# Split training data for validation
X_train, X_val, y_train, y_val = train_test_split(X, y_encoded, test_size=0.2, random_state=18, stratify=y_encoded)

# Prepare datasets
train_data = lgb.Dataset(X_train, label=y_train)
val_data = lgb.Dataset(X_val, label=y_val, reference=train_data)

# Parameters for multiclass classification
params = {
    'objective': 'multiclass',
    'num_class': n_classes,
    'metric': 'multi_logloss',
    'boosting_type': 'gbdt',
    'num_leaves': 100,
    'learning_rate': 0.1,
    'feature_fraction': 0.8,
    'bagging_fraction': 0.8,
    'bagging_freq': 5,
    'verbose': -1,
    'random_state': 18
}

# Train with early stopping
model = lgb.train(
    params,
    train_data,
    valid_sets=[train_data, val_data],
    callbacks=[lgb.early_stopping(stopping_rounds=50, verbose=False),
               lgb.log_evaluation(period=0)],
    num_boost_round=1000
)

# Predict on test set
predictions_proba = model.predict(X_test)

# Create submission dataframe
submission_df = pd.DataFrame(predictions_proba, columns=label_encoder.classes_)
submission_df.insert(0, 'id', test_ids)

# Write submission
submission_df.to_csv('/workspace/submission.csv', index=False)