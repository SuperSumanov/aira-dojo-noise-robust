# Import necessary libraries
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import accuracy_score
import lightgbm as lgb
import warnings
warnings.filterwarnings('ignore')

# Set random seed
np.random.seed(18)

# Read the data
train_df = pd.read_csv('/workspace/data/train.csv')
test_df = pd.read_csv('/workspace/data/test.csv')

# Feature engineering function
def preprocess_data(df):
    # Create copies
    df = df.copy()
    
    # Extract components from PassengerId
    df['Group'] = df['PassengerId'].apply(lambda x: int(x.split('_')[0]))
    df['GroupSize'] = df['PassengerId'].groupby(df['PassengerId'].str.split('_').str[0]).transform('count')
    
    # Extract cabin features
    df[['CabinDeck', 'CabinNum', 'CabinSide']] = df['Cabin'].str.split('/', expand=True)
    df['CabinNum'] = pd.to_numeric(df['CabinNum'], errors='coerce')
    
    # Handle missing values
    for col in ['HomePlanet', 'CryoSleep', 'Destination', 'VIP', 'CabinDeck', 'CabinSide']:
        if col in df.columns:
            if df[col].dtype == 'bool':
                df[col] = df[col].fillna(False)
            else:
                df[col] = df[col].fillna(df[col].mode()[0] if len(df[col].mode()) > 0 else 'Unknown')
    
    # Fill numeric columns with median
    numeric_cols = ['Age', 'RoomService', 'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck', 'CabinNum']
    for col in numeric_cols:
        if col in df.columns:
            df[col] = df[col].fillna(df[col].median())
    
    # Create total spending feature
    df['TotalSpending'] = df[['RoomService', 'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck']].sum(axis=1)
    
    # Drop original Cabin and Name columns
    df = df.drop(['Cabin', 'Name'], axis=1)
    
    return df

# Preprocess both train and test data
train_processed = preprocess_data(train_df)
test_processed = preprocess_data(test_df)

# Identify categorical and numerical columns
features_to_encode = ['HomePlanet', 'CryoSleep', 'Destination', 'VIP', 'CabinDeck', 'CabinSide']
numerical_features = ['Age', 'RoomService', 'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck', 'CabinNum', 'Group', 'GroupSize', 'TotalSpending']

categorical_features = []
for col in features_to_encode:
    if col in train_processed.columns:
        categorical_features.append(col)

# Encode categorical variables
all_encoded = pd.concat([train_processed[categorical_features], test_processed[categorical_features]], axis=0)
encoded_dfs = []

for col in categorical_features:
    le = LabelEncoder()
    all_encoded[col] = le.fit_transform(all_encoded[col].astype(str))
    
    # Split back to train and test
    train_processed[col] = all_encoded.iloc[:len(train_processed)][col]
    test_processed[col] = all_encoded.iloc[len(train_processed):][col]

# Prepare features and target
feature_columns = numerical_features + categorical_features
X = train_processed[feature_columns]
y = train_processed['Transported'].astype(int)

X_test = test_processed[feature_columns]

# Split training data for validation
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=18, stratify=y)

# Create LightGBM datasets
train_dataset = lgb.Dataset(X_train, label=y_train)
val_dataset = lgb.Dataset(X_val, label=y_val, reference=train_dataset)

# Define parameters
params = {
    'objective': 'binary',
    'metric': 'binary_logloss',
    'boosting_type': 'gbdt',
    'num_leaves': 31,
    'learning_rate': 0.05,
    'feature_fraction': 0.9,
    'bagging_fraction': 0.8,
    'bagging_freq': 5,
    'verbose': -1,
    'random_state': 18
}

# Train the model with early stopping
model = lgb.train(
    params,
    train_dataset,
    valid_sets=[train_dataset, val_dataset],
    callbacks=[lgb.early_stopping(stopping_rounds=50, verbose=False),
               lgb.log_evaluation(period=0)],
    num_boost_round=1000
)

# Make predictions on validation set
y_val_pred = model.predict(X_val, num_iteration=model.best_iteration)
y_val_pred_binary = (y_val_pred > 0.5).astype(int)

# Calculate validation accuracy
val_accuracy = accuracy_score(y_val, y_val_pred_binary)
print(f'Validation Accuracy: {val_accuracy:.4f}')

# Retrain on full dataset for final prediction
full_train_dataset = lgb.Dataset(X, label=y)
final_model = lgb.train(
    params,
    full_train_dataset,
    num_boost_round=model.best_iteration
)

# Final predictions on test set
test_predictions = final_model.predict(X_test)
test_predictions_binary = (test_predictions > 0.5).astype(bool)

# Create submission file
submission = pd.DataFrame({
    'PassengerId': test_df['PassengerId'],
    'Transported': test_predictions_binary
})

# Save to the required path
submission.to_csv('/workspace/submission.csv', index=False)
print('Submission saved successfully.')