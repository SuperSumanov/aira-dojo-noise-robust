import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import lightgbm as lgb
import warnings
warnings.filterwarnings('ignore')

# Set random seed
np.random.seed(18)

# Load data
train_df = pd.read_csv('/workspace/data/train.csv')
train_df['Transported'] = train_df['Transported'].astype(int)
test_df = pd.read_csv('/workspace/data/test.csv')

# Feature engineering
# Extract group information from PassengerId
train_df['Group'] = train_df['PassengerId'].str.split('_').str[0].astype(int)
test_df['Group'] = test_df['PassengerId'].str.split('_').str[0].astype(int)

# Extract deck, num, side from Cabin
train_df[['Deck', 'Num', 'Side']] = train_df['Cabin'].str.split('/', expand=True)
test_df[['Deck', 'Num', 'Side']] = test_df['Cabin'].str.split('/', expand=True)

# Fill missing values
train_df['Age'].fillna(train_df['Age'].median(), inplace=True)
test_df['Age'].fillna(test_df['Age'].median(), inplace=True)

train_df['RoomService'].fillna(0, inplace=True)
test_df['RoomService'].fillna(0, inplace=True)
train_df['FoodCourt'].fillna(0, inplace=True)
test_df['FoodCourt'].fillna(0, inplace=True)
train_df['ShoppingMall'].fillna(0, inplace=True)
test_df['ShoppingMall'].fillna(0, inplace=True)
train_df['Spa'].fillna(0, inplace=True)
test_df['Spa'].fillna(0, inplace=True)
train_df['VRDeck'].fillna(0, inplace=True)
test_df['VRDeck'].fillna(0, inplace=True)

# Create additional features
train_df['TotalSpent'] = train_df['RoomService'] + train_df['FoodCourt'] + train_df['ShoppingMall'] + train_df['Spa'] + train_df['VRDeck']
test_df['TotalSpent'] = test_df['RoomService'] + test_df['FoodCourt'] + test_df['ShoppingMall'] + test_df['Spa'] + test_df['VRDeck']

train_df['IsAlone'] = (train_df['Group'].value_counts().loc[train_df['Group']].values == 1).astype(int)
test_df['IsAlone'] = (test_df['Group'].value_counts().loc[test_df['Group']].values == 1).astype(int)

# Select features
feature_columns = ['HomePlanet', 'CryoSleep', 'Destination', 'Age', 'VIP', 'RoomService', 'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck', 'TotalSpent', 'IsAlone', 'Deck', 'Side']

# Prepare data
X_train = train_df[feature_columns]
y_train = train_df['Transported']
X_test = test_df[feature_columns]

# Preprocessing
numeric_features = ['Age', 'RoomService', 'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck', 'TotalSpent', 'IsAlone']
categorical_features = ['HomePlanet', 'CryoSleep', 'Destination', 'Deck', 'Side']

preprocessor = ColumnTransformer(
    transformers=[
        ('num', StandardScaler(), numeric_features),
        ('cat', OneHotEncoder(sparse_output=False, handle_unknown='ignore'), categorical_features)
    ]
)

X_train_processed = preprocessor.fit_transform(X_train)
X_test_processed = preprocessor.transform(X_test)

# Split training data for validation
X_train_final, X_val, y_train_final, y_val = train_test_split(X_train_processed, y_train, test_size=0.2, random_state=18, stratify=y_train)

# Train LightGBM model with early stopping
lgb_train = lgb.Dataset(X_train_final, y_train_final)
lgb_val = lgb.Dataset(X_val, y_val, reference=lgb_train)

params = {
    'objective': 'binary',
    'metric': 'binary_logloss',
    'boosting_type': 'gbdt',
    'num_leaves': 31,
    'learning_rate': 0.05,
    'feature_fraction': 0.9,
    'bagging_fraction': 0.8,
    'bagging_freq': 5,
    'verbose': -1,
    'random_state': 18
}

model = lgb.train(
    params,
    lgb_train,
    valid_sets=[lgb_train, lgb_val],
    valid_names=['train', 'valid'],
    num_boost_round=1000,
    callbacks=[lgb.early_stopping(stopping_rounds=50, verbose=False), lgb.log_evaluation(period=0)]
)

# Make predictions on validation set to check performance
y_pred_proba = model.predict(X_val)
y_pred = (y_pred_proba > 0.5).astype(int)
val_accuracy = accuracy_score(y_val, y_pred)
print(f'Validation Accuracy: {val_accuracy:.4f}')

# Final model training on full training data
final_model = lgb.train(
    params,
    lgb_train,
    num_boost_round=model.best_iteration
)

# Predict on test set
y_test_pred_proba = final_model.predict(X_test_processed)
y_test_pred = (y_test_pred_proba > 0.5).astype(bool)

# Create submission
submission = pd.DataFrame({
    'PassengerId': test_df['PassengerId'],
    'Transported': y_test_pred
})

# Save submission
submission.to_csv('/workspace/submission.csv', index=False)