# Seed for reproducibility
import numpy as np
np.random.seed(19)

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb

# Read the data
train_df = pd.read_csv('/workspace/data/train.csv')
test_df = pd.read_csv('/workspace/data/test.csv')
sample_submission = pd.read_csv('/workspace/data/sample_submission.csv')

# Separate features and target
feature_columns = [col for col in train_df.columns if col != 'id' and col != 'species']
X = train_df[feature_columns]
y = train_df['species']

# Encode the target variable
label_encoder = LabelEncoder()
y_encoded = label_encoder.fit_transform(y)

# Create train/validation split
X_train, X_val, y_train, y_val = train_test_split(X, y_encoded, test_size=0.2, random_state=19, stratify=y_encoded)

# Prepare data for LightGBM
train_data = lgb.Dataset(X_train, label=y_train)
val_data = lgb.Dataset(X_val, label=y_val, reference=train_data)

# Set parameters for multiclass classification
params = {
    'objective': 'multiclass',
    'num_class': len(label_encoder.classes_),
    'metric': 'multi_logloss',
    'boosting_type': 'gbdt',
    'num_leaves': 100,
    'learning_rate': 0.05,
    'feature_fraction': 0.8,
    'bagging_fraction': 0.8,
    'bagging_freq': 5,
    'verbose': -1,
    'random_state': 19
}

# Train the model with early stopping
model = lgb.train(
    params,
    train_data,
    valid_sets=[val_data],
    callbacks=[lgb.early_stopping(stopping_rounds=50, verbose=False), lgb.log_evaluation(period=0)]
)

# Make predictions on test data
X_test = test_df[feature_columns]
preds = model.predict(X_test)

# Create submission dataframe
submission = pd.DataFrame(preds, columns=label_encoder.classes_)
submission.insert(0, 'id', test_df['id'])

# Write to submission.csv
submission.to_csv('/workspace/submission.csv', index=False)