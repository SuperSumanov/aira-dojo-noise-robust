import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import lightgbm as lgb
import warnings
warnings.filterwarnings('ignore')

# Set random seed
np.random.seed(19)

# Load data
train_df = pd.read_csv('/workspace/data/train.csv')
submission_df = pd.read_csv('/workspace/data/test.csv')

# Feature engineering
# Extract group information from PassengerId
train_df['Group'] = train_df['PassengerId'].str.split('_').str[0]
submission_df['Group'] = submission_df['PassengerId'].str.split('_').str[0]

# Extract deck, num, side from Cabin
train_df[['Deck', 'Num', 'Side']] = train_df['Cabin'].str.split('/', expand=True)
submission_df[['Deck', 'Num', 'Side']] = submission_df['Cabin'].str.split('/', expand=True)

# Fill missing values
train_df.fillna(0, inplace=True)
submission_df.fillna(0, inplace=True)

# Convert categorical variables to numeric
encoder = OneHotEncoder(sparse_output=False, handle_unknown='ignore')

# Select features
features = ['HomePlanet', 'CryoSleep', 'Destination', 'Age', 'VIP', 'RoomService', 
           'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck', 'Deck', 'Side', 'Group']

# Prepare data
X_train = train_df[features].copy()
y_train = train_df['Transported'].copy()
X_test = submission_df[features].copy()

# Encode categorical variables
X_train_encoded = encoder.fit_transform(X_train)
X_test_encoded = encoder.transform(X_test)

# Train model with LightGBM
params = {
    'objective': 'binary',
    'metric': 'binary_logloss',
    'boosting_type': 'gbdt',
    'num_leaves': 31,
    'learning_rate': 0.05,
    'feature_fraction': 0.9,
    'verbosity': -1,
    'random_state': 19
}

# Create dataset for LightGBM
train_data = lgb.Dataset(X_train_encoded, label=y_train)

# Train model
model = lgb.train(params, train_data, num_boost_round=1000, 
                  callbacks=[lgb.early_stopping(stopping_rounds=50, verbose=False), 
                            lgb.log_evaluation(period=0)])

# Predict
predictions = model.predict(X_test_encoded)

# Convert probabilities to binary predictions
final_predictions = (predictions > 0.5).astype(bool)

# Create submission file
submission = pd.DataFrame({
    'PassengerId': submission_df['PassengerId'],
    'Transported': final_predictions
})

# Save to CSV
submission.to_csv('/workspace/submission.csv', index=False)