# Spaceship Titanic Prediction
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import accuracy_score
from lightgbm import LGBMClassifier
import warnings
warnings.filterwarnings('ignore')

# Set random seed
np.random.seed(19)

# Load data
train_df = pd.read_csv('/workspace/data/train.csv')
test_df = pd.read_csv('/workspace/data/test.csv')

# Feature engineering function
def preprocess_data(df):
    df = df.copy()
    
    # Extract features from PassengerId
    df['Group'] = df['PassengerId'].apply(lambda x: int(x.split('_')[0]))
    df['GroupSize'] = df['PassengerId'].map(df['PassengerId'].str.split('_').str[0].value_counts())
    
    # Extract cabin features
    df[['CabinDeck', 'CabinNum', 'CabinSide']] = pd.DataFrame(
        df['Cabin'].str.split('/', expand=True).values,
        columns=['CabinDeck', 'CabinNum', 'CabinSide']
    )
    df['CabinNum'] = pd.to_numeric(df['CabinNum'], errors='coerce')
    
    # Extract name features
    df['LastName'] = df['Name'].str.split().str[-1] if 'Name' in df.columns else None
    df['FamilySize'] = df.groupby('LastName')['LastName'].transform('count') if 'LastName' in df.columns else 1
    df['IsAlone'] = (df['FamilySize'] == 1).astype(int)
    
    # Handle missing values
    categorical_features = ['HomePlanet', 'CryoSleep', 'Destination', 'VIP', 'CabinDeck', 'CabinSide']
    for col in categorical_features:
        if col in df.columns:
            df[col] = df[col].fillna(df[col].mode()[0] if len(df[col].mode()) > 0 else 'Unknown')
    
    numerical_features = ['Age', 'RoomService', 'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck', 'CabinNum']
    for col in numerical_features:
        if col in df.columns:
            df[col] = df[col].fillna(df[col].median())
    
    # Create additional features
    df['TotalSpent'] = df[['RoomService', 'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck']].sum(axis=1)
    df['HasSpent'] = (df['TotalSpent'] > 0).astype(int)
    
    # Encode categorical variables
    label_encoders = {}
    for col in categorical_features:
        if col in df.columns:
            le = LabelEncoder()
            df[col] = le.fit_transform(df[col].astype(str))
            label_encoders[col] = le
    
    return df

# Preprocess training and test data
train_processed = preprocess_data(train_df)
test_processed = preprocess_data(test_df)

# Select features for modeling
feature_columns = [
    'HomePlanet', 'CryoSleep', 'Destination', 'Age', 'VIP', 'RoomService',
    'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck', 'GroupSize', 'CabinDeck',
    'CabinNum', 'CabinSide', 'FamilySize', 'IsAlone', 'TotalSpent', 'HasSpent'
]

X = train_processed[feature_columns]
y = train_processed['Transported']
X_test = test_processed[feature_columns]

# Split training data for validation
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=19, stratify=y)

# Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_val_scaled = scaler.transform(X_val)
X_test_scaled = scaler.transform(X_test)

# Train model
model = LGBMClassifier(
    n_estimators=300,
    learning_rate=0.1,
    max_depth=6,
    num_leaves=63,
    min_child_samples=20,
    subsample=0.8,
    colsample_bytree=0.8,
    random_state=19,
    verbose=-1
)

# Fit the model
model.fit(
    X_train_scaled, y_train,
    eval_set=[(X_val_scaled, y_val)],
    callbacks=[
        # Using early stopping with validation set
        # Note: Early stopping callback might not be available in some versions
    ],
    verbose=-1
)

# Predict on validation set
y_pred_val = model.predict(X_val_scaled)
val_accuracy = accuracy_score(y_val, y_pred_val)
print(f"Validation Accuracy: {val_accuracy:.4f}")

# Predict on test set
y_pred_test = model.predict(X_test_scaled)

# Prepare submission
submission = pd.DataFrame({
    'PassengerId': test_df['PassengerId'],
    'Transported': y_pred_test.astype(bool)
})

# Save submission
submission.to_csv('/workspace/submission.csv', index=False)
print("Submission saved successfully!")