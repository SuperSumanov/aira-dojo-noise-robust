# Import necessary libraries
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import log_loss
import lightgbm as lgb
import os

# Set random seed for reproducibility
np.random.seed(20)

# Load the data
train_df = pd.read_csv('/workspace/data/train.csv')
test_df = pd.read_csv('/workspace/data/test.csv')
sample_submission = pd.read_csv('/workspace/data/sample_submission.csv')

# Prepare features and target
feature_columns = [col for col in train_df.columns if col not in ['id', 'species']]
X = train_df[feature_columns]
y = train_df['species']

# Encode the target variable
label_encoder = LabelEncoder()
y_encoded = label_encoder.fit_transform(y)
n_classes = len(label_encoder.classes_)

# Split the data for validation
X_train, X_val, y_train, y_val = train_test_split(X, y_encoded, test_size=0.2, random_state=20, stratify=y_encoded)

# Prepare test features
X_test = test_df[feature_columns]

# Create LightGBM datasets
train_data = lgb.Dataset(X_train, label=y_train)
val_data = lgb.Dataset(X_val, label=y_val, reference=train_data)

# Define parameters for multiclass classification
params = {
    'objective': 'multiclass',
    'num_class': n_classes,
    'metric': 'multi_logloss',
    'boosting_type': 'gbdt',
    'num_leaves': 100,
    'learning_rate': 0.1,
    'feature_fraction': 0.9,
    'bagging_fraction': 0.8,
    'bagging_freq': 5,
    'verbose': -1,
    'random_state': 20
}

# Train the model with early stopping
model = lgb.train(
    params,
    train_data,
    valid_sets=[train_data, val_data],
    num_boost_round=1000,
    callbacks=[lgb.early_stopping(stopping_rounds=50, verbose=False),
               lgb.log_evaluation(period=0)],
)

# Make predictions on validation set to check performance
val_pred_proba = model.predict(X_val)
val_logloss = log_loss(y_val, val_pred_proba)
print(f"Validation Log Loss: {val_logloss}")

# Train the final model on the entire training set
full_train_data = lgb.Dataset(X, label=y_encoded)
final_model = lgb.train(
    params,
    full_train_data,
    num_boost_round=model.best_iteration if hasattr(model, 'best_iteration') else 100,
    valid_sets=[],
    callbacks=[lgb.log_evaluation(period=0)]
)

# Make predictions on test set
test_pred_proba = final_model.predict(X_test)

# Create submission dataframe
submission_df = pd.DataFrame(test_pred_proba, columns=label_encoder.classes_)
submission_df.insert(0, 'id', test_df['id'])

# Write submission to file
submission_df.to_csv('/workspace/submission.csv', index=False)

print("Submission file created successfully!")