# Import necessary libraries
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import accuracy_score
import lightgbm as lgb
import warnings
warnings.filterwarnings('ignore')

# Set random seed
np.random.seed(20)

# Read the data
train_df = pd.read_csv('/workspace/data/train.csv')
test_df = pd.read_csv('/workspace/data/test.csv')

# Feature engineering function
def preprocess_data(df):
    # Create copies to avoid modifying original
    df = df.copy()
    
    # Extract features from PassengerId
    df['Group'] = df['PassengerId'].apply(lambda x: int(x.split('_')[0]))
    df['GroupSize'] = df['PassengerId'].groupby(df['PassengerId'].str.split('_').str[0]).transform('count')
    
    # Extract cabin features
    df[['Deck', 'Num', 'Side']] = pd.DataFrame(
        df['Cabin'].str.split('/', expand=True).values,
        columns=['Deck', 'Num', 'Side']
    )
    df['Num'] = pd.to_numeric(df['Num'], errors='coerce')
    
    # Handle missing values
    categorical_features = ['HomePlanet', 'CryoSleep', 'Destination', 'VIP', 'Deck', 'Side']
    numerical_features = ['Age', 'RoomService', 'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck', 'Num']
    
    for col in categorical_features:
        df[col] = df[col].fillna(df[col].mode()[0] if not df[col].mode().empty else 'Unknown')
    
    for col in numerical_features:
        df[col] = df[col].fillna(df[col].median())
    
    # Encode categorical variables
    le_dict = {}
    for col in categorical_features:
        le = LabelEncoder()
        df[col] = le.fit_transform(df[col].astype(str))
        le_dict[col] = le
    
    # Create additional features
    df['TotalSpending'] = df['RoomService'] + df['FoodCourt'] + df['ShoppingMall'] + df['Spa'] + df['VRDeck']
    df['HasSpending'] = (df['TotalSpending'] > 0).astype(int)
    
    return df

# Preprocess both train and test data
train_processed = preprocess_data(train_df)
test_processed = preprocess_data(test_df)

# Select features for modeling
feature_columns = [col for col in train_processed.columns if col not in ['PassengerId', 'Name', 'Cabin', 'Transported', 'Group']]
X = train_processed[feature_columns]
y = train_processed['Transported'].astype(int)

# Split training data for validation
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=20, stratify=y)

# Prepare datasets for LightGBM
train_dataset = lgb.Dataset(X_train, label=y_train)
val_dataset = lgb.Dataset(X_val, label=y_val, reference=train_dataset)

# Define parameters
params = {
    'objective': 'binary',
    'metric': 'binary_logloss',
    'boosting_type': 'gbdt',
    'num_leaves': 31,
    'learning_rate': 0.05,
    'feature_fraction': 0.9,
    'bagging_fraction': 0.8,
    'bagging_freq': 5,
    'verbose': -1,
    'random_state': 20
}

# Train the model with early stopping
model = lgb.train(
    params,
    train_dataset,
    valid_sets=[val_dataset],
    num_boost_round=1000,
    callbacks=[
        lgb.early_stopping(stopping_rounds=50, verbose=False),
        lgb.log_evaluation(period=0)
    ]
)

# Make predictions on validation set to check performance
val_pred = model.predict(X_val)
val_pred_binary = (val_pred > 0.5).astype(int)
val_accuracy = accuracy_score(y_val, val_pred_binary)
print(f'Validation Accuracy: {val_accuracy:.4f}')

# Train final model on entire dataset
full_train_dataset = lgb.Dataset(X, label=y)
final_model = lgb.train(
    params,
    full_train_dataset,
    num_boost_round=model.best_iteration if hasattr(model, 'best_iteration') else 200,
    verbose_eval=False
)

# Prepare test data
X_test = test_processed[feature_columns]

# Make predictions on test set
test_predictions = final_model.predict(X_test)
test_predictions_binary = (test_predictions > 0.5).astype(bool)

# Create submission dataframe
submission_df = pd.DataFrame({
    'PassengerId': test_df['PassengerId'],
    'Transported': test_predictions_binary
})

# Save submission
submission_df.to_csv('/workspace/submission.csv', index=False)
print("Submission saved successfully!")