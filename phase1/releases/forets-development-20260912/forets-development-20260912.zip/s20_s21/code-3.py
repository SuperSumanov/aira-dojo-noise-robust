import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import lightgbm as lgb
import warnings
warnings.filterwarnings('ignore')

# Set random seed
np.random.seed(20)

# Load data
train_df = pd.read_csv('/workspace/data/train.csv')
train_df['Transported'] = train_df['Transported'].astype(int)
test_df = pd.read_csv('/workspace/data/test.csv')

# Feature engineering
train_df['Group'] = train_df['PassengerId'].str.split('_').str[0]
test_df['Group'] = test_df['PassengerId'].str.split('_').str[0]

# Extract cabin features
train_df[['Cabin_deck', 'Cabin_num', 'Cabin_side']] = train_df['Cabin'].str.split('/', expand=True)
test_df[['Cabin_deck', 'Cabin_num', 'Cabin_side']] = test_df['Cabin'].str.split('/', expand=True)

# Fill missing values
train_df['Age'].fillna(train_df['Age'].median(), inplace=True)
test_df['Age'].fillna(test_df['Age'].median(), inplace=True)

train_df['RoomService'].fillna(0, inplace=True)
test_df['RoomService'].fillna(0, inplace=True)
train_df['FoodCourt'].fillna(0, inplace=True)
test_df['FoodCourt'].fillna(0, inplace=True)
train_df['ShoppingMall'].fillna(0, inplace=True)
test_df['ShoppingMall'].fillna(0, inplace=True)
train_df['Spa'].fillna(0, inplace=True)
test_df['Spa'].fillna(0, inplace=True)
train_df['VRDeck'].fillna(0, inplace=True)
test_df['VRDeck'].fillna(0, inplace=True)

# Create total spending feature
train_df['TotalSpending'] = train_df['RoomService'] + train_df['FoodCourt'] + train_df['ShoppingMall'] + train_df['Spa'] + train_df['VRDeck']
test_df['TotalSpending'] = test_df['RoomService'] + test_df['FoodCourt'] + test_df['ShoppingMall'] + test_df['Spa'] + test_df['VRDeck']

# Create family size feature
train_df['FamilySize'] = train_df.groupby('Group')['Group'].transform('count')
test_df['FamilySize'] = test_df.groupby('Group')['Group'].transform('count')

# Drop unnecessary columns
features_to_drop = ['PassengerId', 'Cabin', 'Name', 'Cabin_num']
train_df.drop(columns=features_to_drop, inplace=True)
test_df.drop(columns=features_to_drop, inplace=True)

# Define categorical and numerical columns
categorical_features = ['HomePlanet', 'CryoSleep', 'Destination', 'VIP', 'Cabin_deck', 'Cabin_side']
numerical_features = ['Age', 'RoomService', 'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck', 'TotalSpending', 'FamilySize']

# Preprocessing
preprocessor = ColumnTransformer(
    transformers=[
        ('num', StandardScaler(), numerical_features),
        ('cat', OneHotEncoder(drop='first', sparse_output=False), categorical_features)
    ]
)

# Prepare data
X = train_df.drop('Transported', axis=1)
y = train_df['Transported']

X_test = test_df

# Split data
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=20, stratify=y)

# Transform data
X_train_processed = preprocessor.fit_transform(X_train)
X_val_processed = preprocessor.transform(X_val)
X_test_processed = preprocessor.transform(X_test)

# Train LightGBM model with early stopping
train_data = lgb.Dataset(X_train_processed, label=y_train)
val_data = lgb.Dataset(X_val_processed, label=y_val, reference=train_data)

params = {
    'objective': 'binary',
    'metric': 'binary_logloss',
    'boosting_type': 'gbdt',
    'num_leaves': 31,
    'learning_rate': 0.05,
    'feature_fraction': 0.9,
    'bagging_fraction': 0.8,
    'bagging_freq': 5,
    'verbose': -1,
    'random_state': 20
}

model = lgb.train(
    params,
    train_data,
    valid_sets=[val_data],
    num_boost_round=1000,
    callbacks=[lgb.early_stopping(stopping_rounds=50, verbose=False), lgb.log_evaluation(period=0)]
)

# Make predictions
y_pred_proba = model.predict(X_val_processed)
y_pred = (y_pred_proba > 0.5).astype(int)

# Evaluate
accuracy = accuracy_score(y_val, y_pred)
print(f'Validation Accuracy: {accuracy:.4f}')

# Predict on test set
y_test_pred_proba = model.predict(X_test_processed)
y_test_pred = (y_test_pred_proba > 0.5).astype(bool)

# Create submission
submission = pd.DataFrame({
    'PassengerId': test_df['PassengerId'],
    'Transported': y_test_pred
})

# Save submission
submission.to_csv('/workspace/submission.csv', index=False)