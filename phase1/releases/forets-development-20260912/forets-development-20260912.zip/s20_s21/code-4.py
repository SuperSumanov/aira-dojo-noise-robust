# Seed setup
import numpy as np
np.random.seed(21)

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import log_loss
import lightgbm as lgb
import os

# Load the data
train_df = pd.read_csv('/workspace/data/train.csv')
test_df = pd.read_csv('/workspace/data/test.csv')
sample_submission = pd.read_csv('/workspace/data/sample_submission.csv')

# Prepare features and target
feature_cols = [col for col in train_df.columns if col != 'id' and col != 'species']
X = train_df[feature_cols]
y = train_df['species']
X_test = test_df[feature_cols]

test_ids = test_df['id']

# Encode species labels
label_encoder = LabelEncoder()
y_encoded = label_encoder.fit_transform(y)
n_classes = len(label_encoder.classes_)

# Split the training data to create a validation set
X_train, X_val, y_train, y_val = train_test_split(X, y_encoded, test_size=0.2, random_state=21, stratify=y_encoded)

# Create LightGBM datasets
train_data = lgb.Dataset(X_train, label=y_train)
val_data = lgb.Dataset(X_val, label=y_val, reference=train_data)

# Parameters for multiclass classification
params = {
    'objective': 'multiclass',
    'num_class': n_classes,
    'metric': 'multi_logloss',
    'boosting_type': 'gbdt',
    'num_leaves': 127,
    'learning_rate': 0.05,
    'feature_fraction': 0.9,
    'bagging_fraction': 0.8,
    'bagging_freq': 5,
    'verbose': -1,
    'random_state': 21
}

# Train the model with early stopping
model = lgb.train(
    params,
    train_data,
    valid_sets=[train_data, val_data],
    num_boost_round=1000,
    callbacks=[lgb.early_stopping(stopping_rounds=50, verbose=False),
               lgb.log_evaluation(period=0)]
)

# Get predictions on validation set for evaluation
val_pred_proba = model.predict(X_val)
val_loss = log_loss(y_val, val_pred_proba)
print(f"Validation Log Loss: {val_loss}")

# Retrain on full training data for final submission
full_train_data = lgb.Dataset(X, label=y_encoded)
final_model = lgb.train(
    params,
    full_train_data,
    num_boost_round=model.best_iteration
)

# Make predictions on test set
predictions = final_model.predict(X_test)

# Create submission dataframe
submission_df = pd.DataFrame(predictions, columns=label_encoder.classes_)
submission_df.insert(0, 'id', test_ids)

# Save submission
submission_df.to_csv('/workspace/submission.csv', index=False)
print("Submission saved successfully!")