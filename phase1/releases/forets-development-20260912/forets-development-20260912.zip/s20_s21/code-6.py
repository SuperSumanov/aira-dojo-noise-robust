import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import lightgbm as lgb
import warnings
warnings.filterwarnings('ignore')

# Set random seed
np.random.seed(21)

# Load data
train_df = pd.read_csv('/workspace/data/train.csv')
train_df['Transported'] = train_df['Transported'].astype(int)
test_df = pd.read_csv('/workspace/data/test.csv')

# Feature engineering
train_df['Group'] = train_df['PassengerId'].str.split('_').str[0]
test_df['Group'] = test_df['PassengerId'].str.split('_').str[0]

# Extract cabin features
train_df[['Cabin_deck', 'Cabin_num', 'Cabin_side']] = train_df['Cabin'].str.split('/', expand=True)
test_df[['Cabin_deck', 'Cabin_num', 'Cabin_side']] = test_df['Cabin'].str.split('/', expand=True)

# Fill missing values
train_df['Age'].fillna(train_df['Age'].median(), inplace=True)
test_df['Age'].fillna(test_df['Age'].median(), inplace=True)

train_df['RoomService'].fillna(0, inplace=True)
test_df['RoomService'].fillna(0, inplace=True)
train_df['FoodCourt'].fillna(0, inplace=True)
test_df['FoodCourt'].fillna(0, inplace=True)
train_df['ShoppingMall'].fillna(0, inplace=True)
test_df['ShoppingMall'].fillna(0, inplace=True)
train_df['Spa'].fillna(0, inplace=True)
test_df['Spa'].fillna(0, inplace=True)
train_df['VRDeck'].fillna(0, inplace=True)
test_df['VRDeck'].fillna(0, inplace=True)

# Create total spending feature
train_df['TotalSpending'] = train_df['RoomService'] + train_df['FoodCourt'] + train_df['ShoppingMall'] + train_df['Spa'] + train_df['VRDeck']
test_df['TotalSpending'] = test_df['RoomService'] + test_df['FoodCourt'] + test_df['ShoppingMall'] + test_df['Spa'] + test_df['VRDeck']

# Create family size feature
train_df['FamilySize'] = train_df.groupby('Group')['Group'].transform('count')
test_df['FamilySize'] = test_df.groupby('Group')['Group'].transform('count')

# Drop unnecessary columns
features_to_drop = ['PassengerId', 'Cabin', 'Name', 'Group']
train_df.drop(columns=features_to_drop, inplace=True)
test_df.drop(columns=features_to_drop, inplace=True)

# Prepare features and target
X = train_df.drop('Transported', axis=1)
y = train_df['Transported']

# Identify categorical and numerical columns
categorical_features = X.select_dtypes(include=['object']).columns.tolist()
numerical_features = X.select_dtypes(include=[np.number]).columns.tolist()

# Preprocessing
preprocessor = ColumnTransformer(
    transformers=[
        ('num', StandardScaler(), numerical_features),
        ('cat', OneHotEncoder(sparse_output=False, handle_unknown='ignore'), categorical_features)
    ]
)

# Transform features
X_processed = preprocessor.fit_transform(X)
test_processed = preprocessor.transform(test_df)

# Split training data for validation
X_train, X_val, y_train, y_val = train_test_split(X_processed, y, test_size=0.2, random_state=21, stratify=y)

# Train LightGBM model with early stopping
lgb_train = lgb.Dataset(X_train, y_train)
lgb_val = lgb.Dataset(X_val, y_val, reference=lgb_train)

params = {
    'objective': 'binary',
    'metric': 'binary_logloss',
    'boosting_type': 'gbdt',
    'num_leaves': 31,
    'learning_rate': 0.05,
    'feature_fraction': 0.9,
    'bagging_fraction': 0.8,
    'bagging_freq': 5,
    'verbose': -1,
    'random_state': 21
}

model = lgb.train(
    params,
    lgb_train,
    valid_sets=[lgb_val],
    callbacks=[
        lgb.early_stopping(stopping_rounds=50, verbose=False),
        lgb.log_evaluation(period=0)
    ],
    num_boost_round=1000
)

# Predict on validation set
y_pred_proba = model.predict(X_val)
y_pred = (y_pred_proba > 0.5).astype(int)

# Calculate validation accuracy
val_accuracy = accuracy_score(y_val, y_pred)
print(f'Validation Accuracy: {val_accuracy:.4f}')

# Final prediction on test set
final_predictions = model.predict(test_processed)
final_predictions_binary = (final_predictions > 0.5).astype(bool)

# Create submission file
submission_df = pd.DataFrame({
    'PassengerId': test_df['PassengerId'],
    'Transported': final_predictions_binary
})

# Save to CSV
submission_df.to_csv('/workspace/submission.csv', index=False)