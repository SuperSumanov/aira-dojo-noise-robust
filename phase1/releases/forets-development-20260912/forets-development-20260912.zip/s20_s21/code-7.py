# Spaceship Titanic Prediction
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import accuracy_score
from sklearn.impute import SimpleImputer
import lightgbm as lgb

np.random.seed(21)

# Read data
train_df = pd.read_csv('/workspace/data/train.csv')
test_df = pd.read_csv('/workspace/data/test.csv')

# Feature engineering function
def process_data(df):
    # Create new features from PassengerId
    df['Group'] = df['PassengerId'].apply(lambda x: int(x.split('_')[0]))
    df['GroupSize'] = df['PassengerId'].apply(lambda x: int(x.split('_')[1]))
    
    # Extract cabin features
    df['CabinDeck'] = df['Cabin'].apply(lambda x: x.split('/')[0] if pd.notnull(x) else 'Unknown')
    df['CabinNum'] = df['Cabin'].apply(lambda x: float(x.split('/')[1]) if pd.notnull(x) else -1)
    df['CabinSide'] = df['Cabin'].apply(lambda x: x.split('/')[2] if pd.notnull(x) else 'Unknown')
    
    # Sum of expenses
    luxury_cols = ['RoomService', 'FoodCourt', 'ShoppingMall', 'Spa', 'VRDeck']
    df['TotalSpending'] = df[luxury_cols].sum(axis=1)
    
    # Count of missing expenses
    df['LuxuryCount'] = df[luxury_cols].notna().sum(axis=1)
    
    # Drop original columns
    df = df.drop(['PassengerId', 'Cabin', 'Name'], axis=1)
    
    return df

# Process both datasets
train_processed = process_data(train_df.copy())
test_processed = process_data(test_df.copy())

# Prepare features and target
y = train_processed['Transported'].astype(int)
X = train_processed.drop('Transported', axis=1)
X_test = test_processed

# Identify categorical and numerical columns
categorical_columns = ['HomePlanet', 'CryoSleep', 'Destination', 'VIP', 'CabinDeck', 'CabinSide']
numerical_columns = [col for col in X.columns if col not in categorical_columns]

# Handle missing values
imputers = {}
for col in categorical_columns:
    imputer = SimpleImputer(strategy='most_frequent')
    X[col] = imputer.fit_transform(X[[col]])
    X_test[col] = imputer.transform(X_test[[col]])
    imputers[col] = imputer

for col in numerical_columns:
    imputer = SimpleImputer(strategy='median')
    X[col] = imputer.fit_transform(X[[col]])
    X_test[col] = imputer.transform(X_test[[col]])
    imputers[col] = imputer

# Encode categorical variables
label_encoders = {}
for col in categorical_columns:
    le = LabelEncoder()
    X[col] = le.fit_transform(X[col].astype(str))
    X_test[col] = le.transform(X_test[col].astype(str))
    label_encoders[col] = le

# Scale numerical features
scaler = StandardScaler()
X[numerical_columns] = scaler.fit_transform(X[numerical_columns])
X_test[numerical_columns] = scaler.transform(X_test[numerical_columns])

# Split training data for validation
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=21, stratify=y)

# Prepare LightGBM datasets
train_data = lgb.Dataset(X_train, label=y_train)
val_data = lgb.Dataset(X_val, label=y_val, reference=train_data)

# Define parameters
params = {
    'objective': 'binary',
    'metric': 'binary_logloss',
    'boosting_type': 'gbdt',
    'num_leaves': 31,
    'learning_rate': 0.05,
    'feature_fraction': 0.9,
    'bagging_fraction': 0.8,
    'bagging_freq': 5,
    'verbose': -1,
    'random_state': 21
}

# Train model with early stopping
model = lgb.train(
    params,
    train_data,
    valid_sets=[train_data, val_data],
    num_boost_round=1000,
    callbacks=[lgb.early_stopping(stopping_rounds=50, verbose=False),
               lgb.log_evaluation(period=0)],
)

# Make predictions on validation set
val_pred = model.predict(X_val, num_iteration=model.best_iteration)
val_pred_binary = (val_pred > 0.5).astype(int)
val_accuracy = accuracy_score(y_val, val_pred_binary)
print(f'Validation Accuracy: {val_accuracy:.4f}')

# Train final model on full training data
full_train_data = lgb.Dataset(X, label=y)
final_model = lgb.train(
    params,
    full_train_data,
    num_boost_round=model.best_iteration,
    valid_sets=[full_train_data],
    callbacks=[lgb.log_evaluation(period=0)],
)

# Make predictions on test data
test_predictions = final_model.predict(X_test)
test_predictions_binary = (test_predictions > 0.5).astype(bool)

# Prepare submission
submission = pd.DataFrame({
    'PassengerId': test_df['PassengerId'],
    'Transported': test_predictions_binary
})

# Save submission
submission.to_csv('/workspace/submission.csv', index=False)
print('Submission saved successfully')
