# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.

from dataclasses import dataclass, field

from omegaconf import MISSING

from dojo.config_dataclasses.solver.mcts import MCTSSolverConfig


@dataclass
class ForeTSSolverConfig(MCTSSolverConfig):
    selector_seed: int = field(default=MISSING)
    selection_policy: str = field(default=MISSING)
    selection_coupling: str = 'independent_subset_v2'
    skip_redundant_critic: bool = False
    common_start_protocol: str = "none"
    action_delivery_protocol: str = "none"
    edit_scope: str = "whole_program"
    critic_host: str = field(
        default=MISSING, metadata={"description": "Host address for the critic service"}
    )
    critic_port: int = field(
        default=MISSING, metadata={"description": "Port number for the critic service"}
    )
    critic_max_attempts: int = field(
        default=MISSING, metadata={"description": "Maximum number of attempts to contact the critic service"}
    )
    critic_top_k: int = field(
        default=MISSING, metadata={"description": "Number of top candidates to consider from the critic's output"}
    )
    num_children_to_choose: int = field(
        default=MISSING, metadata={"description": "Number of child nodes to choose based on critic's evaluation"}
    )

    def validate(self) -> None:
        super().validate()
        if self.edit_scope not in ("whole_program", "model_module"):
            raise ValueError("edit scope")
        if self.selection_policy not in ("uniform_random", "critic_topk_random"):
            raise ValueError("explicit supported selection_policy required")
        if self.selection_coupling not in ('independent_subset_v2', 'common_priority_v1'):
            raise ValueError('unsupported selection coupling')
        if type(self.selector_seed) is not int:
            raise ValueError("explicit integer selector_seed required")
        if type(self.skip_redundant_critic) is not bool:
            raise ValueError("skip_redundant_critic must be boolean")
        if self.action_delivery_protocol not in ("none", "original_search_visible_action_delivery_v1"):
            raise ValueError("action delivery protocol")
        if self.common_start_protocol not in ("none", "rf_common_v1"):
            raise ValueError("common start protocol")
        for name in ("num_children", "critic_top_k", "num_children_to_choose", "critic_max_attempts"):
            value = getattr(self, name)
            if type(value) is not int or value <= 0:
                raise ValueError(f"{name} must be a positive integer")
        if not self.num_children_to_choose <= self.critic_top_k <= self.num_children:
            raise ValueError("require choose <= top_k <= num_children")
        import math
        if isinstance(self.uct_c, bool) or not isinstance(self.uct_c, (int, float)) or not math.isfinite(self.uct_c) or self.uct_c < 0:
            raise ValueError("uct_c must be finite and nonnegative")
