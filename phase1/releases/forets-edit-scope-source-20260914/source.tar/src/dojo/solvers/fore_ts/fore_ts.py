# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.

import asyncio
from typing import Any, Dict, List, Optional, Tuple, Union
from dojo.core.solvers.utils.response import extract_code
from dojo.core.solvers.utils.journal import Journal
from dojo.solvers.mcts.mcts import MCTS, MCTSNode
from dojo.solvers.utils import get_complextiy_level
from dojo.core.solvers.operators.core import async_execute_op_plan_code
from dojo.config_dataclasses.solver.fore_ts import ForeTSSolverConfig
import urllib.request as _rq
import json
import random
import math
from pathlib import Path
from omegaconf import OmegaConf
from dojo.solvers.fore_ts.batch_runtime import expand_batch

class ForeTS(MCTS):
    """Tree search that enquiry a critic before expanding a node."""

    search_name = "ForeTS"

    def __init__(self, cfg: ForeTSSolverConfig, task_info):
        cfg.validate()
        task_name = task_info.get("name", task_info.get("competition_id"))
        if not isinstance(task_name, str) or not task_name.strip():
            raise ValueError("ForeTS requires the actual task name before generation")
        super().__init__(cfg, task_info)
        self.journal_for_unselected = Journal()
        self.critic_host = cfg.critic_host
        self.critic_port = cfg.critic_port
        self.critic_top_k = cfg.critic_top_k
        self.num_children_to_choose = cfg.num_children_to_choose
        self.task_name = task_name
        self.critic_max_attempts = cfg.critic_max_attempts

    def _expand_leaf_and_backprop(self, path, state, task):
        return expand_batch(self, path, state, task, MCTSNode, extract_code,
                            OmegaConf.to_container(OmegaConf.structured(self.cfg), resolve=True))

    async def _query_critic(self, node: MCTSNode) -> float:
        """
        Query the critic for a value estimate of the given node.

        Args:
            node: The node for which to query the critic
        """
        # Query the critic for a value estimate of the node
        key = id(node)
        for attempt in range(self.critic_max_attempts):
            try:
                request = _rq.Request(
                    f"http://{self.critic_host}:{self.critic_port}/score",
                    json.dumps({
                        "task": self.task_name,
                        "code": (node.code or "")[:40000],
                    }).encode(),
                    {"Content-Type": "application/json"},
                )
                with _rq.urlopen(request, timeout=600) as response:
                    response_data = json.loads(response.read().decode())
                    raw_score = response_data["score"]
                    if isinstance(raw_score, bool):
                        raise ValueError("critic score must be numeric, not boolean")
                    value_estimate = float(raw_score)
                    if not math.isfinite(value_estimate):
                        raise ValueError("critic score must be finite")
                return value_estimate
            except Exception as e:
                self.logger.warning(
                    f"Critic query failed for node {key}: {type(e).__name__}")
                if attempt + 1 == self.critic_max_attempts:
                    raise RuntimeError("critic attempts exhausted; no selection executed") from None
                await asyncio.sleep(1)
        raise RuntimeError("critic_max_attempts must be positive")
                
    async def _draft(self, parent: Optional[MCTSNode] = None) -> MCTSNode:
        """
        Generate a new solution from scratch using the draft LLM operator.

        Uses the draft operator to create a new code solution based on the task description.
        The resulting code is packaged into a new Node object with relevant metadata.

        Returns:
            Node: A new node containing the drafted solution
        """
        plan, code, metrics = await async_execute_op_plan_code(
            self.draft_fn,
            self.task_desc,
            self.journal,
            self.state.current_step,
            self.cfg.time_limit_secs - self.state.running_time,
            self.data_preview,
            get_complextiy_level(parent) if self.cfg.use_complexity else None,
            self.root_node,
            max_operator_tries=self.cfg.max_llm_call_retries,
        )
        from dojo.solvers.fore_ts.edit_scope import process
        code, metrics = process(self, code, metrics)
        node = MCTSNode(plan=plan, code=code, parents=[], operators_used=["draft"], operators_metrics=[metrics])

        return node

    async def _improve(self, parent_node: MCTSNode) -> MCTSNode:
        """
        Improve an existing solution using the improve LLM operator.

        Takes a parent node with a working solution and attempts to enhance it
        using the improve operator.

        Args:
            parent_node: The node containing the solution to improve

        Returns:
            Node: A new node containing the improved solution
        """
        plan, code, metrics = await async_execute_op_plan_code(
            self.improve_fn,
            self.task_desc,
            self.journal,
            parent_node,
            self.state.current_step,
            self.cfg.time_limit_secs - self.state.running_time,
            get_complextiy_level(parent_node) if self.cfg.use_complexity else None,
            self.data_preview,
            max_operator_tries=self.cfg.max_llm_call_retries,
        )
        from dojo.solvers.fore_ts.edit_scope import process
        code, metrics = process(self, code, metrics)
        node = MCTSNode(
            plan=plan, code=code, parents=[], operators_used=["improve"], operators_metrics=[metrics]
        )

        return node

    def log_journal(self):
        result = super().log_journal()
        if self.cfg.action_delivery_protocol != "none":
            from dojo.solvers.fore_ts.action_delivery import record_action
            from dojo.solvers.fore_ts import wallclock
            record_action(self, wallclock)
        return result

    def load_checkpoint(self):
        # Parent restore loses MCTS statistics and interpreter state; do not replay.
        root = Path(self.cfg.checkpoint_path)
        if any((root / name).exists() for name in
               ("state.json", "journal.jsonl", "forets-candidates-private")):
            raise RuntimeError("ForeTS full checkpoint reconciliation not implemented")
        return super().load_checkpoint()

    def save_checkpoint(self):
        super().save_checkpoint()
        # Preserve upstream's separate, non-executed journal as an export view.
        for filename, journal in (("journal.jsonl", self.journal),
                                  ("journal_for_unselected.jsonl", self.journal_for_unselected)):
            path = Path(self.cfg.checkpoint_path) / filename
            with path.open("w") as output:
                for node_data in journal.node_list():
                    output.write(json.dumps(node_data) + "\n")
