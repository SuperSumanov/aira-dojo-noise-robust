import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import log_loss
import lightgbm as lgb
import xgboost as xgb
from catboost import CatBoostClassifier
import warnings

warnings.filterwarnings("ignore")

# Load data
train_df = pd.read_csv("./data/train.csv")
test_df = pd.read_csv("./data/test.csv")

# Prepare features and target
feature_cols = [
    col for col in train_df.columns if col.startswith(("margin", "shape", "texture"))
]
X_train = train_df[feature_cols]
y_train = train_df["species"]
X_test = test_df[feature_cols]

# Scale features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Convert to dataframes to maintain column names
X_train_scaled = pd.DataFrame(X_train_scaled, columns=feature_cols)
X_test_scaled = pd.DataFrame(X_test_scaled, columns=feature_cols)


# Create interaction features
def create_interaction_features(df):
    # Create pairwise interactions between feature groups
    new_features = []

    # Extract feature groups
    margin_cols = [col for col in df.columns if col.startswith("margin")]
    shape_cols = [col for col in df.columns if col.startswith("shape")]
    texture_cols = [col for col in df.columns if col.startswith("texture")]

    # Create interactions between different feature types
    for i in range(min(len(margin_cols), len(shape_cols))):
        new_col_name = f"margin_shape_{i}"
        df[new_col_name] = df[margin_cols[i]] * df[shape_cols[i]]
        new_features.append(new_col_name)

    for i in range(min(len(margin_cols), len(texture_cols))):
        new_col_name = f"margin_texture_{i}"
        df[new_col_name] = df[margin_cols[i]] * df[texture_cols[i]]
        new_features.append(new_col_name)

    for i in range(min(len(shape_cols), len(texture_cols))):
        new_col_name = f"shape_texture_{i}"
        df[new_col_name] = df[shape_cols[i]] * df[texture_cols[i]]
        new_features.append(new_col_name)

    return df, new_features


# Apply interaction features
X_train_with_interactions, interaction_features = create_interaction_features(
    X_train_scaled.copy()
)
X_test_with_interactions, _ = create_interaction_features(X_test_scaled.copy())

# Get all feature columns including interactions
final_feature_cols = list(X_train_with_interactions.columns)

# Prepare stratified k-fold
skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

# Store predictions for ensemble
oof_predictions = np.zeros((len(X_train), len(y_train.unique())))
test_predictions = []

# Define models
lgb_params = {
    "objective": "multiclass",
    "num_class": len(y_train.unique()),
    "metric": "multi_logloss",
    "boosting_type": "gbdt",
    "num_leaves": 31,
    "learning_rate": 0.05,
    "feature_fraction": 0.9,
    "bagging_fraction": 0.8,
    "bagging_freq": 5,
    "verbose": -1,
    "random_state": 42,
}

xgb_params = {
    "objective": "multi:softprob",
    "num_class": len(y_train.unique()),
    "eval_metric": "mlogloss",
    "learning_rate": 0.05,
    "max_depth": 6,
    "subsample": 0.8,
    "colsample_bytree": 0.8,
    "random_state": 42,
}

cat_params = {
    "objective": "Multiclass",
    "iterations": 1000,
    "learning_rate": 0.05,
    "depth": 6,
    "l2_leaf_reg": 1,
    "random_seed": 42,
    "verbose": False,
}

# Cross-validation loop
cv_scores = []
for fold, (train_idx, val_idx) in enumerate(
    skf.split(X_train_with_interactions, y_train)
):
    print(f"Training fold {fold + 1}")

    X_tr, X_val = (
        X_train_with_interactions.iloc[train_idx],
        X_train_with_interactions.iloc[val_idx],
    )
    y_tr, y_val = y_train.iloc[train_idx], y_train.iloc[val_idx]

    # LightGBM
    lgb_train = lgb.Dataset(X_tr, y_tr)
    lgb_val = lgb.Dataset(X_val, y_val, reference=lgb_train)

    lgb_model = lgb.train(
        lgb_params,
        lgb_train,
        valid_sets=[lgb_train, lgb_val],
        verbose_eval=False,
        num_boost_round=1000,
        callbacks=[lgb.early_stopping(stopping_rounds=50, verbose=False)],
    )

    # XGBoost
    xgb_train = xgb.DMatrix(X_tr, y_tr)
    xgb_val = xgb.DMatrix(X_val, y_val)

    xgb_model = xgb.train(
        xgb_params,
        xgb_train,
        num_boost_round=1000,
        evals=[(xgb_train, "train"), (xgb_val, "val")],
        verbose_eval=False,
        early_stopping_rounds=50,
    )

    # CatBoost
    cat_model = CatBoostClassifier(**cat_params)
    cat_model.fit(
        X_tr, y_tr, eval_set=(X_val, y_val), verbose=False, early_stopping_rounds=50
    )

    # Get predictions
    lgb_pred = lgb_model.predict(X_val)
    xgb_pred = xgb_model.predict(xgb_val)
    cat_pred = cat_model.predict_proba(X_val)

    # Ensemble predictions (simple average)
    ensemble_pred = (lgb_pred + xgb_pred + cat_pred) / 3

    # Calculate CV score
    cv_score = log_loss(y_val, ensemble_pred)
    cv_scores.append(cv_score)
    print(f"Fold {fold + 1} CV Score: {cv_score:.5f}")

    # Store out-of-fold predictions
    oof_predictions[val_idx] = ensemble_pred

    # Store test predictions
    lgb_test_pred = lgb_model.predict(X_test_with_interactions)
    xgb_test_pred = xgb_model.predict(xgb.DMatrix(X_test_with_interactions))
    cat_test_pred = cat_model.predict_proba(X_test_with_interactions)
    test_pred = (lgb_test_pred + xgb_test_pred + cat_test_pred) / 3
    test_predictions.append(test_pred)

# Print CV scores
print(f"\nCV Scores: {[round(score, 5) for score in cv_scores]}")
print(f"Mean CV Score: {np.mean(cv_scores):.5f} (+/- {np.std(cv_scores) * 2:.5f})")

# Train final models on full data
print("\nTraining final models...")
lgb_final = lgb.train(
    lgb_params,
    lgb.Dataset(X_train_with_interactions, y_train),
    num_boost_round=1000,
    callbacks=[lgb.early_stopping(stopping_rounds=50, verbose=False)],
)

xgb_final = xgb.train(
    xgb_params,
    xgb.DMatrix(X_train_with_interactions, y_train),
    num_boost_round=1000,
    callbacks=[xgb.callback.EarlyStopping(rounds=50, metric_name="mlogloss")],
)

cat_final = CatBoostClassifier(**cat_params)
cat_final.fit(X_train_with_interactions, y_train, verbose=False)

# Generate final test predictions
lgb_test_pred = lgb_final.predict(X_test_with_interactions)
xgb_test_pred = xgb_final.predict(xgb.DMatrix(X_test_with_interactions))
cat_test_pred = cat_final.predict_proba(X_test_with_interactions)
final_test_pred = (lgb_test_pred + xgb_test_pred + cat_test_pred) / 3

# Create submission file
sample_sub = pd.read_csv("./data/sample_submission.csv")
submission = pd.DataFrame({"id": test_df["id"]})

# Add all species columns
species_list = sample_sub.columns[1:].tolist()
for i, species in enumerate(species_list):
    submission[species] = final_test_pred[:, i]

# Save submission file
submission.to_csv("submission.csv", index=False)
print("Submission file saved as 'submission.csv'")
