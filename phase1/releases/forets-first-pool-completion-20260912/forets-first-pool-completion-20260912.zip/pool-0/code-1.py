import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import log_loss
import lightgbm as lgb
import xgboost as xgb
from catboost import CatBoostClassifier
import warnings

warnings.filterwarnings("ignore")

# Load data
train_df = pd.read_csv("./data/train.csv")
test_df = pd.read_csv("./data/test.csv")

# Prepare features and target
feature_cols = [
    col for col in train_df.columns if col.startswith(("margin", "shape", "texture"))
]
X_train = train_df[feature_cols]
y_train = train_df["species"]
X_test = test_df[feature_cols]

# Encode labels
label_encoder = LabelEncoder()
y_train_encoded = label_encoder.fit_transform(y_train)
classes = label_encoder.classes_


# Feature engineering: Create interaction features
def create_features(X):
    # Create ratio features
    margin_features = [col for col in X.columns if col.startswith("margin")]
    shape_features = [col for col in X.columns if col.startswith("shape")]
    texture_features = [col for col in X.columns if col.startswith("texture")]

    # Create ratio features between different feature types
    new_features = X.copy()

    # Ratio of means between feature types
    margin_mean = X[margin_features].mean(axis=1)
    shape_mean = X[shape_features].mean(axis=1)
    texture_mean = X[texture_features].mean(axis=1)

    new_features["margin_to_shape_ratio"] = margin_mean / (shape_mean + 1e-8)
    new_features["margin_to_texture_ratio"] = margin_mean / (texture_mean + 1e-8)
    new_features["shape_to_texture_ratio"] = shape_mean / (texture_mean + 1e-8)

    # Polynomial combinations
    new_features["margin_shape_product"] = X[margin_features].mean(axis=1) * X[
        shape_features
    ].mean(axis=1)
    new_features["margin_texture_product"] = X[margin_features].mean(axis=1) * X[
        texture_features
    ].mean(axis=1)
    new_features["shape_texture_product"] = X[shape_features].mean(axis=1) * X[
        texture_features
    ].mean(axis=1)

    # Standard deviations
    new_features["margin_std"] = X[margin_features].std(axis=1)
    new_features["shape_std"] = X[shape_features].std(axis=1)
    new_features["texture_std"] = X[texture_features].std(axis=1)

    return new_features


X_train_engineered = create_features(X_train)
X_test_engineered = create_features(X_test)

# Convert to numpy arrays for faster processing
X_train_np = X_train_engineered.values
X_test_np = X_test_engineered.values
y_train_np = y_train_encoded

# 5-fold cross-validation
skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
cv_scores = []

# Initialize models
lgb_models = []
xgb_models = []
cat_models = []

# Store predictions for ensemble
oof_predictions = np.zeros((len(X_train), len(classes)))
test_predictions = np.zeros((len(X_test), len(classes)))

for fold, (train_idx, val_idx) in enumerate(skf.split(X_train_np, y_train_np)):
    print(f"Training fold {fold+1}")

    X_tr, X_val = X_train_np[train_idx], X_train_np[val_idx]
    y_tr, y_val = y_train_np[train_idx], y_train_np[val_idx]

    # LightGBM
    lgb_train = lgb.Dataset(X_tr, y_tr)
    lgb_val = lgb.Dataset(X_val, y_val, reference=lgb_train)

    lgb_params = {
        "objective": "multiclass",
        "num_class": len(classes),
        "metric": "multi_logloss",
        "boosting_type": "gbdt",
        "num_leaves": 31,
        "learning_rate": 0.05,
        "feature_fraction": 0.9,
        "bagging_fraction": 0.8,
        "bagging_freq": 5,
        "verbose": -1,
        "random_state": 42 + fold,
    }

    lgb_model = lgb.train(
        lgb_params,
        lgb_train,
        valid_sets=[lgb_train, lgb_val],
        valid_names=["train", "valid"],
        num_boost_round=1000,
        callbacks=[
            lgb.early_stopping(stopping_rounds=50, verbose=False),
            lgb.log_evaluation(period=0),
        ],
    )

    # XGBoost
    xgb_train = xgb.DMatrix(X_tr, y_tr)
    xgb_val = xgb.DMatrix(X_val, y_val)

    xgb_params = {
        "objective": "multi:softprob",
        "num_class": len(classes),
        "eval_metric": "mlogloss",
        "max_depth": 6,
        "learning_rate": 0.05,
        "subsample": 0.8,
        "colsample_bytree": 0.8,
        "random_state": 42 + fold,
    }

    xgb_model = xgb.train(
        xgb_params,
        xgb_train,
        num_boost_round=1000,
        evals=[(xgb_train, "train"), (xgb_val, "val")],
        early_stopping_rounds=50,
        verbose_eval=False,
    )

    # CatBoost
    cat_model = CatBoostClassifier(
        iterations=1000,
        depth=6,
        learning_rate=0.05,
        l2_leaf_reg=3,
        random_seed=42 + fold,
        verbose=False,
        loss_function="MultiClass",
    )

    cat_model.fit(X_tr, y_tr, eval_set=(X_val, y_val), early_stopping_rounds=50)

    # Store models
    lgb_models.append(lgb_model)
    xgb_models.append(xgb_model)
    cat_models.append(cat_model)

    # Get predictions
    lgb_pred = lgb_model.predict(X_val)
    xgb_pred = xgb_model.predict(xgb_val)
    cat_pred = cat_model.predict_proba(X_val)

    # Average predictions
    avg_pred = (lgb_pred + xgb_pred + cat_pred) / 3

    # Store OOF predictions
    oof_predictions[val_idx] = avg_pred

    # Add test predictions
    lgb_test_pred = lgb_model.predict(X_test_np)
    xgb_test_pred = xgb_model.predict(xgb.DMatrix(X_test_np))
    cat_test_pred = cat_model.predict_proba(X_test_np)

    test_predictions += (lgb_test_pred + xgb_test_pred + cat_test_pred) / 3

# Calculate CV score
cv_score = log_loss(y_train_np, oof_predictions)
print(f"5-Fold Cross Validation Score: {cv_score:.6f}")

# Final predictions (average of all models)
final_test_predictions = test_predictions / 5

# Create submission file
submission = pd.DataFrame({"id": test_df["id"]})
for i, class_name in enumerate(classes):
    submission[class_name] = final_test_predictions[:, i]

# Save submission
submission.to_csv("submission.csv", index=False)
print("Submission saved successfully")
