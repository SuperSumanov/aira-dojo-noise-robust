import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import log_loss
import lightgbm as lgb
import xgboost as xgb
from catboost import CatBoostClassifier
import warnings

warnings.filterwarnings("ignore")

# Load data
train_df = pd.read_csv("./data/train.csv")
test_df = pd.read_csv("./data/test.csv")

# Prepare features and target
feature_cols = [
    col for col in train_df.columns if col.startswith(("margin", "shape", "texture"))
]
target_col = "species"

# Encode target
le = LabelEncoder()
train_df[target_col] = le.fit_transform(train_df[target_col])

# Combine train and test for consistent feature engineering
all_data = pd.concat([train_df[feature_cols], test_df[feature_cols]], axis=0)
n_train = len(train_df)

# Feature Engineering: Create interaction features
print("Creating interaction features...")
# Create 3-way interactions between feature groups
interaction_features = []
for i in range(64):
    for j in range(64):
        for k in range(64):
            # Only create meaningful interactions (different feature types)
            if i < 64 and j < 64 and k < 64:
                new_feature_name = f"inter_{i}_{j}_{k}"
                all_data[new_feature_name] = (
                    all_data[f"margin_{i+1}"]
                    * all_data[f"shape_{j+1}"]
                    * all_data[f"texture_{k+1}"]
                )
                interaction_features.append(new_feature_name)

print(f"Created {len(interaction_features)} interaction features")

# Split back into train and test
X_train = all_data.iloc[:n_train]
X_test = all_data.iloc[n_train:]

y_train = train_df[target_col]


# Define models
def get_models():
    models = {
        "lgb": lgb.LGBMClassifier(
            n_estimators=1000,
            learning_rate=0.05,
            num_leaves=31,
            max_depth=7,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=42,
            verbosity=-1,
        ),
        "xgb": xgb.XGBClassifier(
            n_estimators=1000,
            learning_rate=0.05,
            max_depth=6,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=42,
            verbosity=0,
        ),
        "cat": CatBoostClassifier(
            iterations=1000,
            learning_rate=0.05,
            depth=6,
            subsample=0.8,
            colsample_bylevel=0.8,
            random_seed=42,
            verbose=False,
        ),
    }
    return models


# Cross-validation function
def cross_validate(models, X, y, n_splits=5):
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=42)

    cv_scores = []
    oof_predictions = np.zeros((len(X), len(np.unique(y))))

    for fold, (train_idx, val_idx) in enumerate(skf.split(X, y)):
        print(f"Training fold {fold + 1}")

        X_train_fold, X_val_fold = X.iloc[train_idx], X.iloc[val_idx]
        y_train_fold, y_val_fold = y.iloc[train_idx], y.iloc[val_idx]

        # Train models
        model_predictions = {}
        for name, model in models.items():
            if name == "cat":
                model.fit(
                    X_train_fold,
                    y_train_fold,
                    eval_set=(X_val_fold, y_val_fold),
                    early_stopping_rounds=50,
                    verbose=False,
                )
            else:
                model.fit(
                    X_train_fold,
                    y_train_fold,
                    eval_set=[(X_val_fold, y_val_fold)],
                    early_stopping_rounds=50,
                    verbose=False,
                )

            # Get predictions
            if name == "cat":
                pred_proba = model.predict_proba(X_val_fold)
            else:
                pred_proba = model.predict_proba(X_val_fold)

            model_predictions[name] = pred_proba
            oof_predictions[val_idx] += pred_proba

        # Simple averaging ensemble for this fold
        avg_pred = np.mean(list(model_predictions.values()), axis=0)
        score = log_loss(y_val_fold, avg_pred)
        cv_scores.append(score)
        print(f"Fold {fold + 1} CV Score: {score:.5f}")

    # Average CV scores
    avg_cv_score = np.mean(cv_scores)
    std_cv_score = np.std(cv_scores)

    print(f"\nAverage CV Score: {avg_cv_score:.5f} (+/- {std_cv_score * 2:.5f})")

    return avg_cv_score, oof_predictions / n_splits


# Bayesian optimization for ensemble weights (simplified)
def optimize_ensemble_weights(train_preds, y_true, n_iter=20):
    """Simple optimization of ensemble weights"""
    best_score = float("inf")
    best_weights = [0.33, 0.33, 0.34]  # Default equal weights

    # Try different weight combinations
    for _ in range(n_iter):
        # Generate random weights that sum to 1
        weights = np.random.dirichlet([1] * 3)
        # Combine predictions with weights
        combined_pred = (
            weights[0] * train_preds["lgb"]
            + weights[1] * train_preds["xgb"]
            + weights[2] * train_preds["cat"]
        )
        score = log_loss(y_true, combined_pred)
        if score < best_score:
            best_score = score
            best_weights = weights.copy()

    return best_weights, best_score


# Train individual models and get predictions
print("Training individual models...")
models = get_models()

# Fit models on training data
model_fits = {}
for name, model in models.items():
    if name == "cat":
        model.fit(X_train, y_train, verbose=False)
    else:
        model.fit(X_train, y_train)
    model_fits[name] = model

# Get predictions on training data for ensemble optimization
train_predictions = {}
for name, model in model_fits.items():
    if name == "cat":
        pred = model.predict_proba(X_train)
    else:
        pred = model.predict_proba(X_train)
    train_predictions[name] = pred

# Optimize ensemble weights
optimal_weights, opt_score = optimize_ensemble_weights(train_predictions, y_train)
print(f"Optimal weights: {optimal_weights}")
print(f"Optimized CV Score: {opt_score:.5f}")

# Final predictions on test set
test_predictions = {}
for name, model in model_fits.items():
    if name == "cat":
        pred = model.predict_proba(X_test)
    else:
        pred = model.predict_proba(X_test)
    test_predictions[name] = pred

# Ensemble prediction with optimized weights
final_test_pred = (
    optimal_weights[0] * test_predictions["lgb"]
    + optimal_weights[1] * test_predictions["xgb"]
    + optimal_weights[2] * test_predictions["cat"]
)

# Create submission
submission = pd.DataFrame({"id": test_df["id"]})

# Add probability columns for all classes
class_names = le.classes_
for i, class_name in enumerate(class_names):
    submission[class_name] = final_test_pred[:, i]

# Save submission
submission.to_csv("submission.csv", index=False)
print("Submission saved successfully!")

# Print the final CV score
print(f"Final 5-Fold CV Score: {opt_score:.5f}")
