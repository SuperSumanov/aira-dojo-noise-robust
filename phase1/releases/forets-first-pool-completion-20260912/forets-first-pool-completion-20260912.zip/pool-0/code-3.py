import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import log_loss
import lightgbm as lgb
import xgboost as xgb
from catboost import CatBoostClassifier
import warnings

warnings.filterwarnings("ignore")

# Load data
train_df = pd.read_csv("./data/train.csv")
test_df = pd.read_csv("./data/test.csv")

# Prepare features and target
feature_cols = [
    col for col in train_df.columns if col.startswith(("margin", "shape", "texture"))
]
X_train = train_df[feature_cols]
y_train = train_df["species"]
X_test = test_df[feature_cols]

# Encode labels
label_encoder = LabelEncoder()
y_train_encoded = label_encoder.fit_transform(y_train)
classes = label_encoder.classes_


# Create feature interactions
def create_interactions(X):
    # Create interaction features between different feature types
    margin_cols = [col for col in X.columns if col.startswith("margin")]
    shape_cols = [col for col in X.columns if col.startswith("shape")]
    texture_cols = [col for col in X.columns if col.startswith("texture")]

    # Create pairwise interactions
    X_new = X.copy()

    # Interaction between margin and shape
    for i in range(min(len(margin_cols), len(shape_cols))):
        new_col_name = f"margin_shape_{i}"
        X_new[new_col_name] = X[margin_cols[i]] * X[shape_cols[i]]

    # Interaction between margin and texture
    for i in range(min(len(margin_cols), len(texture_cols))):
        new_col_name = f"margin_texture_{i}"
        X_new[new_col_name] = X[margin_cols[i]] * X[texture_cols[i]]

    # Interaction between shape and texture
    for i in range(min(len(shape_cols), len(texture_cols))):
        new_col_name = f"shape_texture_{i}"
        X_new[new_col_name] = X[shape_cols[i]] * X[texture_cols[i]]

    # Sum of features
    X_new["margin_sum"] = X[margin_cols].sum(axis=1)
    X_new["shape_sum"] = X[shape_cols].sum(axis=1)
    X_new["texture_sum"] = X[texture_cols].sum(axis=1)

    return X_new


# Apply feature engineering
X_train_engineered = create_interactions(X_train)
X_test_engineered = create_interactions(X_test)

# Prepare for cross-validation
skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

# Initialize models
lgb_models = []
xgb_models = []
cat_models = []

# Store predictions for ensemble
oof_predictions = np.zeros((len(X_train_engineered), len(classes)))
test_predictions = np.zeros((len(X_test_engineered), len(classes)))

# Cross-validation loop
cv_scores = []

for fold, (train_idx, val_idx) in enumerate(
    skf.split(X_train_engineered, y_train_encoded)
):
    print(f"Training fold {fold + 1}")

    X_tr, X_val = X_train_engineered.iloc[train_idx], X_train_engineered.iloc[val_idx]
    y_tr, y_val = y_train_encoded[train_idx], y_train_encoded[val_idx]

    # LightGBM
    lgb_train_data = lgb.Dataset(X_tr, label=y_tr)
    lgb_val_data = lgb.Dataset(X_val, label=y_val, reference=lgb_train_data)

    lgb_params = {
        "objective": "multiclass",
        "num_class": len(classes),
        "metric": "multi_logloss",
        "boosting_type": "gbdt",
        "num_leaves": 31,
        "learning_rate": 0.05,
        "feature_fraction": 0.9,
        "bagging_fraction": 0.8,
        "bagging_freq": 5,
        "verbose": -1,
        "random_state": 42 + fold,
    }

    lgb_model = lgb.train(
        lgb_params,
        lgb_train_data,
        valid_sets=[lgb_train_data, lgb_val_data],
        num_boost_round=1000,
        callbacks=[
            lgb.early_stopping(stopping_rounds=50, verbose=False),
            lgb.log_evaluation(period=0),
        ],
    )

    # XGBoost
    xgb_train_data = xgb.DMatrix(X_tr, label=y_tr)
    xgb_val_data = xgb.DMatrix(X_val, label=y_val)

    xgb_params = {
        "objective": "multi:softprob",
        "num_class": len(classes),
        "eval_metric": "mlogloss",
        "max_depth": 6,
        "learning_rate": 0.05,
        "subsample": 0.8,
        "colsample_bytree": 0.8,
        "random_state": 42 + fold,
    }

    xgb_model = xgb.train(
        xgb_params,
        xgb_train_data,
        num_boost_round=1000,
        evals=[(xgb_train_data, "train"), (xgb_val_data, "val")],
        early_stopping_rounds=50,
        verbose_eval=False,
    )

    # CatBoost
    cat_model = CatBoostClassifier(
        iterations=1000,
        depth=6,
        learning_rate=0.05,
        l2_leaf_reg=3,
        bagging_temperature=0.2,
        random_strength=0.2,
        od_wait=50,
        loss_function="MultiClass",
        eval_metric="MultiClass",
        verbose=False,
        random_seed=42 + fold,
    )

    cat_model.fit(X_tr, y_tr, eval_set=(X_val, y_val), silent=True)

    # Store models
    lgb_models.append(lgb_model)
    xgb_models.append(xgb_model)
    cat_models.append(cat_model)

    # Get predictions
    lgb_pred = lgb_model.predict(X_val)
    xgb_pred = xgb_model.predict(xgb_val_data)
    cat_pred = cat_model.predict_proba(X_val)

    # Ensemble predictions (weighted average)
    ensemble_pred = (lgb_pred + xgb_pred + cat_pred) / 3

    # Store out-of-fold predictions
    oof_predictions[val_idx] = ensemble_pred

    # Calculate CV score
    cv_score = log_loss(y_val, ensemble_pred)
    cv_scores.append(cv_score)
    print(f"Fold {fold + 1} CV Score: {cv_score:.6f}")

# Print CV scores
print(f"\nCross-validation scores: {cv_scores}")
print(f"Mean CV Score: {np.mean(cv_scores):.6f} (+/- {np.std(cv_scores) * 2:.6f})")

# Train final models on entire training set
final_lgb_preds = []
final_xgb_preds = []
final_cat_preds = []

for i in range(5):
    # LightGBM
    lgb_pred = lgb_models[i].predict(X_train_engineered)
    final_lgb_preds.append(lgb_pred)

    # XGBoost
    xgb_pred = xgb_models[i].predict(xgb.DMatrix(X_train_engineered))
    final_xgb_preds.append(xgb_pred)

    # CatBoost
    cat_pred = cat_models[i].predict_proba(X_train_engineered)
    final_cat_preds.append(cat_pred)

# Average predictions from all folds
final_lgb_pred = np.mean(final_lgb_preds, axis=0)
final_xgb_pred = np.mean(final_xgb_preds, axis=0)
final_cat_pred = np.mean(final_cat_preds, axis=0)

# Final ensemble prediction
final_ensemble_pred = (final_lgb_pred + final_xgb_pred + final_cat_pred) / 3

# Predict test set
final_test_lgb_preds = []
final_test_xgb_preds = []
final_test_cat_preds = []

for i in range(5):
    # LightGBM
    lgb_pred = lgb_models[i].predict(X_test_engineered)
    final_test_lgb_preds.append(lgb_pred)

    # XGBoost
    xgb_pred = xgb_models[i].predict(xgb.DMatrix(X_test_engineered))
    final_test_xgb_preds.append(xgb_pred)

    # CatBoost
    cat_pred = cat_models[i].predict_proba(X_test_engineered)
    final_test_cat_preds.append(cat_pred)

# Average predictions from all folds
final_test_lgb_pred = np.mean(final_test_lgb_preds, axis=0)
final_test_xgb_pred = np.mean(final_test_xgb_preds, axis=0)
final_test_cat_pred = np.mean(final_test_cat_preds, axis=0)

# Final test ensemble prediction
final_test_ensemble_pred = (
    final_test_lgb_pred + final_test_xgb_pred + final_test_cat_pred
) / 3

# Create submission file
submission_df = pd.DataFrame({"id": test_df["id"]})

for i, class_name in enumerate(classes):
    submission_df[class_name] = final_test_ensemble_pred[:, i]

# Save submission file
submission_df.to_csv("submission.csv", index=False)
print("Submission file created successfully!")
