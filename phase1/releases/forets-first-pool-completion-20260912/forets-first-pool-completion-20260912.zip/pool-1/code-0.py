import pandas as pd
import numpy as np
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.metrics import accuracy_score
import lightgbm as lgb
import xgboost as xgb
from catboost import CatBoostClassifier
import warnings

warnings.filterwarnings("ignore")

# Load data
train_df = pd.read_csv("./data/train.csv")
test_df = pd.read_csv("./data/test.csv")


# Feature engineering function
def create_features(df):
    df = df.copy()

    # Extract group information from PassengerId
    df["Group"] = df["PassengerId"].str.split("_").str[0].astype(int)
    df["GroupSize"] = df.groupby("Group")["PassengerId"].transform("count")

    # Extract cabin information
    df["Cabin_deck"] = df["Cabin"].str.split("/").str[0]
    df["Cabin_side"] = df["Cabin"].str.split("/").str[2]

    # Create spending features
    spending_cols = ["RoomService", "FoodCourt", "ShoppingMall", "Spa", "VRDeck"]
    df["TotalSpending"] = df[spending_cols].sum(axis=1)
    df["HasSpent"] = (df["TotalSpending"] > 0).astype(int)

    # Age groups
    df["AgeGroup"] = pd.cut(
        df["Age"],
        bins=[0, 12, 18, 35, 60, 100],
        labels=["Child", "Teen", "Adult", "Middle", "Senior"],
    )

    # CryoSleep interaction with spending
    df["CryoSpendingInteraction"] = df["CryoSleep"].fillna(False) & (
        df["TotalSpending"] > 0
    )

    # VIP + CryoSleep combinations
    df["VIP_Cryo"] = df["VIP"].fillna(False) & df["CryoSleep"].fillna(False)

    return df


# Apply feature engineering to both datasets
train_df = create_features(train_df)
test_df = create_features(test_df)

# Select features for modeling
feature_cols = [
    "HomePlanet",
    "CryoSleep",
    "Destination",
    "Age",
    "VIP",
    "Cabin_deck",
    "Cabin_side",
    "GroupSize",
    "TotalSpending",
    "HasSpent",
    "AgeGroup",
    "CryoSpendingInteraction",
    "VIP_Cryo",
]

# Handle missing values
imputer = SimpleImputer(strategy="most_frequent")
train_imputed = pd.DataFrame(
    imputer.fit_transform(train_df[feature_cols]), columns=feature_cols
)
test_imputed = pd.DataFrame(
    imputer.transform(test_df[feature_cols]), columns=feature_cols
)

# Encode categorical variables
le_dict = {}
for col in ["HomePlanet", "Destination", "Cabin_deck", "Cabin_side", "AgeGroup"]:
    if col in train_imputed.columns:
        le = LabelEncoder()
        train_imputed[col] = le.fit_transform(train_imputed[col].fillna("Missing"))
        test_imputed[col] = le.transform(test_imputed[col].fillna("Missing"))
        le_dict[col] = le

# Handle boolean columns
for col in ["CryoSleep", "VIP", "CryoSpendingInteraction", "VIP_Cryo"]:
    if col in train_imputed.columns:
        train_imputed[col] = train_imputed[col].fillna(False).astype(int)
        test_imputed[col] = test_imputed[col].fillna(False).astype(int)

# Fill remaining missing values for numerical features
num_imputer = SimpleImputer(strategy="median")
train_imputed[["Age", "TotalSpending"]] = num_imputer.fit_transform(
    train_imputed[["Age", "TotalSpending"]]
)
test_imputed[["Age", "TotalSpending"]] = num_imputer.transform(
    test_imputed[["Age", "TotalSpending"]]
)

# Prepare data for modeling
X_train = train_imputed
y_train = train_df["Transported"]
X_test = test_imputed

# Normalize features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Convert to proper format for models
X_train_lgb = X_train_scaled
X_test_lgb = X_test_scaled

# Define models
lgb_params = {
    "objective": "binary",
    "metric": "binary_logloss",
    "boosting_type": "gbdt",
    "num_leaves": 31,
    "learning_rate": 0.05,
    "feature_fraction": 0.9,
    "bagging_fraction": 0.8,
    "bagging_freq": 5,
    "verbose": -1,
    "random_state": 42,
}

xgb_params = {
    "objective": "binary:logistic",
    "eval_metric": "logloss",
    "learning_rate": 0.05,
    "max_depth": 6,
    "subsample": 0.8,
    "colsample_bytree": 0.8,
    "random_state": 42,
}

cat_params = {
    "objective": "Logloss",
    "eval_metric": "Accuracy",
    "learning_rate": 0.05,
    "depth": 6,
    "l2_leaf_reg": 1,
    "random_seed": 42,
    "verbose": False,
}

# 5-Fold Cross Validation
skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
cv_scores = []

# Store predictions for stacking
oof_predictions = np.zeros(len(X_train))
test_predictions = np.zeros(len(X_test))

# Model predictions storage
lgb_preds = []
xgb_preds = []
cat_preds = []

for fold, (train_idx, val_idx) in enumerate(skf.split(X_train, y_train)):
    print(f"Training fold {fold + 1}")

    # Split data
    X_tr, X_val = X_train_lgb[train_idx], X_train_lgb[val_idx]
    y_tr, y_val = y_train.iloc[train_idx], y_train.iloc[val_idx]

    # LightGBM
    train_data = lgb.Dataset(X_tr, label=y_tr)
    val_data = lgb.Dataset(X_val, label=y_val, reference=train_data)

    lgb_model = lgb.train(
        lgb_params,
        train_data,
        valid_sets=[val_data],
        num_boost_round=1000,
        callbacks=[
            lgb.early_stopping(stopping_rounds=50, verbose=False),
            lgb.log_evaluation(period=0),
        ],
    )

    # XGBoost
    xgb_train = xgb.DMatrix(X_tr, label=y_tr)
    xgb_val = xgb.DMatrix(X_val, label=y_val)

    xgb_model = xgb.train(
        xgb_params,
        xgb_train,
        num_boost_round=1000,
        evals=[(xgb_train, "train"), (xgb_val, "val")],
        early_stopping_rounds=50,
        verbose_eval=False,
    )

    # CatBoost
    cat_model = CatBoostClassifier(
        **cat_params, iterations=1000, early_stopping_rounds=50
    )
    cat_model.fit(X_tr, y_tr, eval_set=(X_val, y_val), verbose=False)

    # Get predictions
    lgb_pred = lgb_model.predict(X_val)
    xgb_pred = xgb_model.predict(xgb_val)
    cat_pred = cat_model.predict_proba(X_val)[:, 1]

    # Convert to binary predictions
    lgb_pred_binary = (lgb_pred > 0.5).astype(int)
    xgb_pred_binary = (xgb_pred > 0.5).astype(int)
    cat_pred_binary = (cat_pred > 0.5).astype(int)

    # Calculate accuracy
    lgb_acc = accuracy_score(y_val, lgb_pred_binary)
    xgb_acc = accuracy_score(y_val, xgb_pred_binary)
    cat_acc = accuracy_score(y_val, cat_pred_binary)

    print(f"LGB: {lgb_acc:.4f}, XGB: {xgb_acc:.4f}, CAT: {cat_acc:.4f}")

    cv_scores.append([lgb_acc, xgb_acc, cat_acc])

    # Store out-of-fold predictions
    oof_predictions[val_idx] = lgb_pred_binary

    # Store test predictions
    lgb_test_pred = lgb_model.predict(X_test_lgb)
    xgb_test_pred = xgb_model.predict(xgb.DMatrix(X_test_lgb))
    cat_test_pred = cat_model.predict_proba(X_test_lgb)[:, 1]

    lgb_preds.append(lgb_test_pred)
    xgb_preds.append(xgb_test_pred)
    cat_preds.append(cat_test_pred)

# Calculate mean CV scores
mean_scores = np.mean(cv_scores, axis=0)
print(f"\nMean CV Scores:")
print(f"LightGBM: {mean_scores[0]:.4f}")
print(f"XGBoost: {mean_scores[1]:.4f}")
print(f"CatBoost: {mean_scores[2]:.4f}")

# Ensemble predictions (simple average)
final_predictions = (
    np.array(lgb_preds).mean(axis=0) * 0.3
    + np.array(xgb_preds).mean(axis=0) * 0.3
    + np.array(cat_preds).mean(axis=0) * 0.4
)

# Convert to binary predictions
final_predictions_binary = (final_predictions > 0.5).astype(int)

# Save submission
submission = pd.DataFrame(
    {
        "PassengerId": test_df["PassengerId"],
        "Transported": final_predictions_binary.astype(bool),
    }
)

submission.to_csv("submission.csv", index=False)
print("\nSubmission saved successfully!")
print(f"Final accuracy score: {accuracy_score(y_train, oof_predictions):.4f}")
