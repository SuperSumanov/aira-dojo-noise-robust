import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
import lightgbm as lgb
import xgboost as xgb
from catboost import CatBoostClassifier
import warnings

warnings.filterwarnings("ignore")

# Load data
train_df = pd.read_csv("./data/train.csv")
test_df = pd.read_csv("./data/test.csv")


# Feature engineering function
def feature_engineering(df):
    df = df.copy()

    # Extract cabin features
    df["Cabin_deck"] = df["Cabin"].str.split("/").str[0]
    df["Cabin_num"] = df["Cabin"].str.split("/").str[1].astype(float)
    df["Cabin_side"] = df["Cabin"].str.split("/").str[2]

    # Extract group info from PassengerId
    df["Group"] = df["PassengerId"].str.split("_").str[0]
    df["Group_size"] = df.groupby("Group")["PassengerId"].transform("count")

    # Create spending features
    spending_cols = ["RoomService", "FoodCourt", "ShoppingMall", "Spa", "VRDeck"]
    df["Total_spending"] = df[spending_cols].sum(axis=1)
    df["Spending_ratio"] = df["Total_spending"] / (
        df["Age"] + 1
    )  # Avoid division by zero

    # Create age groups
    df["Age_group"] = pd.cut(
        df["Age"],
        bins=[0, 12, 18, 35, 60, 100],
        labels=["Child", "Teen", "Adult", "Middle", "Senior"],
    )

    # Create VIP combinations
    df["VIP_bool"] = df["VIP"].fillna(False).astype(bool)

    # Create family size features
    df["Is_alone"] = (df["Group_size"] == 1).astype(int)

    # Create spending categories
    df["High_spend"] = (df["Total_spending"] > df["Total_spending"].median()).astype(
        int
    )

    return df


# Apply feature engineering to both datasets
train_df = feature_engineering(train_df)
test_df = feature_engineering(test_df)

# Select features for modeling
feature_columns = [
    "Age",
    "CryoSleep",
    "Destination",
    "HomePlanet",
    "VIP_bool",
    "Cabin_deck",
    "Cabin_side",
    "Cabin_num",
    "Group_size",
    "Total_spending",
    "Spending_ratio",
    "Age_group",
    "Is_alone",
    "High_spend",
]

# Handle missing values
train_df[feature_columns] = train_df[feature_columns].fillna(-1)
test_df[feature_columns] = test_df[feature_columns].fillna(-1)

# Encode categorical variables
categorical_features = [
    "CryoSleep",
    "Destination",
    "HomePlanet",
    "Cabin_deck",
    "Cabin_side",
    "Age_group",
]
label_encoders = {}

for col in categorical_features:
    if col in train_df.columns:
        le = LabelEncoder()
        train_df[col + "_encoded"] = le.fit_transform(train_df[col].astype(str))
        test_df[col + "_encoded"] = le.transform(test_df[col].astype(str))
        label_encoders[col] = le

# Prepare features for modeling
feature_columns_encoded = [
    col for col in feature_columns if not col in categorical_features
]
feature_columns_encoded += [col + "_encoded" for col in categorical_features]

X_train = train_df[feature_columns_encoded]
y_train = train_df["Transported"]

X_test = test_df[feature_columns_encoded]

# Define models
lgb_model = lgb.LGBMClassifier(
    n_estimators=1000,
    learning_rate=0.05,
    num_leaves=31,
    max_depth=-1,
    random_state=42,
    verbosity=-1,
)

xgb_model = xgb.XGBClassifier(
    n_estimators=1000,
    learning_rate=0.05,
    max_depth=6,
    random_state=42,
    eval_metric="logloss",
)

cat_model = CatBoostClassifier(
    iterations=1000, learning_rate=0.05, depth=6, random_seed=42, verbose=False
)

rf_meta_model = RandomForestClassifier(n_estimators=100, random_state=42)

# 5-Fold Cross Validation
skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
cv_scores = []

predictions_list = []
for fold, (train_idx, val_idx) in enumerate(skf.split(X_train, y_train)):
    print(f"Training fold {fold + 1}")

    X_tr, X_val = X_train.iloc[train_idx], X_train.iloc[val_idx]
    y_tr, y_val = y_train.iloc[train_idx], y_train.iloc[val_idx]

    # Train models
    lgb_model.fit(
        X_tr,
        y_tr,
        eval_set=[(X_val, y_val)],
        callbacks=[lgb.early_stopping(stopping_rounds=50, verbose=False)],
    )
    xgb_model.fit(X_tr, y_tr)
    cat_model.fit(X_tr, y_tr, verbose=False)

    # Get predictions
    lgb_pred = lgb_model.predict(X_val)
    xgb_pred = xgb_model.predict(X_val)
    cat_pred = cat_model.predict(X_val)

    # Create meta-features
    meta_features = np.column_stack([lgb_pred, xgb_pred, cat_pred])

    # Train meta-model
    rf_meta_model.fit(meta_features, y_val)

    # Predict on test set
    lgb_test_pred = lgb_model.predict(X_test)
    xgb_test_pred = xgb_model.predict(X_test)
    cat_test_pred = cat_model.predict(X_test)

    test_meta_features = np.column_stack([lgb_test_pred, xgb_test_pred, cat_test_pred])
    final_pred = rf_meta_model.predict(test_meta_features)

    # Store predictions
    predictions_list.append(final_pred)

    # Calculate CV score
    accuracy = accuracy_score(y_val, lgb_pred)
    cv_scores.append(accuracy)
    print(f"Fold {fold + 1} Accuracy: {accuracy:.4f}")

print(f"\n5-Fold Cross Validation Scores: {cv_scores}")
print(f"Mean CV Score: {np.mean(cv_scores):.4f} (+/- {np.std(cv_scores) * 2:.4f})")

# Final prediction using all folds
final_predictions = np.mean(predictions_list, axis=0).round().astype(bool)

# Create submission file
submission = pd.DataFrame(
    {"PassengerId": test_df["PassengerId"], "Transported": final_predictions}
)

submission.to_csv("submission.csv", index=False)
print("Submission file created successfully!")
