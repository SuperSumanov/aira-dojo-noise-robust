import pandas as pd
import numpy as np
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score
import lightgbm as lgb
import xgboost as xgb
from catboost import CatBoostClassifier
from sklearn.ensemble import RandomForestClassifier
import warnings

warnings.filterwarnings("ignore")

# Load data
train_df = pd.read_csv("./data/train.csv")
test_df = pd.read_csv("./data/test.csv")


# Feature engineering function
def create_features(df):
    # Extract cabin info
    df["Cabin_deck"] = df["Cabin"].str.split("/").str[0]
    df["Cabin_side"] = df["Cabin"].str.split("/").str[2]

    # Group size and group ID
    df["GroupID"] = df["PassengerId"].str.split("_").str[0]
    df["GroupSize"] = df.groupby("GroupID")["PassengerId"].transform("count")

    # Age groups
    df["AgeGroup"] = pd.cut(
        df["Age"],
        bins=[0, 12, 18, 35, 60, 100],
        labels=["Child", "Teen", "Adult", "Middle", "Senior"],
    )

    # Total spending
    spending_cols = ["RoomService", "FoodCourt", "ShoppingMall", "Spa", "VRDeck"]
    df["TotalSpending"] = df[spending_cols].sum(axis=1)

    # Spending ratios
    df["SpendingRatio"] = df["TotalSpending"] / (
        df["Age"] + 1
    )  # Avoid division by zero

    # VIP indicator
    df["IsVIP"] = df["VIP"].map({True: 1, False: 0})

    # CryoSleep indicator
    df["IsCryo"] = df["CryoSleep"].map({True: 1, False: 0})

    # Family indicator (if same group ID and same cabin deck)
    df["FamilyMember"] = (df["GroupSize"] > 1) & (df["Cabin_deck"].notna())

    return df


# Apply feature engineering
train_df = create_features(train_df)
test_df = create_features(test_df)


# Handle missing values
def handle_missing_values(df):
    # Fill numerical columns with median
    num_cols = [
        "Age",
        "RoomService",
        "FoodCourt",
        "ShoppingMall",
        "Spa",
        "VRDeck",
        "TotalSpending",
        "SpendingRatio",
    ]
    for col in num_cols:
        if col in df.columns:
            df[col] = df[col].fillna(df[col].median())

    # Fill categorical columns with mode
    cat_cols = ["Cabin_deck", "Cabin_side", "HomePlanet", "Destination", "AgeGroup"]
    for col in cat_cols:
        if col in df.columns:
            df[col] = df[col].fillna(
                df[col].mode()[0] if not df[col].mode().empty else "Unknown"
            )

    # Fill CryoSleep and VIP with False
    df["CryoSleep"] = df["CryoSleep"].fillna(False)
    df["VIP"] = df["VIP"].fillna(False)

    return df


train_df = handle_missing_values(train_df)
test_df = handle_missing_values(test_df)


# Target encoding for categorical variables
def target_encode(df_train, df_test, cols_to_encode, target_col):
    encoded_dict = {}
    for col in cols_to_encode:
        # Calculate mean target for each category
        encoding_map = df_train.groupby(col)[target_col].mean()
        # Apply to both train and test
        df_train[col + "_encoded"] = df_train[col].map(encoding_map)
        df_test[col + "_encoded"] = df_test[col].map(encoding_map)
        # Fill NaN with global mean
        df_train[col + "_encoded"] = df_train[col + "_encoded"].fillna(
            df_train[target_col].mean()
        )
        df_test[col + "_encoded"] = df_test[col + "_encoded"].fillna(
            df_train[target_col].mean()
        )
        encoded_dict[col] = encoding_map
    return df_train, df_test, encoded_dict


# Select features for modeling
feature_cols = [
    "Age",
    "TotalSpending",
    "SpendingRatio",
    "GroupSize",
    "IsVIP",
    "IsCryo",
    "Cabin_deck_encoded",
    "Cabin_side_encoded",
    "HomePlanet_encoded",
    "Destination_encoded",
    "AgeGroup_encoded",
]

# Apply target encoding
train_df, test_df, _ = target_encode(
    train_df,
    test_df,
    ["Cabin_deck", "Cabin_side", "HomePlanet", "Destination", "AgeGroup"],
    "Transported",
)

# Prepare data for modeling
X = train_df[feature_cols]
y = train_df["Transported"]

# Test data preparation
X_test = test_df[feature_cols]

# 5-Fold Cross Validation
skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
cv_scores = []

# Model parameters
lgb_params = {
    "objective": "binary",
    "metric": "binary_logloss",
    "boosting_type": "gbdt",
    "num_leaves": 31,
    "learning_rate": 0.05,
    "feature_fraction": 0.9,
    "bagging_fraction": 0.8,
    "bagging_freq": 5,
    "verbose": -1,
    "random_state": 42,
}

xgb_params = {
    "objective": "binary:logistic",
    "eval_metric": "logloss",
    "max_depth": 6,
    "learning_rate": 0.05,
    "subsample": 0.8,
    "colsample_bytree": 0.8,
    "random_state": 42,
}

cat_params = {
    "objective": "Logloss",
    "eval_metric": "AUC",
    "depth": 6,
    "learning_rate": 0.05,
    "l2_leaf_reg": 1,
    "random_seed": 42,
    "verbose": False,
}

# Training and prediction loop
for fold, (train_idx, val_idx) in enumerate(skf.split(X, y)):
    print(f"Training fold {fold + 1}")

    X_train_fold, X_val_fold = X.iloc[train_idx], X.iloc[val_idx]
    y_train_fold, y_val_fold = y.iloc[train_idx], y.iloc[val_idx]

    # LightGBM
    lgb_train = lgb.Dataset(X_train_fold, y_train_fold)
    lgb_val = lgb.Dataset(X_val_fold, y_val_fold, reference=lgb_train)

    lgb_model = lgb.train(
        lgb_params,
        lgb_train,
        valid_sets=[lgb_train, lgb_val],
        num_boost_round=1000,
        callbacks=[
            lgb.early_stopping(stopping_rounds=50, verbose=False),
            lgb.log_evaluation(period=0),
        ],
    )

    # XGBoost
    xgb_train = xgb.DMatrix(X_train_fold, y_train_fold)
    xgb_val = xgb.DMatrix(X_val_fold, y_val_fold)

    xgb_model = xgb.train(
        xgb_params,
        xgb_train,
        num_boost_round=1000,
        evals=[(xgb_train, "train"), (xgb_val, "val")],
        early_stopping_rounds=50,
        verbose_eval=False,
    )

    # CatBoost
    cat_model = CatBoostClassifier(
        **cat_params, iterations=1000, early_stopping_rounds=50
    )

    cat_model.fit(
        X_train_fold, y_train_fold, eval_set=(X_val_fold, y_val_fold), verbose=False
    )

    # Predictions
    lgb_pred = (lgb_model.predict(X_val_fold) > 0.5).astype(int)
    xgb_pred = (xgb_model.predict(xgb_val) > 0.5).astype(int)
    cat_pred = cat_model.predict(X_val_fold)

    # Ensemble predictions (weighted average)
    ensemble_pred = (
        (lgb_pred * 0.3 + xgb_pred * 0.3 + cat_pred * 0.4).round().astype(int)
    )

    # Score
    score = accuracy_score(y_val_fold, ensemble_pred)
    cv_scores.append(score)
    print(f"Fold {fold + 1} Accuracy: {score:.5f}")

print(f"\n5-Fold Cross Validation Scores: {cv_scores}")
print(f"Mean CV Score: {np.mean(cv_scores):.5f} (+/- {np.std(cv_scores) * 2:.5f})")

# Final model training and prediction
print("\nTraining final model and generating predictions...")

# Train final models
lgb_final = lgb.train(lgb_params, lgb.Dataset(X, y), num_boost_round=1000)
xgb_final = xgb.train(xgb_params, xgb.DMatrix(X, y), num_boost_round=1000)
cat_final = CatBoostClassifier(**cat_params, iterations=1000)
cat_final.fit(X, y, verbose=False)

# Final predictions
lgb_pred_final = (lgb_final.predict(X_test) > 0.5).astype(int)
xgb_pred_final = (xgb_final.predict(xgb.DMatrix(X_test)) > 0.5).astype(int)
cat_pred_final = cat_final.predict(X_test)

# Ensemble final predictions
final_pred = (
    (lgb_pred_final * 0.3 + xgb_pred_final * 0.3 + cat_pred_final * 0.4)
    .round()
    .astype(int)
)

# Create submission
submission = pd.DataFrame(
    {"PassengerId": test_df["PassengerId"], "Transported": final_pred.astype(bool)}
)

submission.to_csv("submission.csv", index=False)
print("Submission file saved as 'submission.csv'")
