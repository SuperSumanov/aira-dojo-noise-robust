import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import accuracy_score
import lightgbm as lgb
import xgboost as xgb
from catboost import CatBoostClassifier
import warnings

warnings.filterwarnings("ignore")

# Load data
train_df = pd.read_csv("./data/train.csv")
test_df = pd.read_csv("./data/test.csv")


# Feature Engineering
def create_features(df):
    # Extract cabin features
    df["Cabin_deck"] = df["Cabin"].str.split("/").str[0]
    df["Cabin_num"] = df["Cabin"].str.split("/").str[1].astype(float)
    df["Cabin_side"] = df["Cabin"].str.split("/").str[2]

    # Extract group info from PassengerId
    df["Group"] = df["PassengerId"].str.split("_").str[0]
    df["Group_size"] = df.groupby("Group")["PassengerId"].transform("count")

    # Create spending features
    spending_cols = ["RoomService", "FoodCourt", "ShoppingMall", "Spa", "VRDeck"]
    df["Total_spending"] = df[spending_cols].sum(axis=1)
    df["Spending_ratio"] = df["Total_spending"] / (df[spending_cols].max(axis=1) + 1)

    # Age groups
    df["Age_group"] = pd.cut(
        df["Age"],
        bins=[0, 12, 18, 35, 60, 100],
        labels=["Child", "Teen", "Adult", "Middle", "Senior"],
    )

    # Create binary features
    df["Has_spent"] = (df["Total_spending"] > 0).astype(int)
    df["Is_cryo"] = (df["CryoSleep"] == True).astype(int)

    return df


# Apply feature engineering
train_df = create_features(train_df)
test_df = create_features(test_df)

# Select features for modeling
feature_cols = [
    "HomePlanet",
    "CryoSleep",
    "Destination",
    "Age",
    "VIP",
    "Cabin_deck",
    "Cabin_side",
    "Group_size",
    "Total_spending",
    "Spending_ratio",
    "Age_group",
    "Has_spent",
    "Is_cryo",
]

# Handle missing values
train_df[feature_cols] = train_df[feature_cols].fillna("Missing")
test_df[feature_cols] = test_df[feature_cols].fillna("Missing")

# Encode categorical variables
categorical_features = [
    "HomePlanet",
    "Destination",
    "Cabin_deck",
    "Cabin_side",
    "Age_group",
]

# Label encode categorical features
label_encoders = {}
for col in categorical_features:
    le = LabelEncoder()
    train_df[col + "_encoded"] = le.fit_transform(train_df[col].astype(str))
    test_df[col + "_encoded"] = le.transform(test_df[col].astype(str))
    label_encoders[col] = le

# Use encoded features for modeling
encoded_feature_cols = [col + "_encoded" for col in categorical_features]
final_feature_cols = encoded_feature_cols + [
    "Age",
    "Group_size",
    "Total_spending",
    "Spending_ratio",
    "Has_spent",
    "Is_cryo",
]

# Prepare data
X_train = train_df[final_feature_cols]
y_train = train_df["Transported"]
X_test = test_df[final_feature_cols]

# Cross-validation setup
skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
cv_scores = []

# Model predictions storage
oof_predictions = np.zeros(len(X_train))
test_predictions = np.zeros(len(X_test))

# Define models
lgb_params = {
    "objective": "binary",
    "metric": "binary_logloss",
    "boosting_type": "gbdt",
    "num_leaves": 31,
    "learning_rate": 0.05,
    "feature_fraction": 0.9,
    "bagging_fraction": 0.8,
    "bagging_freq": 5,
    "verbose": -1,
    "random_state": 42,
}

xgb_params = {
    "objective": "binary:logistic",
    "eval_metric": "logloss",
    "learning_rate": 0.05,
    "max_depth": 6,
    "subsample": 0.8,
    "colsample_bytree": 0.8,
    "random_state": 42,
}

cat_params = {
    "objective": "Logloss",
    "learning_rate": 0.05,
    "iterations": 1000,
    "verbose": False,
    "random_seed": 42,
}

# Training and prediction loop
for fold, (train_idx, val_idx) in enumerate(skf.split(X_train, y_train)):
    print(f"Training fold {fold + 1}")

    # Split data
    X_tr, X_val = X_train.iloc[train_idx], X_train.iloc[val_idx]
    y_tr, y_val = y_train.iloc[train_idx], y_train.iloc[val_idx]

    # LightGBM
    train_data_lgb = lgb.Dataset(X_tr, label=y_tr)
    val_data_lgb = lgb.Dataset(X_val, label=y_val)

    lgb_model = lgb.train(
        lgb_params,
        train_data_lgb,
        valid_sets=[val_data_lgb],
        callbacks=[
            lgb.early_stopping(stopping_rounds=50, verbose=False),
            lgb.log_evaluation(period=0),
        ],
    )

    # XGBoost
    train_data_xgb = xgb.DMatrix(X_tr, label=y_tr)
    val_data_xgb = xgb.DMatrix(X_val, label=y_val)

    xgb_model = xgb.train(
        xgb_params,
        train_data_xgb,
        num_boost_round=1000,
        evals=[(train_data_xgb, "train"), (val_data_xgb, "val")],
        early_stopping_rounds=50,
        verbose_eval=False,
    )

    # CatBoost
    cat_model = CatBoostClassifier(**cat_params)
    cat_model.fit(X_tr, y_tr, eval_set=(X_val, y_val), silent=True)

    # Predictions
    lgb_pred = lgb_model.predict(X_val)
    xgb_pred = xgb_model.predict(val_data_xgb)
    cat_pred = cat_model.predict_proba(X_val)[:, 1]

    # Average predictions
    avg_pred = (lgb_pred + xgb_pred + cat_pred) / 3

    # Store OOF predictions
    oof_predictions[val_idx] = avg_pred

    # Calculate CV score
    cv_score = accuracy_score(y_val, (avg_pred > 0.5).astype(int))
    cv_scores.append(cv_score)
    print(f"Fold {fold + 1} CV Score: {cv_score:.5f}")

    # Test predictions
    lgb_test_pred = lgb_model.predict(X_test)
    xgb_test_pred = xgb_model.predict(xgb.DMatrix(X_test))
    cat_test_pred = cat_model.predict_proba(X_test)[:, 1]

    test_predictions += (lgb_test_pred + xgb_test_pred + cat_test_pred) / 3

# Final CV score
mean_cv_score = np.mean(cv_scores)
std_cv_score = np.std(cv_scores)
print(f"\n5-Fold CV Scores: {[f'{score:.5f}' for score in cv_scores]}")
print(f"Mean CV Score: {mean_cv_score:.5f} (+/- {std_cv_score * 2:.5f})")

# Generate submission
test_predictions = test_predictions / 5
submission = pd.DataFrame(
    {
        "PassengerId": test_df["PassengerId"],
        "Transported": (test_predictions > 0.5).astype(bool),
    }
)

# Save submission
submission.to_csv("submission.csv", index=False)
print("Submission saved successfully!")
