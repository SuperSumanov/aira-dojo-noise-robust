import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import LabelEncoder
from lightgbm import LGBMClassifier
from xgboost import XGBClassifier
from catboost import CatBoostClassifier
from sklearn.metrics import log_loss
import warnings

warnings.filterwarnings("ignore")

# Load data
train_df = pd.read_csv("./data/train.csv")
test_df = pd.read_csv("./data/test.csv")

# Prepare features and target
feature_cols = [
    col for col in train_df.columns if col.startswith(("margin", "shape", "texture"))
]
X_train = train_df[feature_cols]
y_train = train_df["species"]
X_test = test_df[feature_cols]

# Encode labels
label_encoder = LabelEncoder()
y_train_encoded = label_encoder.fit_transform(y_train)
classes = label_encoder.classes_


# Create interaction features
def create_interaction_features(X):
    # Create pairwise interactions between feature groups
    margin_cols = [col for col in X.columns if col.startswith("margin")]
    shape_cols = [col for col in X.columns if col.startswith("shape")]
    texture_cols = [col for col in X.columns if col.startswith("texture")]

    X_new = X.copy()

    # Add interaction terms
    for i in range(len(margin_cols)):
        for j in range(len(shape_cols)):
            X_new[f"margin_shape_{i}_{j}"] = X[margin_cols[i]] * X[shape_cols[j]]

    for i in range(len(margin_cols)):
        for j in range(len(texture_cols)):
            X_new[f"margin_texture_{i}_{j}"] = X[margin_cols[i]] * X[texture_cols[j]]

    for i in range(len(shape_cols)):
        for j in range(len(texture_cols)):
            X_new[f"shape_texture_{i}_{j}"] = X[shape_cols[i]] * X[texture_cols[j]]

    return X_new


# Apply feature engineering
X_train_engineered = create_interaction_features(X_train)
X_test_engineered = create_interaction_features(X_test)

# Initialize models
lgb_model = LGBMClassifier(
    n_estimators=1000,
    learning_rate=0.05,
    num_leaves=31,
    max_depth=-1,
    random_state=42,
    verbosity=-1,
)

xgb_model = XGBClassifier(
    n_estimators=1000, learning_rate=0.05, max_depth=6, random_state=42, verbosity=0
)

cat_model = CatBoostClassifier(
    n_estimators=1000, learning_rate=0.05, depth=6, random_state=42, verbose=False
)

# 5-Fold Cross Validation
skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
cv_scores = []

predictions_list = []
for fold, (train_idx, val_idx) in enumerate(
    skf.split(X_train_engineered, y_train_encoded)
):
    print(f"Training fold {fold + 1}")

    X_tr, X_val = X_train_engineered.iloc[train_idx], X_train_engineered.iloc[val_idx]
    y_tr, y_val = y_train_encoded[train_idx], y_train_encoded[val_idx]

    # Train models
    lgb_model.fit(X_tr, y_tr)
    xgb_model.fit(X_tr, y_tr)
    cat_model.fit(X_tr, y_tr)

    # Get predictions
    lgb_pred = lgb_model.predict_proba(X_val)
    xgb_pred = xgb_model.predict_proba(X_val)
    cat_pred = cat_model.predict_proba(X_val)

    # Average predictions
    avg_pred = (lgb_pred + xgb_pred + cat_pred) / 3

    # Calculate CV score
    score = log_loss(y_val, avg_pred)
    cv_scores.append(score)
    print(f"Fold {fold + 1} CV Score: {score:.6f}")

print(f"\n5-Fold CV Scores: {cv_scores}")
print(f"Mean CV Score: {np.mean(cv_scores):.6f} (+/- {np.std(cv_scores) * 2:.6f})")

# Train final models on full data
lgb_model.fit(X_train_engineered, y_train_encoded)
xgb_model.fit(X_train_engineered, y_train_encoded)
cat_model.fit(X_train_engineered, y_train_encoded)

# Generate final predictions
lgb_pred_final = lgb_model.predict_proba(X_test_engineered)
xgb_pred_final = xgb_model.predict_proba(X_test_engineered)
cat_pred_final = cat_model.predict_proba(X_test_engineered)

# Ensemble predictions
final_predictions = (lgb_pred_final + xgb_pred_final + cat_pred_final) / 3

# Create submission file
submission_df = pd.DataFrame(final_predictions, columns=classes)
submission_df.insert(0, "id", test_df["id"])
submission_df.to_csv("submission.csv", index=False)

print("Submission file created successfully.")
