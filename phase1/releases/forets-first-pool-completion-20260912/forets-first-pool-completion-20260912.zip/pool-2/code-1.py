import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import log_loss
import lightgbm as lgb
import xgboost as xgb
from catboost import CatBoostClassifier
import optuna
from scipy.optimize import minimize
import warnings

warnings.filterwarnings("ignore")

# Load data
train_df = pd.read_csv("./data/train.csv")
test_df = pd.read_csv("./data/test.csv")

# Prepare features and target
feature_columns = [
    col for col in train_df.columns if col.startswith(("margin", "shape", "texture"))
]
X_train = train_df[feature_columns]
y_train = train_df["species"]
X_test = test_df[feature_columns]

# Encode labels
label_encoder = LabelEncoder()
y_train_encoded = label_encoder.fit_transform(y_train)
num_classes = len(label_encoder.classes_)


# Create interaction features
def create_interaction_features(X):
    # Create interaction features between different feature types
    X_copy = X.copy()

    # Extract feature groups
    margin_cols = [col for col in X.columns if col.startswith("margin")]
    shape_cols = [col for col in X.columns if col.startswith("shape")]
    texture_cols = [col for col in X.columns if col.startswith("texture")]

    # Create pairwise interactions
    interaction_features = []
    feature_names = []

    # Interaction between margin and shape
    for i, m_col in enumerate(margin_cols):
        for j, s_col in enumerate(shape_cols):
            new_feature_name = f"margin_{i}_shape_{j}"
            X_copy[new_feature_name] = X_copy[m_col] * X_copy[s_col]
            feature_names.append(new_feature_name)
            interaction_features.append(new_feature_name)

    # Interaction between margin and texture
    for i, m_col in enumerate(margin_cols):
        for j, t_col in enumerate(texture_cols):
            new_feature_name = f"margin_{i}_texture_{j}"
            X_copy[new_feature_name] = X_copy[m_col] * X_copy[t_col]
            feature_names.append(new_feature_name)
            interaction_features.append(new_feature_name)

    # Interaction between shape and texture
    for i, s_col in enumerate(shape_cols):
        for j, t_col in enumerate(texture_cols):
            new_feature_name = f"shape_{i}_texture_{j}"
            X_copy[new_feature_name] = X_copy[s_col] * X_copy[t_col]
            feature_names.append(new_feature_name)
            interaction_features.append(new_feature_name)

    return X_copy, interaction_features


# Apply feature engineering
X_train_engineered, interaction_features = create_interaction_features(X_train)
X_test_engineered, _ = create_interaction_features(X_test)

# Get final feature list
final_features = list(X_train_engineered.columns)


# Define evaluation function for CV
def evaluate_model(model, X, y, cv_folds=5):
    skf = StratifiedKFold(n_splits=cv_folds, shuffle=True, random_state=42)
    cv_scores = []

    for fold, (train_idx, val_idx) in enumerate(skf.split(X, y)):
        X_train_fold, X_val_fold = X.iloc[train_idx], X.iloc[val_idx]
        y_train_fold, y_val_fold = y.iloc[train_idx], y.iloc[val_idx]

        if hasattr(model, "fit"):
            model.fit(X_train_fold, y_train_fold)
            preds = model.predict_proba(X_val_fold)
        else:
            # For lightgbm/xgboost models that require specific handling
            if "lgb" in str(type(model)).lower():
                model.fit(
                    X_train_fold,
                    y_train_fold,
                    eval_set=[(X_val_fold, y_val_fold)],
                    eval_metric="multi_logloss",
                    callbacks=[lgb.early_stopping(stopping_rounds=50, verbose=False)],
                    verbose=False,
                )
                preds = model.predict(X_val_fold)
            elif "xgb" in str(type(model)).lower():
                model.fit(
                    X_train_fold,
                    y_train_fold,
                    eval_set=[(X_val_fold, y_val_fold)],
                    eval_metric="mlogloss",
                    callbacks=[xgb.callback.EarlyStopping(rounds=50, save_best=True)],
                    verbose_eval=False,
                )
                preds = model.predict(X_val_fold)
            else:
                model.fit(X_train_fold, y_train_fold)
                preds = model.predict_proba(X_val_fold)

        score = log_loss(y_val_fold, preds)
        cv_scores.append(score)

    return np.mean(cv_scores), np.std(cv_scores)


# Initialize models
lgb_params = {
    "objective": "multiclass",
    "num_class": num_classes,
    "metric": "multi_logloss",
    "boosting_type": "gbdt",
    "num_leaves": 31,
    "learning_rate": 0.05,
    "feature_fraction": 0.9,
    "bagging_fraction": 0.8,
    "bagging_freq": 5,
    "verbose": -1,
    "random_state": 42,
}

xgb_params = {
    "objective": "multiclass:softprob",
    "num_class": num_classes,
    "eval_metric": "mlogloss",
    "learning_rate": 0.05,
    "max_depth": 6,
    "subsample": 0.8,
    "colsample_bytree": 0.8,
    "random_state": 42,
}

cat_params = {
    "objective": "Multiclass",
    "iterations": 1000,
    "learning_rate": 0.05,
    "depth": 6,
    "l2_leaf_reg": 1,
    "random_seed": 42,
    "verbose": False,
}

# Perform 5-fold CV and get predictions
skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
cv_scores = []

# Store predictions for ensembling
oof_predictions = np.zeros((len(X_train_engineered), num_classes))
test_predictions = np.zeros((len(X_test_engineered), num_classes))

for fold, (train_idx, val_idx) in enumerate(
    skf.split(X_train_engineered, y_train_encoded)
):
    print(f"Processing fold {fold + 1}")

    X_train_fold, X_val_fold = (
        X_train_engineered.iloc[train_idx],
        X_train_engineered.iloc[val_idx],
    )
    y_train_fold, y_val_fold = y_train_encoded[train_idx], y_train_encoded[val_idx]

    # LightGBM
    lgb_model = lgb.LGBMClassifier(**lgb_params)
    lgb_model.fit(
        X_train_fold,
        y_train_fold,
        eval_set=[(X_val_fold, y_val_fold)],
        eval_metric="multi_logloss",
        callbacks=[lgb.early_stopping(stopping_rounds=50, verbose=False)],
        verbose=False,
    )

    # XGBoost
    xgb_model = xgb.XGBClassifier(**xgb_params)
    xgb_model.fit(
        X_train_fold,
        y_train_fold,
        eval_set=[(X_val_fold, y_val_fold)],
        eval_metric="mlogloss",
        callbacks=[xgb.callback.EarlyStopping(rounds=50, save_best=True)],
        verbose=False,
    )

    # CatBoost
    cat_model = CatBoostClassifier(**cat_params)
    cat_model.fit(
        X_train_fold, y_train_fold, eval_set=[(X_val_fold, y_val_fold)], verbose=False
    )

    # Get predictions
    lgb_pred = lgb_model.predict_proba(X_val_fold)
    xgb_pred = xgb_model.predict_proba(X_val_fold)
    cat_pred = cat_model.predict_proba(X_val_fold)

    # Average predictions
    avg_pred = (lgb_pred + xgb_pred + cat_pred) / 3

    # Store OOF predictions
    oof_predictions[val_idx] = avg_pred

    # Evaluate fold
    score = log_loss(y_val_fold, avg_pred)
    cv_scores.append(score)
    print(f"Fold {fold + 1} CV Score: {score:.6f}")

    # Add test predictions
    lgb_test_pred = lgb_model.predict_proba(X_test_engineered)
    xgb_test_pred = xgb_model.predict_proba(X_test_engineered)
    cat_test_pred = cat_model.predict_proba(X_test_engineered)
    test_predictions += (lgb_test_pred + xgb_test_pred + cat_test_pred) / 3

# Final evaluation
mean_cv_score = np.mean(cv_scores)
std_cv_score = np.std(cv_scores)
print(f"\n5-Fold Cross Validation Scores:")
for i, score in enumerate(cv_scores):
    print(f"Fold {i+1}: {score:.6f}")
print(f"\nMean CV Score: {mean_cv_score:.6f} (+/- {std_cv_score*2:.6f})")

# Normalize test predictions
test_predictions /= 5

# Create submission file
submission_df = pd.DataFrame({"id": test_df["id"]})
for i, class_name in enumerate(label_encoder.classes_):
    submission_df[class_name] = test_predictions[:, i]

# Save submission file
submission_df.to_csv("submission.csv", index=False)
print("\nSubmission file created successfully!")
print(f"Final 5-Fold CV Score: {mean_cv_score:.6f}")
