import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
from scipy.special import softmax
import warnings

warnings.filterwarnings("ignore")

# Load data
train_df = pd.read_csv("./data/train.csv")
test_df = pd.read_csv("./data/test.csv")

# Prepare data
feature_cols = [
    col for col in train_df.columns if col.startswith(("margin", "shape", "texture"))
]
target_col = "species"

# Encode target
label_encoder = LabelEncoder()
train_df["target"] = label_encoder.fit_transform(train_df[target_col])

# Separate features and target
X_train = train_df[feature_cols].values
y_train = train_df["target"].values
X_test = test_df[feature_cols].values

# Get unique species for submission
species_names = label_encoder.classes_

# Cross-validation setup
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
oof_predictions = np.zeros((len(train_df), len(species_names)))
test_predictions = np.zeros((len(test_df), len(species_names)))

# Define models
models = []

# Model 1: All features
params1 = {
    "objective": "multiclass",
    "num_class": len(species_names),
    "metric": "multi_logloss",
    "boosting_type": "gbdt",
    "num_leaves": 31,
    "learning_rate": 0.05,
    "feature_fraction": 0.9,
    "bagging_fraction": 0.8,
    "bagging_freq": 5,
    "verbose": -1,
    "random_state": 42,
}

# Model 2: Only shape features
params2 = {
    "objective": "multiclass",
    "num_class": len(species_names),
    "metric": "multi_logloss",
    "boosting_type": "gbdt",
    "num_leaves": 63,
    "learning_rate": 0.03,
    "feature_fraction": 0.8,
    "bagging_fraction": 0.7,
    "bagging_freq": 3,
    "verbose": -1,
    "random_state": 42,
}

# Model 3: Only texture features
params3 = {
    "objective": "multiclass",
    "num_class": len(species_names),
    "metric": "multi_logloss",
    "boosting_type": "gbdt",
    "num_leaves": 15,
    "learning_rate": 0.07,
    "feature_fraction": 0.95,
    "bagging_fraction": 0.9,
    "bagging_freq": 10,
    "verbose": -1,
    "random_state": 42,
}

# Training and prediction loop
for fold, (train_idx, val_idx) in enumerate(cv.split(X_train, y_train)):
    print(f"Training fold {fold + 1}")

    # Split data
    X_tr, X_val = X_train[train_idx], X_train[val_idx]
    y_tr, y_val = y_train[train_idx], y_train[val_idx]

    # Model 1: All features
    train_data1 = lgb.Dataset(X_tr, label=y_tr)
    val_data1 = lgb.Dataset(X_val, label=y_val, reference=train_data1)

    model1 = lgb.train(
        params1,
        train_data1,
        valid_sets=[val_data1],
        num_boost_round=1000,
        callbacks=[
            lgb.early_stopping(stopping_rounds=50, verbose=False),
            lgb.log_evaluation(period=0),
        ],
    )

    # Model 2: Shape features only
    shape_features = [f for f in feature_cols if f.startswith("shape")]
    shape_indices = [feature_cols.index(f) for f in shape_features]
    X_tr_shape = X_tr[:, shape_indices]
    X_val_shape = X_val[:, shape_indices]

    train_data2 = lgb.Dataset(X_tr_shape, label=y_tr)
    val_data2 = lgb.Dataset(X_val_shape, label=y_val, reference=train_data2)

    model2 = lgb.train(
        params2,
        train_data2,
        valid_sets=[val_data2],
        num_boost_round=1000,
        callbacks=[
            lgb.early_stopping(stopping_rounds=50, verbose=False),
            lgb.log_evaluation(period=0),
        ],
    )

    # Model 3: Texture features only
    texture_features = [f for f in feature_cols if f.startswith("texture")]
    texture_indices = [feature_cols.index(f) for f in texture_features]
    X_tr_texture = X_tr[:, texture_indices]
    X_val_texture = X_val[:, texture_indices]

    train_data3 = lgb.Dataset(X_tr_texture, label=y_tr)
    val_data3 = lgb.Dataset(X_val_texture, label=y_val, reference=train_data3)

    model3 = lgb.train(
        params3,
        train_data3,
        valid_sets=[val_data3],
        num_boost_round=1000,
        callbacks=[
            lgb.early_stopping(stopping_rounds=50, verbose=False),
            lgb.log_evaluation(period=0),
        ],
    )

    # Store models
    models.extend([model1, model2, model3])

    # Predictions for validation
    pred1 = model1.predict(X_val)
    pred2 = model2.predict(X_val_shape)
    pred3 = model3.predict(X_val_texture)

    # Average predictions
    avg_pred = (pred1 + pred2 + pred3) / 3
    oof_predictions[val_idx] = avg_pred

    # Predictions for test
    test_pred1 = model1.predict(X_test)
    test_pred2 = model2.predict(X_test[:, shape_indices])
    test_pred3 = model3.predict(X_test[:, texture_indices])

    test_pred_avg = (test_pred1 + test_pred2 + test_pred3) / 3
    test_predictions += test_pred_avg / 5

# Calculate CV score
from sklearn.metrics import log_loss

cv_score = log_loss(y_train, oof_predictions)
print(f"5-Fold CV Score: {cv_score}")

# Create submission
submission = pd.DataFrame({"id": test_df["id"]})

# Add probability columns for each species
for i, species in enumerate(species_names):
    submission[species] = test_predictions[:, i]

# Save submission
submission.to_csv("submission.csv", index=False)
print("Submission saved successfully")
