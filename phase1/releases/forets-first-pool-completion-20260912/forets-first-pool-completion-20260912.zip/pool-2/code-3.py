import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import log_loss
import lightgbm as lgb
import xgboost as xgb
from catboost import CatBoostClassifier
import warnings

warnings.filterwarnings("ignore")

# Load data
train_df = pd.read_csv("./data/train.csv")
test_df = pd.read_csv("./data/test.csv")

# Prepare features and target
feature_cols = [
    col for col in train_df.columns if col.startswith(("margin", "shape", "texture"))
]
X_train = train_df[feature_cols]
y_train = train_df["species"]
X_test = test_df[feature_cols]

# Encode labels
label_encoder = LabelEncoder()
y_train_encoded = label_encoder.fit_transform(y_train)

# Get unique species for submission
species_list = label_encoder.classes_


# Create additional features
def create_features(X):
    # Create interaction features
    X_new = X.copy()

    # Extract individual feature groups
    margin_cols = [col for col in X.columns if col.startswith("margin")]
    shape_cols = [col for col in X.columns if col.startswith("shape")]
    texture_cols = [col for col in X.columns if col.startswith("texture")]

    # Create ratios and differences between feature groups
    for i in range(min(len(margin_cols), len(shape_cols))):
        X_new[f"margin_shape_ratio_{i}"] = X_new[margin_cols[i]] / (
            X_new[shape_cols[i]] + 1e-8
        )
        X_new[f"margin_shape_diff_{i}"] = X_new[margin_cols[i]] - X_new[shape_cols[i]]

    for i in range(min(len(shape_cols), len(texture_cols))):
        X_new[f"shape_texture_ratio_{i}"] = X_new[shape_cols[i]] / (
            X_new[texture_cols[i]] + 1e-8
        )
        X_new[f"shape_texture_diff_{i}"] = X_new[shape_cols[i]] - X_new[texture_cols[i]]

    # Create sums of feature groups
    X_new["margin_sum"] = X_new[margin_cols].sum(axis=1)
    X_new["shape_sum"] = X_new[shape_cols].sum(axis=1)
    X_new["texture_sum"] = X_new[texture_cols].sum(axis=1)

    # Create means of feature groups
    X_new["margin_mean"] = X_new[margin_cols].mean(axis=1)
    X_new["shape_mean"] = X_new[shape_cols].mean(axis=1)
    X_new["texture_mean"] = X_new[texture_cols].mean(axis=1)

    # Create standard deviations
    X_new["margin_std"] = X_new[margin_cols].std(axis=1)
    X_new["shape_std"] = X_new[shape_cols].std(axis=1)
    X_new["texture_std"] = X_new[texture_cols].std(axis=1)

    return X_new


# Apply feature engineering
X_train_engineered = create_features(X_train)
X_test_engineered = create_features(X_test)

# Prepare for cross-validation
skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

# Initialize models
lgb_models = []
xgb_models = []
cat_models = []

# Store predictions for ensemble
oof_predictions = np.zeros((len(X_train_engineered), len(species_list)))
test_predictions = []

# Cross-validation loop
cv_scores = []

for fold, (train_idx, val_idx) in enumerate(
    skf.split(X_train_engineered, y_train_encoded)
):
    print(f"Training fold {fold + 1}")

    X_tr, X_val = X_train_engineered.iloc[train_idx], X_train_engineered.iloc[val_idx]
    y_tr, y_val = y_train_encoded[train_idx], y_train_encoded[val_idx]

    # LightGBM model
    lgb_train = lgb.Dataset(X_tr, label=y_tr)
    lgb_val = lgb.Dataset(X_val, label=y_val, reference=lgb_train)

    lgb_params = {
        "objective": "multiclass",
        "num_class": len(species_list),
        "metric": "multi_logloss",
        "boosting_type": "gbdt",
        "num_leaves": 31,
        "learning_rate": 0.05,
        "feature_fraction": 0.9,
        "bagging_fraction": 0.8,
        "bagging_freq": 5,
        "verbose": -1,
        "random_state": 42 + fold,
    }

    lgb_model = lgb.train(
        lgb_params,
        lgb_train,
        valid_sets=[lgb_train, lgb_val],
        valid_names=["train", "valid"],
        num_boost_round=1000,
        callbacks=[
            lgb.early_stopping(stopping_rounds=50, verbose=False),
            lgb.log_evaluation(period=0),
        ],
    )

    # XGBoost model
    xgb_train = xgb.DMatrix(X_tr, label=y_tr)
    xgb_val = xgb.DMatrix(X_val, label=y_val)

    xgb_params = {
        "objective": "multi:softprob",
        "num_class": len(species_list),
        "eval_metric": "mlogloss",
        "learning_rate": 0.05,
        "max_depth": 6,
        "subsample": 0.8,
        "colsample_bytree": 0.8,
        "random_state": 42 + fold,
    }

    xgb_model = xgb.train(
        xgb_params,
        xgb_train,
        num_boost_round=1000,
        evals=[(xgb_train, "train"), (xgb_val, "val")],
        early_stopping_rounds=50,
        verbose_eval=False,
    )

    # CatBoost model
    cat_model = CatBoostClassifier(
        iterations=1000,
        learning_rate=0.05,
        depth=6,
        l2_leaf_reg=3,
        bagging_temperature=0.2,
        random_seed=42 + fold,
        verbose=False,
        loss_function="MultiClass",
    )

    cat_model.fit(X_tr, y_tr, eval_set=(X_val, y_val), early_stopping_rounds=50)

    # Store models
    lgb_models.append(lgb_model)
    xgb_models.append(xgb_model)
    cat_models.append(cat_model)

    # Predictions
    lgb_pred = lgb_model.predict(X_val)
    xgb_pred = xgb_model.predict(xgb_val)
    cat_pred = cat_model.predict_proba(X_val)

    # Ensemble predictions (simple average)
    ensemble_pred = (lgb_pred + xgb_pred + cat_pred) / 3

    # Store out-of-fold predictions
    oof_predictions[val_idx] = ensemble_pred

    # Calculate CV score
    cv_score = log_loss(y_val, ensemble_pred)
    cv_scores.append(cv_score)
    print(f"Fold {fold + 1} CV Score: {cv_score:.5f}")

    # Test predictions
    lgb_test_pred = lgb_model.predict(X_test_engineered)
    xgb_test_pred = xgb_model.predict(xgb.DMatrix(X_test_engineered))
    cat_test_pred = cat_model.predict_proba(X_test_engineered)

    test_pred = (lgb_test_pred + xgb_test_pred + cat_test_pred) / 3
    test_predictions.append(test_pred)

# Print CV scores
print("\nCross-validation scores:")
for i, score in enumerate(cv_scores):
    print(f"Fold {i+1}: {score:.5f}")

mean_cv_score = np.mean(cv_scores)
std_cv_score = np.std(cv_scores)
print(f"\nMean CV Score: {mean_cv_score:.5f} (+/- {std_cv_score * 2:.5f})")

# Final ensemble prediction for test set
final_test_pred = np.mean(test_predictions, axis=0)

# Create submission file
submission_df = pd.DataFrame({"id": test_df["id"]})
for i, species in enumerate(species_list):
    submission_df[species] = final_test_pred[:, i]

# Save submission
submission_df.to_csv("submission.csv", index=False)
print("\nSubmission file saved as 'submission.csv'")
