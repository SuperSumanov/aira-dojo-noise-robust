import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score
import lightgbm as lgb
import xgboost as xgb
from catboost import CatBoostClassifier
import warnings

warnings.filterwarnings("ignore")

# Load data
train_df = pd.read_csv("./data/train.csv")
test_df = pd.read_csv("./data/test.csv")

# Create combined dataset for consistent preprocessing
combined_df = pd.concat(
    [train_df.drop("Transported", axis=1), test_df], axis=0, ignore_index=True
)

# Feature Engineering
# Extract group information from PassengerId
combined_df["Group"] = (
    combined_df["PassengerId"].str.extract(r"(\d+)_\d+")[0].astype(int)
)
combined_df["GroupSize"] = combined_df.groupby("Group")["Group"].transform("count")

# Extract cabin information
combined_df["CabinDeck"] = combined_df["Cabin"].str.split("/").str[0]
combined_df["CabinNum"] = combined_df["Cabin"].str.split("/").str[1].astype(float)
combined_df["CabinSide"] = combined_df["Cabin"].str.split("/").str[2]

# Create spending features
spending_cols = ["RoomService", "FoodCourt", "ShoppingMall", "Spa", "VRDeck"]
combined_df["TotalSpending"] = combined_df[spending_cols].sum(axis=1)
combined_df["HasSpent"] = (combined_df[spending_cols] > 0).any(axis=1).astype(int)

# Calculate spending ratios
for col in spending_cols:
    combined_df[f"{col}_Ratio"] = combined_df[col] / (
        combined_df["TotalSpending"] + 1e-8
    )

# Fill missing values
for col in ["Age", "RoomService", "FoodCourt", "ShoppingMall", "Spa", "VRDeck"]:
    if col in combined_df.columns:
        combined_df[col].fillna(0, inplace=True)

# Handle categorical variables
categorical_cols = [
    "HomePlanet",
    "CryoSleep",
    "Destination",
    "VIP",
    "CabinDeck",
    "CabinSide",
]
for col in categorical_cols:
    if col in combined_df.columns:
        # Fill missing values for categoricals
        combined_df[col].fillna("Unknown", inplace=True)

# Target encoding for categorical variables
target_col = "Transported"
for col in ["HomePlanet", "Destination", "CabinDeck", "CabinSide"]:
    if col in combined_df.columns:
        # Create target mean encoding
        target_mean = train_df.groupby(col)[target_col].mean()
        combined_df[f"{col}_encoded"] = (
            combined_df[col].map(target_mean).fillna(train_df[target_col].mean())
        )

# Prepare final datasets
train_features = combined_df.iloc[: len(train_df)].copy()
test_features = combined_df.iloc[len(train_df) :].copy()

# Select features for modeling
feature_cols = [
    "Age",
    "GroupSize",
    "HasSpent",
    "TotalSpending",
    "RoomService_Ratio",
    "FoodCourt_Ratio",
    "ShoppingMall_Ratio",
    "Spa_Ratio",
    "VRDeck_Ratio",
    "HomePlanet_encoded",
    "Destination_encoded",
    "CabinDeck_encoded",
    "CabinSide_encoded",
]

# Encode categorical variables for final models
le_dict = {}
for col in ["HomePlanet", "Destination", "CabinDeck", "CabinSide"]:
    if col in train_features.columns:
        le = LabelEncoder()
        train_features[col] = le.fit_transform(train_features[col].astype(str))
        test_features[col] = le.transform(test_features[col].astype(str))
        le_dict[col] = le

# Convert to numeric
train_features = train_features[feature_cols].fillna(0)
test_features = test_features[feature_cols].fillna(0)

# Prepare target variable
y_train = train_df["Transported"]

# Cross-validation setup
skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
cv_scores = []

# Model predictions storage
lgb_pred_train = np.zeros(len(train_df))
xgb_pred_train = np.zeros(len(train_df))
cat_pred_train = np.zeros(len(train_df))
lgb_pred_test = np.zeros(len(test_df))
xgb_pred_test = np.zeros(len(test_df))
cat_pred_test = np.zeros(len(test_df))

# Train models
for fold, (train_idx, val_idx) in enumerate(skf.split(train_features, y_train)):
    print(f"Training fold {fold+1}")

    X_train_fold, X_val_fold = (
        train_features.iloc[train_idx],
        train_features.iloc[val_idx],
    )
    y_train_fold, y_val_fold = y_train.iloc[train_idx], y_train.iloc[val_idx]

    # LightGBM
    lgb_train = lgb.Dataset(X_train_fold, label=y_train_fold)
    lgb_val = lgb.Dataset(X_val_fold, label=y_val_fold, reference=lgb_train)

    lgb_params = {
        "objective": "binary",
        "metric": "binary_logloss",
        "boosting_type": "gbdt",
        "num_leaves": 31,
        "learning_rate": 0.05,
        "feature_fraction": 0.9,
        "bagging_fraction": 0.8,
        "bagging_freq": 5,
        "verbose": -1,
        "random_state": 42 + fold,
    }

    lgb_model = lgb.train(
        lgb_params,
        lgb_train,
        valid_sets=[lgb_train, lgb_val],
        num_boost_round=1000,
        callbacks=[
            lgb.early_stopping(stopping_rounds=50, verbose=False),
            lgb.log_evaluation(period=0),
        ],
    )

    # XGBoost
    xgb_train = xgb.DMatrix(X_train_fold, label=y_train_fold)
    xgb_val = xgb.DMatrix(X_val_fold, label=y_val_fold)

    xgb_params = {
        "objective": "binary:logistic",
        "eval_metric": "logloss",
        "max_depth": 6,
        "learning_rate": 0.05,
        "subsample": 0.8,
        "colsample_bytree": 0.8,
        "random_state": 42 + fold,
    }

    xgb_model = xgb.train(
        xgb_params,
        xgb_train,
        num_boost_round=1000,
        evals=[(xgb_train, "train"), (xgb_val, "val")],
        early_stopping_rounds=50,
        verbose_eval=False,
    )

    # CatBoost
    cat_model = CatBoostClassifier(
        iterations=1000,
        learning_rate=0.05,
        depth=6,
        l2_leaf_reg=3,
        bootstrap_type="Bayesian",
        random_seed=42 + fold,
        silent=True,
    )

    cat_model.fit(
        X_train_fold,
        y_train_fold,
        eval_set=(X_val_fold, y_val_fold),
        early_stopping_rounds=50,
        verbose=False,
    )

    # Predictions
    lgb_pred_train[val_idx] = lgb_model.predict(X_val_fold)
    xgb_pred_train[val_idx] = xgb_model.predict(xgb_val)
    cat_pred_train[val_idx] = cat_model.predict_proba(X_val_fold)[:, 1]

    # Test predictions (averaged across folds)
    lgb_pred_test += lgb_model.predict(test_features) / 5
    xgb_pred_test += xgb_model.predict(xgb.DMatrix(test_features)) / 5
    cat_pred_test += cat_model.predict_proba(test_features)[:, 1] / 5

    # Calculate fold score
    pred_binary = (
        lgb_pred_train[val_idx] + xgb_pred_train[val_idx] + cat_pred_train[val_idx]
    ) / 3 > 0.5
    score = accuracy_score(y_val_fold, pred_binary)
    cv_scores.append(score)
    print(f"Fold {fold+1} CV Score: {score:.5f}")

print(f"\n5-Fold CV Scores: {cv_scores}")
print(f"Mean CV Score: {np.mean(cv_scores):.5f} (+/- {np.std(cv_scores) * 2:.5f})")

# Final prediction using ensemble
final_pred = (lgb_pred_test + xgb_pred_test + cat_pred_test) / 3 > 0.5

# Create submission
submission = pd.DataFrame(
    {"PassengerId": test_df["PassengerId"], "Transported": final_pred}
)

submission.to_csv("submission.csv", index=False)
print("\nSubmission file created successfully!")
