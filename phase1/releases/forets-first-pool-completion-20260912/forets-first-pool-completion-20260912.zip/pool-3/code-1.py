import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score
import lightgbm as lgb
import xgboost as xgb
from catboost import CatBoostClassifier
from sklearn.feature_selection import SelectFromModel
import warnings

warnings.filterwarnings("ignore")

# Load data
train_df = pd.read_csv("./data/train.csv")
test_df = pd.read_csv("./data/test.csv")


# Feature engineering function
def create_features(df):
    # Extract cabin info
    df["Cabin_deck"] = df["Cabin"].str.split("/").str[0]
    df["Cabin_side"] = df["Cabin"].str.split("/").str[2]

    # Group features
    df["Group"] = df["PassengerId"].str.split("_").str[0]
    df["Group_size"] = df.groupby("Group")["PassengerId"].transform("count")

    # Age groups
    df["Age_group"] = pd.cut(
        df["Age"],
        bins=[0, 12, 18, 35, 60, 100],
        labels=["Child", "Teen", "Adult", "Middle", "Senior"],
    )

    # Spending features
    df["Total_spending"] = df[
        ["RoomService", "FoodCourt", "ShoppingMall", "Spa", "VRDeck"]
    ].sum(axis=1)
    df["Spending_ratio"] = df["Total_spending"] / (
        df["Age"] + 1
    )  # Avoid division by zero

    # VIP and CryoSleep interaction
    df["VIP_CryoSleep"] = df["VIP"].astype(str) + "_" + df["CryoSleep"].astype(str)

    # Family/Group features
    df["Is_alone"] = (df["Group_size"] == 1).astype(int)

    # Cabin side impact
    df["Cabin_side_impact"] = (df["Cabin_side"] == "S").astype(int)

    return df


# Apply feature engineering
train_df = create_features(train_df)
test_df = create_features(test_df)


# Handle missing values
def handle_missing_values(df):
    # Fill numeric columns with median
    numeric_cols = ["Age", "RoomService", "FoodCourt", "ShoppingMall", "Spa", "VRDeck"]
    for col in numeric_cols:
        df[col] = df[col].fillna(df[col].median())

    # Fill categorical columns with mode
    categorical_cols = [
        "HomePlanet",
        "Destination",
        "Cabin_deck",
        "Cabin_side",
        "Age_group",
        "VIP_CryoSleep",
    ]
    for col in categorical_cols:
        if col in df.columns:
            df[col] = df[col].fillna(
                df[col].mode()[0] if not df[col].mode().empty else "Unknown"
            )

    # Fill CryoSleep with False (as it's likely to be the majority class)
    df["CryoSleep"] = df["CryoSleep"].fillna(False)

    return df


train_df = handle_missing_values(train_df)
test_df = handle_missing_values(test_df)


# Target encoding for categorical variables
def target_encode(df_train, df_test, cols_to_encode, target_col="Transported"):
    for col in cols_to_encode:
        if col in df_train.columns:
            # Calculate target mean for each category
            target_mean = df_train.groupby(col)[target_col].mean()

            # Apply to both train and test
            df_train[col + "_encoded"] = df_train[col].map(target_mean)
            df_test[col + "_encoded"] = df_test[col].map(target_mean)

            # Handle unseen categories
            df_test[col + "_encoded"] = df_test[col + "_encoded"].fillna(
                target_mean.mean()
            )

    return df_train, df_test


# Apply target encoding
cols_to_encode = [
    "HomePlanet",
    "Destination",
    "Cabin_deck",
    "Cabin_side",
    "Age_group",
    "VIP_CryoSleep",
]
train_df, test_df = target_encode(train_df, test_df, cols_to_encode)

# Prepare features
feature_cols = [
    "Age",
    "RoomService",
    "FoodCourt",
    "ShoppingMall",
    "Spa",
    "VRDeck",
    "Group_size",
    "Total_spending",
    "Spending_ratio",
    "Is_alone",
    "Cabin_side_impact",
    "HomePlanet_encoded",
    "Destination_encoded",
    "Cabin_deck_encoded",
    "Cabin_side_encoded",
    "Age_group_encoded",
    "VIP_CryoSleep_encoded",
]

# Convert categorical columns to numeric
le = LabelEncoder()
for col in ["CryoSleep", "VIP"]:
    if col in train_df.columns:
        train_df[col] = le.fit_transform(train_df[col].astype(str))
        test_df[col] = le.transform(test_df[col].astype(str))

# Prepare data
X_train = train_df[feature_cols]
y_train = train_df["Transported"]

# Initialize models
lgb_model = lgb.LGBMClassifier(
    n_estimators=1000,
    learning_rate=0.05,
    num_leaves=31,
    max_depth=-1,
    random_state=42,
    verbosity=-1,
)

xgb_model = xgb.XGBClassifier(
    n_estimators=1000, learning_rate=0.05, max_depth=6, random_state=42, verbosity=0
)

cat_model = CatBoostClassifier(
    iterations=1000, learning_rate=0.05, depth=6, random_seed=42, verbose=False
)

# 5-Fold Cross Validation
skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
cv_scores = []

for fold, (train_idx, val_idx) in enumerate(skf.split(X_train, y_train)):
    X_tr, X_val = X_train.iloc[train_idx], X_train.iloc[val_idx]
    y_tr, y_val = y_train.iloc[train_idx], y_train.iloc[val_idx]

    # Fit models
    lgb_model.fit(X_tr, y_tr)
    xgb_model.fit(X_tr, y_tr)
    cat_model.fit(X_tr, y_tr, silent=True)

    # Get predictions
    lgb_pred = lgb_model.predict(X_val)
    xgb_pred = xgb_model.predict(X_val)
    cat_pred = cat_model.predict(X_val)

    # Ensemble predictions (majority voting)
    ensemble_pred = (lgb_pred + xgb_pred + cat_pred) >= 2

    # Calculate accuracy
    acc = accuracy_score(y_val, ensemble_pred)
    cv_scores.append(acc)
    print(f"Fold {fold+1}: Accuracy = {acc:.5f}")

print(
    f"\n5-Fold CV Mean Accuracy: {np.mean(cv_scores):.5f} (+/- {np.std(cv_scores) * 2:.5f})"
)

# Final model training and prediction
lgb_model.fit(X_train, y_train)
xgb_model.fit(X_train, y_train)
cat_model.fit(X_train, y_train, silent=True)

# Predict on test set
lgb_pred = lgb_model.predict(test_df[feature_cols])
xgb_pred = xgb_model.predict(test_df[feature_cols])
cat_pred = cat_model.predict(test_df[feature_cols])

# Ensemble final predictions
final_pred = (lgb_pred + xgb_pred + cat_pred) >= 2

# Create submission
submission = pd.DataFrame(
    {"PassengerId": test_df["PassengerId"], "Transported": final_pred}
)

submission.to_csv("submission.csv", index=False)
print("Submission file saved successfully!")
