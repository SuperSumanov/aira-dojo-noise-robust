import pandas as pd
import numpy as np
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score
import lightgbm as lgb
import xgboost as xgb
from catboost import CatBoostClassifier
import warnings

warnings.filterwarnings("ignore")

# Load data
train_df = pd.read_csv("./data/train.csv")
test_df = pd.read_csv("./data/test.csv")


# Feature engineering function
def create_features(df):
    df = df.copy()

    # Extract group information from PassengerId
    df["Group"] = df["PassengerId"].str.split("_").str[0].astype(int)
    df["GroupSize"] = df.groupby("Group")["PassengerId"].transform("count")

    # Extract cabin information
    df[["CabinDeck", "CabinNum", "CabinSide"]] = df["Cabin"].str.split("/", expand=True)

    # Create spending features
    spending_cols = ["RoomService", "FoodCourt", "ShoppingMall", "Spa", "VRDeck"]
    df["TotalSpending"] = df[spending_cols].sum(axis=1)
    df["HasSpent"] = (df["TotalSpending"] > 0).astype(int)

    # Age groups
    df["AgeGroup"] = pd.cut(
        df["Age"],
        bins=[0, 12, 18, 35, 60, 100],
        labels=["Child", "Teen", "Adult", "Middle", "Senior"],
    )

    # Family size from group info
    df["FamilySize"] = df.groupby("Group")["PassengerId"].transform("count")

    # VIP + CryoSleep combinations
    df["VIP_Cryo"] = (
        df["VIP"].fillna(False).astype(str)
        + "_"
        + df["CryoSleep"].fillna(False).astype(str)
    )

    return df


# Apply feature engineering
train_processed = create_features(train_df)
test_processed = create_features(test_df)

# Select features for modeling
feature_cols = [
    "HomePlanet",
    "CryoSleep",
    "Destination",
    "Age",
    "VIP",
    "CabinDeck",
    "CabinSide",
    "GroupSize",
    "TotalSpending",
    "HasSpent",
    "AgeGroup",
    "FamilySize",
    "VIP_Cryo",
]

# Handle missing values
train_processed[feature_cols] = train_processed[feature_cols].fillna("Missing")
test_processed[feature_cols] = test_processed[feature_cols].fillna("Missing")

# Encode categorical variables
label_encoders = {}
for col in [
    "HomePlanet",
    "Destination",
    "CabinDeck",
    "CabinSide",
    "AgeGroup",
    "VIP_Cryo",
]:
    if col in train_processed.columns:
        le = LabelEncoder()
        train_processed[col + "_encoded"] = le.fit_transform(
            train_processed[col].astype(str)
        )
        test_processed[col + "_encoded"] = le.transform(test_processed[col].astype(str))
        label_encoders[col] = le

# Prepare features for modeling
feature_cols_encoded = [
    col + "_encoded"
    for col in [
        "HomePlanet",
        "Destination",
        "CabinDeck",
        "CabinSide",
        "AgeGroup",
        "VIP_Cryo",
    ]
]
feature_cols_final = [
    "CryoSleep",
    "Age",
    "GroupSize",
    "TotalSpending",
    "HasSpent",
    "FamilySize",
] + feature_cols_encoded

X_train = train_processed[feature_cols_final]
y_train = train_processed["Transported"]

# Convert to appropriate types
X_train = X_train.astype("float32")
y_train = y_train.astype("int")

# Initialize cross-validation
skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
cv_scores = []

# Model predictions storage
oof_predictions = np.zeros(len(X_train))
test_predictions = np.zeros(len(test_processed))

# Models to ensemble
models = {
    "lgb": {
        "model": lgb.LGBMClassifier(
            n_estimators=1000,
            learning_rate=0.05,
            num_leaves=31,
            max_depth=-1,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=42,
            verbosity=-1,
        ),
        "params": {},
    },
    "xgb": {
        "model": xgb.XGBClassifier(
            n_estimators=1000,
            learning_rate=0.05,
            max_depth=6,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=42,
        ),
        "params": {},
    },
    "cat": {
        "model": CatBoostClassifier(
            iterations=1000,
            learning_rate=0.05,
            depth=6,
            l2_leaf_reg=3,
            random_strength=0.5,
            bagging_temperature=0.5,
            eval_metric="Accuracy",
            random_seed=42,
            verbose=False,
        ),
        "params": {},
    },
}

# Training and evaluation loop
for fold, (train_idx, val_idx) in enumerate(skf.split(X_train, y_train)):
    print(f"Training fold {fold+1}")

    X_tr, X_val = X_train.iloc[train_idx], X_train.iloc[val_idx]
    y_tr, y_val = y_train.iloc[train_idx], y_train.iloc[val_idx]

    fold_predictions = np.zeros(len(X_val))

    # Train and predict with each model
    for model_name, model_info in models.items():
        model = model_info["model"]

        if model_name == "lgb":
            model.fit(
                X_tr,
                y_tr,
                eval_set=[(X_val, y_val)],
                callbacks=[
                    lgb.early_stopping(stopping_rounds=50, verbose=False),
                    lgb.log_evaluation(period=0),
                ],
            )
        elif model_name == "xgb":
            model.fit(
                X_tr,
                y_tr,
                eval_set=[(X_val, y_val)],
                early_stopping_rounds=50,
                verbose=False,
            )
        else:  # catboost
            model.fit(X_tr, y_tr, eval_set=[(X_val, y_val)], verbose=False)

        # Predict and store
        pred = model.predict_proba(X_val)[:, 1]
        fold_predictions += pred / len(models)

    # Store OOF predictions
    oof_predictions[val_idx] = fold_predictions

    # Calculate fold score
    fold_score = accuracy_score(y_val, (fold_predictions > 0.5).astype(int))
    cv_scores.append(fold_score)
    print(f"Fold {fold+1} CV Score: {fold_score:.5f}")

# Print CV scores
print(f"\n5-Fold Cross Validation Scores: {cv_scores}")
print(f"Mean CV Score: {np.mean(cv_scores):.5f} (+/- {np.std(cv_scores) * 2:.5f})")

# Final training and prediction
final_predictions = np.zeros(len(test_processed))

for model_name, model_info in models.items():
    model = model_info["model"]

    if model_name == "lgb":
        model.fit(
            X_train,
            y_train,
            callbacks=[
                lgb.early_stopping(stopping_rounds=50, verbose=False),
                lgb.log_evaluation(period=0),
            ],
        )
    elif model_name == "xgb":
        model.fit(X_train, y_train, early_stopping_rounds=50, verbose=False)
    else:  # catboost
        model.fit(X_train, y_train, verbose=False)

    # Predict test set
    test_pred = model.predict_proba(test_processed[feature_cols_final])[:, 1]
    final_predictions += test_pred / len(models)

# Save submission
submission = pd.DataFrame(
    {
        "PassengerId": test_df["PassengerId"],
        "Transported": (final_predictions > 0.5).astype(bool),
    }
)

submission.to_csv("submission.csv", index=False)
print("Submission file saved as 'submission.csv'")
