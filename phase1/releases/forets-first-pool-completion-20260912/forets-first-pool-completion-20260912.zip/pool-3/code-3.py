import pandas as pd
import numpy as np
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score
import lightgbm as lgb
import xgboost as xgb
from catboost import CatBoostClassifier
from sklearn.feature_selection import SelectFromModel
from sklearn.linear_model import LogisticRegression
import warnings

warnings.filterwarnings("ignore")

# Load data
train_df = pd.read_csv("./data/train.csv")
test_df = pd.read_csv("./data/test.csv")


# Feature engineering function
def feature_engineering(df):
    df = df.copy()

    # Extract cabin features
    df["Cabin_deck"] = df["Cabin"].str.split("/").str[0]
    df["Cabin_num"] = df["Cabin"].str.split("/").str[1].astype(float)
    df["Cabin_side"] = df["Cabin"].str.split("/").str[2]

    # Group size and group ID features
    df["GroupID"] = df["PassengerId"].str.split("_").str[0]
    df["GroupSize"] = df.groupby("GroupID")["PassengerId"].transform("count")

    # Age groups
    df["AgeGroup"] = pd.cut(
        df["Age"],
        bins=[0, 12, 18, 35, 60, 100],
        labels=["Child", "Teen", "Adult", "Middle", "Senior"],
    )

    # Total spending
    spending_cols = ["RoomService", "FoodCourt", "ShoppingMall", "Spa", "VRDeck"]
    df["TotalSpending"] = df[spending_cols].sum(axis=1)

    # Spending ratios
    df["SpendingRatio"] = df["TotalSpending"] / (
        df["Age"] + 1
    )  # Avoid division by zero

    # VIP and CryoSleep combinations
    df["VIP_CryoSleep"] = df["VIP"].astype(str) + "_" + df["CryoSleep"].astype(str)

    # Family size (based on Name)
    df["FamilySize"] = df["Name"].str.split().str.len() - 1  # Approximate family size

    return df


# Apply feature engineering
train_processed = feature_engineering(train_df)
test_processed = feature_engineering(test_df)


# Handle missing values
def handle_missing_values(df):
    df = df.copy()

    # Fill numerical columns with median
    numerical_cols = [
        "Age",
        "RoomService",
        "FoodCourt",
        "ShoppingMall",
        "Spa",
        "VRDeck",
        "Cabin_num",
        "FamilySize",
    ]
    for col in numerical_cols:
        if col in df.columns:
            df[col] = df[col].fillna(df[col].median())

    # Fill categorical columns with mode
    categorical_cols = [
        "HomePlanet",
        "Destination",
        "Cabin_deck",
        "Cabin_side",
        "AgeGroup",
        "VIP_CryoSleep",
    ]
    for col in categorical_cols:
        if col in df.columns:
            df[col] = df[col].fillna(
                df[col].mode()[0] if not df[col].mode().empty else "Unknown"
            )

    # Fill CryoSleep with False (as it's a binary variable)
    df["CryoSleep"] = df["CryoSleep"].fillna(False)

    return df


train_processed = handle_missing_values(train_processed)
test_processed = handle_missing_values(test_processed)


# Encode categorical variables
def encode_categorical(df):
    df = df.copy()
    le_dict = {}

    categorical_cols = [
        "HomePlanet",
        "Destination",
        "Cabin_deck",
        "Cabin_side",
        "AgeGroup",
        "VIP_CryoSleep",
    ]

    for col in categorical_cols:
        if col in df.columns:
            le = LabelEncoder()
            df[col] = le.fit_transform(df[col].astype(str))
            le_dict[col] = le

    return df, le_dict


train_encoded, label_encoders = encode_categorical(train_processed)
test_encoded, _ = encode_categorical(test_processed)

# Prepare features and target
feature_cols = [
    col
    for col in train_encoded.columns
    if col not in ["PassengerId", "Name", "Cabin", "Transported"]
]
X = train_encoded[feature_cols]
y = train_encoded["Transported"]


# Target encoding for selected categorical features
def target_encode(X_train, X_test, y, cols_to_encode):
    X_train_encoded = X_train.copy()
    X_test_encoded = X_test.copy()

    for col in cols_to_encode:
        if col in X_train_encoded.columns:
            # Calculate mean target for each category
            target_mean = X_train_encoded.groupby(col)["Transported"].mean()

            # Apply to both train and test
            X_train_encoded[f"{col}_target_encoded"] = X_train_encoded[col].map(
                target_mean
            )
            X_test_encoded[f"{col}_target_encoded"] = X_test_encoded[col].map(
                target_mean
            )

            # Fill NaN with overall mean
            overall_mean = y.mean()
            X_train_encoded[f"{col}_target_encoded"] = X_train_encoded[
                f"{col}_target_encoded"
            ].fillna(overall_mean)
            X_test_encoded[f"{col}_target_encoded"] = X_test_encoded[
                f"{col}_target_encoded"
            ].fillna(overall_mean)

            # Drop original column
            X_train_encoded = X_train_encoded.drop(columns=[col])
            X_test_encoded = X_test_encoded.drop(columns=[col])

    return X_train_encoded, X_test_encoded


# Apply target encoding to categorical columns
cols_to_encode = ["HomePlanet", "Destination", "Cabin_deck", "Cabin_side", "AgeGroup"]
X_train_target, X_test_target = target_encode(
    X, test_encoded[feature_cols], y, cols_to_encode
)

# Remove original categorical columns that were target encoded
final_features = [
    col for col in X_train_target.columns if not col.endswith("_target_encoded")
]

# Perform 5-fold cross-validation
skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
cv_scores = []

models = {
    "lgb": lgb.LGBMClassifier(
        n_estimators=1000,
        learning_rate=0.05,
        num_leaves=31,
        max_depth=-1,
        random_state=42,
        verbosity=-1,
    ),
    "xgb": xgb.XGBClassifier(
        n_estimators=1000, learning_rate=0.05, max_depth=6, random_state=42, verbosity=0
    ),
    "cat": CatBoostClassifier(
        iterations=1000, learning_rate=0.05, depth=6, random_seed=42, verbose=False
    ),
}

predictions_list = []
oof_predictions = np.zeros(len(X))

for fold, (train_idx, val_idx) in enumerate(skf.split(X, y)):
    print(f"Training fold {fold + 1}")

    X_train_fold, X_val_fold = (
        X_train_target.iloc[train_idx],
        X_train_target.iloc[val_idx],
    )
    y_train_fold, y_val_fold = y.iloc[train_idx], y.iloc[val_idx]

    # Train models
    model_predictions = {}

    for name, model in models.items():
        if name == "cat":
            model.fit(
                X_train_fold,
                y_train_fold,
                eval_set=(X_val_fold, y_val_fold),
                early_stopping_rounds=50,
                verbose=False,
            )
        else:
            model.fit(
                X_train_fold,
                y_train_fold,
                eval_set=[(X_val_fold, y_val_fold)],
                callbacks=[lgb.early_stopping(stopping_rounds=50, verbose=False)],
                verbose=False,
            )

        pred = model.predict_proba(X_val_fold)[:, 1]
        model_predictions[name] = pred

        # Store out-of-fold predictions for stacking
        oof_predictions[val_idx] += pred / len(models)

    # Stack predictions for this fold
    stacked_pred = np.mean(list(model_predictions.values()), axis=0)
    score = accuracy_score(y_val_fold, (stacked_pred > 0.5).astype(int))
    cv_scores.append(score)
    print(f"Fold {fold + 1} Accuracy: {score:.5f}")

    # Store predictions for test set
    test_predictions = {}
    for name, model in models.items():
        if name == "cat":
            test_pred = model.predict_proba(X_test_target)[:, 1]
        else:
            test_pred = model.predict_proba(X_test_target)[:, 1]
        test_predictions[name] = test_pred

    # Average test predictions
    avg_test_pred = np.mean(list(test_predictions.values()), axis=0)
    predictions_list.append(avg_test_pred)

print(f"\n5-Fold Cross Validation Scores: {cv_scores}")
print(f"Mean CV Score: {np.mean(cv_scores):.5f} (+/- {np.std(cv_scores) * 2:.5f})")

# Final prediction using averaged test predictions
final_test_predictions = np.mean(predictions_list, axis=0)
submission = pd.DataFrame(
    {
        "PassengerId": test_df["PassengerId"],
        "Transported": (final_test_predictions > 0.5).astype(bool),
    }
)

submission.to_csv("submission.csv", index=False)
print("Submission file saved as 'submission.csv'")
