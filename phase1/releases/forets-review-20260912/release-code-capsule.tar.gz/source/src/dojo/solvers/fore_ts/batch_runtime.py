"""ForeTS batch integration, pre-execution recovery only; no result labels here.

Intended for an isolated upstream patch, NOT the active producer. Operator-internal
retries/cost traces, rendered prompt isolation and full search recovery remain open.
"""
import asyncio
import copy
from dojo.solvers.fore_ts.execution_witness import ExecutionWitness
from dojo.core.tasks.constants import EXECUTION_OUTPUT
from dojo.solvers.fore_ts.request_guard import BatchRequestGuard
from dojo.solvers.fore_ts.selection import POLICIES, choose_slots
from pathlib import Path

from dojo.solvers.fore_ts.candidate_ledger import CandidateLedger, LedgerError, digest


def assert_candidate_unchanged(ledger, slot, node):
    record = {k: getattr(node, k) for k in
              ("id", "ctime", "code", "plan", "operators_used", "operators_metrics")}
    if (digest(record) != digest(ledger.data["candidates"][slot]["node"]) or
            node.parents or node.children or node.metric is not None or node.is_buggy is not None):
        raise LedgerError("candidate changed after generation freeze")


def expand_batch(solver, path, state, task, node_type, extract_code, config_snapshot):
    count = min(solver.cfg.num_children, solver.remaining_steps)
    if count <= 0:
        return state
    if type(solver.cfg.selector_seed) is not int:
        raise LedgerError('explicit independent selector seed required')
    policy = solver.cfg.selection_policy
    if policy not in POLICIES:
        raise LedgerError("explicit selection policy required before generation")
    coupling = getattr(solver.cfg, 'selection_coupling', 'independent_subset_v2')
    if coupling not in ('independent_subset_v2', 'common_priority_v1'):
        raise LedgerError('unsupported selection coupling before generation')
    skip_redundant = getattr(solver.cfg, 'skip_redundant_critic', False)
    if type(skip_redundant) is not bool:
        raise LedgerError('skip_redundant_critic must be boolean')
    bypass = (skip_redundant and policy == 'critic_topk_random'
              and count <= solver.critic_top_k)
    parent = path[-1]
    # Bind the actual in-memory boundary, not merely its step or parent identity.
    boundary = dict(
        task=solver.task_name, task_description=solver.task_desc,
        config=config_snapshot, state=vars(solver.state), preview=solver.data_preview,
        journal=solver.journal.node_list(), path=[n.id for n in path],
        tree=[dict(id=n.id, parents=[p.id for p in n.parents],
                   children=sorted(c.id for c in n.children),
                   explore_count=n.explore_count, node_value=n.node_value)
              for n in solver.journal.nodes],
        global_q=[solver.global_min_q_val, solver.global_max_q_val],
    )
    binding = dict(schema=4, selection_policy=policy, execution_contract="task-return-receipt-v1", request_contract="same-rendered-request-v1", boundary_sha256=digest(boundary), parent_id=parent.id,
                   task=solver.task_name, step=solver.state.current_step)
    binding.update(selection_coupling=coupling)
    if bypass:
        binding.update(score_bypass='full_pool_no_pruning', critic_top_k=solver.critic_top_k)
    root = Path(solver.cfg.checkpoint_path)
    root.mkdir(parents=True, exist_ok=True)
    file = root / 'forets-candidates-private' / f'batch-{solver.state.current_step}.sqlite'
    with CandidateLedger(file, binding, count) as ledger:
        ledger.ensure_preexecution()  # Check EVERY slot before any possible paid call.

        guard = BatchRequestGuard(ledger, count * solver.cfg.max_llm_call_retries)

        witness = ExecutionWitness(ledger, task, solver.remaining_steps,
                                   solver.cfg.execution_timeout, EXECUTION_OUTPUT)

        async def obtain(slot):
            c = ledger.data['candidates'][slot]
            if c['state'] == 'pending':
                ledger.begin_generation(slot)
                with guard.slot(slot):
                    node = await (solver._draft(parent) if not parent.parents else solver._improve(parent))
                if node.parents or node.children or node.metric is not None or node.is_buggy is not None:
                    raise LedgerError('generated candidate attached or labeled before execution')
                ledger.generated(slot, {k: getattr(node, k) for k in
                    ('id', 'ctime', 'code', 'plan', 'operators_used', 'operators_metrics')})
            else:
                # Analysis appends operator records; it must not edit the pre-execution ledger.
                node = node_type(**copy.deepcopy(c['node']), parents=[])
            return node

        async def gather():
            results = await asyncio.gather(*(obtain(i) for i in range(count)), return_exceptions=True)
            # Preserve completed siblings; never select from a partial pool.
            for result in results:
                if isinstance(result, BaseException):
                    raise result
            return results

        nodes = asyncio.run(gather())
        for slot, node in enumerate(nodes):
            assert_candidate_unchanged(ledger, slot, node)
        ledger.freeze_pool()  # All generation finishes before ANY critic request.
        if policy == 'critic_topk_random' and not bypass:
            async def score_all():
                for slot, node in enumerate(nodes):
                    if ledger.data['candidates'][slot]['state'] == 'generated':
                        assert_candidate_unchanged(ledger, slot, node)
                        ledger.begin_score(slot)
                        score = await solver._query_critic(node)
                        assert_candidate_unchanged(ledger, slot, node)
                        ledger.scored(slot, score)
            asyncio.run(score_all())
        if ledger.data['selected'] is None:
            scores = ([c['score'] for c in ledger.data['candidates']]
                      if policy == 'critic_topk_random' and not bypass else None)
            # choose_slots canonicalizes full top-k into original slot order.
            # This uses exactly the same RNG identity and selected slot(s),
            # without inventing scores or treating missing predictions as zero.
            effective_policy = 'uniform_random' if bypass else policy
            ledger.select(choose_slots(count, solver.critic_top_k, solver.num_children_to_choose,
                          effective_policy, solver.cfg.selector_seed, solver.task_name,
                          solver.state.current_step, scores, coupling=coupling))

        # Upstream's unselected journal is an export-only view. It must never
        # enter executed memory/UCT, the selection pool, or task execution.
        exported = {node.id: node for node in solver.journal_for_unselected.nodes}
        if len(exported) != len(solver.journal_for_unselected.nodes):
            raise LedgerError('duplicate unselected export identities')
        for slot, node in enumerate(nodes):
            if slot not in ledger.data['selected']:
                if node.id in exported:
                    # A known pre-execution retry must not duplicate its export.
                    assert_candidate_unchanged(ledger, slot, exported[node.id])
                else:
                    solver.journal_for_unselected.append(node)
                    exported[node.id] = node

        for slot in ledger.data['selected']:
            if solver.remaining_steps <= 0:
                break
            child = nodes[slot]
            assert_candidate_unchanged(ledger, slot, child)
            ledger.begin_execution(slot)  # Durable intent BEFORE external effects.
            state, eval_result = witness.task_for(slot, "candidate").step_task(state, extract_code(child.code))
            solver.parse_eval_result(node=child, eval_result=eval_result)
            # Only executed and parsed nodes enter memory/UCT. Never synthesize a score.
            child.parents = [parent]
            parent.children.add(child)
            solver.journal.append(child)
            solver.log_journal()
            solver.state.current_step += 1
            if not child.is_buggy:
                solver._backprop_step(path=path + [child], value_estimate=child.metric.value)
                solver.set_global_q_values(child.metric.value)
            else:
                state, debug_path, fixed_metric = solver.debug_cycle(state, witness.task_for(slot, "debug"), child)
                if fixed_metric is not None:
                    solver._backprop_step(path=path + debug_path, value_estimate=fixed_metric)
                    solver.set_global_q_values(fixed_metric)
            ledger.execution_completed(slot)
        ledger.finish()
    return state
