"""Compatibility import; new supervisors use dojo.utils.run_budget directly.

Importing the llm_helpers package initializes the LLM stack. Keep budget-only
bootstrap outside that package so its deadline does not depend on ML imports.
"""
from dojo.utils.run_budget import RunBudgetError, initialize, reserve, main

__all__ = ['RunBudgetError', 'initialize', 'reserve']


if __name__ == '__main__':
    main()
