"""One bounded exploratory worker inside a Slurm step; no automatic replay.

Slurm --time/allocation limits are still required. SIGKILL or a node failure can
prevent budget archival; the persistent exclusive claim then remains ambiguous.
Never reconstruct a fresh allowance from a missing node-local database.
"""
import argparse
from contextlib import closing
import hashlib
import json
import os
from pathlib import Path
import re
import sqlite3
import sys
import tempfile

from dojo.core.runners.slurm.bounded_process import run_bounded
from dojo.utils.run_budget import initialize


def _write_new(path, value):
    with os.fdopen(os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600), 'w') as file:
        json.dump(value, file, sort_keys=True, indent=2)
        file.write('\n')
        file.flush()
        os.fsync(file.fileno())


def run_worker(args, *, worker_command=None):
    allocation, step = os.environ.get('SLURM_JOB_ID', ''), os.environ.get('SLURM_STEP_ID', '')
    if not re.fullmatch(r'[0-9]+', allocation) or not re.fullmatch(r'[0-9]+', step):
        raise RuntimeError('bounded worker requires a numeric Slurm allocation and step')
    if args.attempt != 1:
        raise RuntimeError('bounded exploration does not automatically replay runs')
    for value in (args.wall_seconds, args.max_api_attempts, args.max_output_tokens):
        if type(value) is not int or value <= 0:
            raise ValueError('positive integer bounds required')
    if os.environ.get('FORETS_RUN_BUDGET_PATH'):
        raise RuntimeError('refusing inherited budget from another run')
    identity = args.identity.resolve()
    config = args.config.resolve(strict=True)
    config_bytes = config.read_bytes()
    if json.loads(config_bytes).get('logger', {}).get('write_env_vars') is not False:
        raise RuntimeError('bounded worker requires explicit disabled environment export')
    # Persistent marker is created before any dispatch. An interrupted attempt
    # cannot be retried by silently creating another node-local budget.
    claim = identity.with_suffix('.bounded')
    claim.mkdir(mode=0o700, parents=False, exist_ok=False)
    local = Path(tempfile.mkdtemp(prefix='forets-worker-', dir='/tmp'))
    budget = local / 'attempts.sqlite'
    initialize(budget, args.max_api_attempts, args.max_output_tokens)
    _write_new(claim/'started.json', dict(allocation_id=allocation, step_id=step,
        run_id_sha256=hashlib.sha256(args.run_id.encode()).hexdigest(),
        config_sha256=hashlib.sha256(config_bytes).hexdigest(),
        local_budget=str(budget), wall_seconds=args.wall_seconds,
        max_api_attempts=args.max_api_attempts, max_output_tokens=args.max_output_tokens,
        api_cost_cap_usd=None, automated_resume_allowed=False))
    command = worker_command or [sys.executable, '-m', 'dojo.main_srun_worker', str(config),
        str(identity), '--run-id', args.run_id, '--attempt', str(args.attempt)]
    environment = os.environ.copy()
    environment['FORETS_RUN_BUDGET_PATH'] = str(budget)
    summary = run_bounded(command, cwd=Path.cwd(), output_dir=claim/'execution',
        wall_seconds=args.wall_seconds, grace_seconds=2., environment=environment)
    receipt = dict(worker_status=summary['status'], budget_archived=False,
                   api_cost_usd=None, reserved_adapter_attempts=None)
    try:
        archive = claim/'attempts.sqlite'
        fd = os.open(archive, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        os.close(fd)
        with closing(sqlite3.connect(budget.as_uri() + '?mode=ro', uri=True, timeout=5)) as source:
            with closing(sqlite3.connect(archive, timeout=5)) as target:
                source.backup(target)
            receipt['reserved_adapter_attempts'] = source.execute('SELECT COUNT(*) FROM attempts').fetchone()[0]
        receipt['budget_archived'] = True
    except Exception as exc:
        receipt['archive_error_type'] = type(exc).__name__
    _write_new(claim/'finished.json', receipt)
    # Keep node-local evidence. It is small and not an automatic-resume source.
    return 0 if summary['status'] == 'completed' and receipt['budget_archived'] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('config', type=Path)
    parser.add_argument('identity', type=Path)
    parser.add_argument('--run-id', required=True)
    parser.add_argument('--attempt', required=True, type=int)
    parser.add_argument('--wall-seconds', required=True, type=int)
    parser.add_argument('--max-api-attempts', required=True, type=int)
    parser.add_argument('--max-output-tokens', required=True, type=int)
    raise SystemExit(run_worker(parser.parse_args()))


if __name__ == '__main__':
    main()
