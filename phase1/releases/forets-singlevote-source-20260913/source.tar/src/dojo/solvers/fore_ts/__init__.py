# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.

__all__ = ["ForeTS"]


def __getattr__(name):
    # GenericLLM imports request_guard; eagerly loading the solver here creates
    # GenericLLM -> ForeTS -> MCTS -> analyze_op -> GenericLLM cycles.
    if name == "ForeTS":
        from .fore_ts import ForeTS
        return ForeTS
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
