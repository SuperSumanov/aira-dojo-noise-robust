"""Common batch selector; pure function, no model calls or result-label reads."""
import hashlib
import json
import math
import random

POLICIES = ('uniform_random', 'critic_topk_random')


def choose_slots(count, top_k, choose, policy, seed, task, step, scores=None, *,
                 coupling='independent_subset_v2'):
    if coupling not in ('independent_subset_v2', 'common_priority_v1'):
        raise ValueError('unsupported selection coupling')
    if policy not in POLICIES:
        raise ValueError('explicit supported selection policy required')
    if any(type(v) is not int or v <= 0 for v in (count, top_k, choose)) or choose > top_k:
        raise ValueError('invalid candidate/top-k/choose contract')
    if type(seed) is not int or type(step) is not int or step < 0 or not isinstance(task, str) or not task:
        raise ValueError('invalid independent selector identity')
    if policy == 'uniform_random':
        if scores is not None:
            raise ValueError('random baseline must not receive critic scores')
        eligible = list(range(count))
    else:
        if (not isinstance(scores, (list, tuple)) or len(scores) != count or
                any(type(s) not in (int, float) or not math.isfinite(s) for s in scores)):
            raise ValueError('complete finite score vector required')
        # Keep all ties at the cutoff; common priority randomizes ties fairly.
        # This is the frozen new selector protocol, not a change to old runs.
        ranked = sorted(range(count), key=lambda i: scores[i], reverse=True)
        threshold = scores[ranked[min(top_k, count)-1]]
        eligible = [i for i in range(count) if scores[i] >= threshold]
    if coupling == 'common_priority_v1':
        # Shuffle the whole pool before the score-based eligibility filter.
        # The stream is shared across arms and matches the tested prototype.
        identity = dict(version='forets-common-priority-v1', seed=seed,
                        task=task, step=step, purpose='selection_order')
        key = hashlib.sha256(json.dumps(identity, sort_keys=True,
                                       separators=(',', ':')).encode()).hexdigest()
        order = list(range(count))
        random.Random(key).shuffle(order)
        return [slot for slot in order if slot in eligible][:min(choose, len(eligible))]
    identity = dict(domain='forets-selector-v2', seed=seed, task=task, step=step)
    key = hashlib.sha256(json.dumps(identity, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    return random.Random(key).sample(eligible, min(choose, len(eligible)))
