import numpy as np
import pandas as pd
import lightgbm as lgb
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import log_loss
import warnings

warnings.filterwarnings("ignore")

# ============================================================
# 1. Load Data
# ============================================================
train_df = pd.read_csv("./data/train.csv")
test_df = pd.read_csv("./data/test.csv")
sample_sub = pd.read_csv("./data/sample_submission.csv")

print(f"Train shape: {train_df.shape}")
print(f"Test shape: {test_df.shape}")
print(f"Sample submission shape: {sample_sub.shape}")

# ============================================================
# 2. Prepare Features and Target
# ============================================================
# Identify feature columns (exclude id and species)
feature_cols = [c for c in train_df.columns if c not in ["id", "species"]]
print(f"Number of features: {len(feature_cols)}")

# Separate feature groups
margin_cols = [c for c in feature_cols if c.startswith("margin")]
shape_cols = [c for c in feature_cols if c.startswith("shape")]
texture_cols = [c for c in feature_cols if c.startswith("texture")]
print(
    f"Margin: {len(margin_cols)}, Shape: {len(shape_cols)}, Texture: {len(texture_cols)}"
)

X_train = train_df[feature_cols].copy()
X_test = test_df[feature_cols].copy()

# Encode target
le = LabelEncoder()
y_train = le.fit_transform(train_df["species"])
num_classes = len(le.classes_)
print(f"Number of classes: {num_classes}")


# ============================================================
# 3. Feature Engineering: Statistical Aggregations per Group
# ============================================================
def add_stat_features(df, prefix, cols):
    df[f"{prefix}_mean"] = df[cols].mean(axis=1)
    df[f"{prefix}_std"] = df[cols].std(axis=1)
    df[f"{prefix}_min"] = df[cols].min(axis=1)
    df[f"{prefix}_max"] = df[cols].max(axis=1)
    df[f"{prefix}_median"] = df[cols].median(axis=1)
    df[f"{prefix}_skew"] = df[cols].skew(axis=1)
    df[f"{prefix}_kurt"] = df[cols].kurtosis(axis=1)
    return df


for prefix, cols in [
    ("margin", margin_cols),
    ("shape", shape_cols),
    ("texture", texture_cols),
]:
    X_train = add_stat_features(X_train, prefix, cols)
    X_test = add_stat_features(X_test, prefix, cols)

# Also add global stats
all_feature_cols = [c for c in X_train.columns if c not in ["id"]]
X_train = add_stat_features(X_train, "global", all_feature_cols)
X_test = add_stat_features(X_test, "global", all_feature_cols)

print(f"Features after engineering: {X_train.shape[1]}")

# ============================================================
# 4. LightGBM Parameters (GPU accelerated)
# ============================================================
params = {
    "objective": "multiclass",
    "num_class": num_classes,
    "metric": "multi_logloss",
    "boosting_type": "gbdt",
    "device": "gpu",
    "gpu_platform_id": 0,
    "gpu_device_id": 0,
    "learning_rate": 0.03,
    "num_leaves": 127,
    "max_depth": -1,
    "min_child_samples": 20,
    "subsample": 0.8,
    "colsample_bytree": 0.8,
    "reg_alpha": 0.1,
    "reg_lambda": 0.1,
    "min_split_gain": 0.01,
    "verbose": -1,
    "seed": 42,
    "num_threads": 8,
}

# ============================================================
# 5. 5-Fold Cross-Validation
# ============================================================
n_folds = 5
skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=42)

oof_preds = np.zeros((len(X_train), num_classes))
test_preds = np.zeros((len(X_test), num_classes))
cv_scores = []

for fold, (train_idx, val_idx) in enumerate(skf.split(X_train, y_train)):
    print(f"\n=== Fold {fold + 1}/{n_folds} ===")

    X_tr, X_val = X_train.iloc[train_idx], X_train.iloc[val_idx]
    y_tr, y_val = y_train[train_idx], y_train[val_idx]

    # Create LightGBM datasets
    train_data = lgb.Dataset(X_tr, label=y_tr)
    val_data = lgb.Dataset(X_val, label=y_val, reference=train_data)

    # Train with early stopping
    model = lgb.train(
        params,
        train_data,
        num_boost_round=2000,
        valid_sets=[train_data, val_data],
        valid_names=["train", "valid"],
        callbacks=[
            lgb.early_stopping(stopping_rounds=100, verbose=True),
            lgb.log_evaluation(period=100),
        ],
    )

    # Predict
    val_pred = model.predict(X_val, num_iteration=model.best_iteration)
    test_pred = model.predict(X_test, num_iteration=model.best_iteration)

    oof_preds[val_idx] = val_pred
    test_preds += test_pred / n_folds

    # Compute fold log loss
    fold_score = log_loss(y_val, val_pred, labels=list(range(num_classes)))
    cv_scores.append(fold_score)
    print(f"Fold {fold + 1} Log Loss: {fold_score:.6f}")

# ============================================================
# 6. Overall CV Score
# ============================================================
overall_cv = log_loss(y_train, oof_preds, labels=list(range(num_classes)))
print(f"\n{'='*50}")
print(f"Mean CV Log Loss: {np.mean(cv_scores):.6f} (+/- {np.std(cv_scores):.6f})")
print(f"Overall OOF Log Loss: {overall_cv:.6f}")
print(f"{'='*50}")

# ============================================================
# 7. Prepare Submission
# ============================================================
# Clip probabilities to avoid log(0) issues
eps = 1e-15
test_preds_clipped = np.clip(test_preds, eps, 1 - eps)

# Renormalize rows to sum to 1
test_preds_clipped = test_preds_clipped / test_preds_clipped.sum(axis=1, keepdims=True)

# Create submission dataframe
submission = pd.DataFrame(test_preds_clipped, columns=le.classes_)
submission.insert(0, "id", test_df["id"].values)

# Ensure column order matches sample submission
submission = submission[sample_sub.columns]

# Save
submission.to_csv("submission.csv", index=False)
print(f"\nSubmission saved to submission.csv")
print(f"Submission shape: {submission.shape}")
print(f"First few rows:")
print(submission.head())
