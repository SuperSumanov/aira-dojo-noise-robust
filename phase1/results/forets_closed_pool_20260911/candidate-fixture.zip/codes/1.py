import numpy as np
import pandas as pd
import lightgbm as lgb
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import log_loss
import warnings

warnings.filterwarnings("ignore")

# Load data
train_df = pd.read_csv("./data/train.csv")
test_df = pd.read_csv("./data/test.csv")
sample_sub = pd.read_csv("./data/sample_submission.csv")

# Prepare features and target
feature_cols = [c for c in train_df.columns if c not in ["id", "species"]]
X = train_df[feature_cols].values
y = train_df["species"].values
X_test = test_df[feature_cols].values

# Encode labels
le = LabelEncoder()
y_enc = le.fit_transform(y)
n_classes = len(le.classes_)

# LightGBM parameters
params = {
    "objective": "multiclass",
    "num_class": n_classes,
    "metric": "multi_logloss",
    "boosting_type": "gbdt",
    "num_leaves": 63,
    "max_depth": 7,
    "learning_rate": 0.05,
    "feature_fraction": 0.8,
    "bagging_fraction": 0.8,
    "bagging_freq": 5,
    "min_child_samples": 10,
    "min_child_weight": 1e-3,
    "reg_alpha": 0.1,
    "reg_lambda": 0.1,
    "verbosity": -1,
    "num_threads": 4,
    "seed": 42,
}

# 5-fold CV
skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
cv_scores = []
test_preds = np.zeros((X_test.shape[0], n_classes))

for fold, (train_idx, val_idx) in enumerate(skf.split(X, y_enc)):
    X_train, X_val = X[train_idx], X[val_idx]
    y_train, y_val = y_enc[train_idx], y_enc[val_idx]

    train_data = lgb.Dataset(X_train, label=y_train)
    val_data = lgb.Dataset(X_val, label=y_val, reference=train_data)

    model = lgb.train(
        params,
        train_data,
        num_boost_round=2000,
        valid_sets=[val_data],
        callbacks=[
            lgb.early_stopping(stopping_rounds=100),
            lgb.log_evaluation(period=0),
        ],
    )

    val_pred = model.predict(X_val, num_iteration=model.best_iteration)
    fold_score = log_loss(y_val, val_pred, labels=list(range(n_classes)))
    cv_scores.append(fold_score)
    print(f"Fold {fold+1} LogLoss: {fold_score:.6f}")

    test_preds += model.predict(X_test, num_iteration=model.best_iteration) / 5

print(f"\nMean CV LogLoss: {np.mean(cv_scores):.6f} (+/- {np.std(cv_scores):.6f})")

# Clip predictions to avoid logloss extremes
test_preds = np.clip(test_preds, 1e-15, 1 - 1e-15)
# Renormalize rows to sum to 1
test_preds = test_preds / test_preds.sum(axis=1, keepdims=True)

# Create submission
submission = pd.DataFrame(test_preds, columns=le.classes_)
submission.insert(0, "id", test_df["id"].values)
submission.to_csv("submission.csv", index=False)
print("Submission saved to submission.csv")
print(f"Shape: {submission.shape}")
