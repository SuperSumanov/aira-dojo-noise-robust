import numpy as np
import pandas as pd
import lightgbm as lgb
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import RobustScaler, LabelEncoder
from sklearn.metrics import log_loss
from sklearn.calibration import CalibratedClassifierCV
import warnings

warnings.filterwarnings("ignore")

# ============================================================
# 1. Load Data
# ============================================================
train_df = pd.read_csv("./data/train.csv")
test_df = pd.read_csv("./data/test.csv")
sample_sub = pd.read_csv("./data/sample_submission.csv")

# Extract IDs
train_ids = train_df["id"].values
test_ids = test_df["id"].values

# Target encoding
le = LabelEncoder()
y = le.fit_transform(train_df["species"].values)
n_classes = len(le.classes_)

# Feature columns (exclude id and species)
feature_cols = [c for c in train_df.columns if c not in ["id", "species"]]
X_train = train_df[feature_cols].values.astype(np.float32)
X_test = test_df[feature_cols].values.astype(np.float32)

print(f"Train shape: {X_train.shape}, Test shape: {X_test.shape}, Classes: {n_classes}")


# ============================================================
# 2. Feature Engineering
# ============================================================
def create_features(X):
    """Create additional features from the 3 feature groups."""
    n_samples = X.shape[0]
    # Feature groups: 0-63 margin, 64-127 shape, 128-191 texture
    margin = X[:, :64]
    shape = X[:, 64:128]
    texture = X[:, 128:]

    # Statistical features per group
    stats_list = []
    for grp in [margin, shape, texture]:
        stats_list.append(np.mean(grp, axis=1, keepdims=True))
        stats_list.append(np.std(grp, axis=1, keepdims=True))
        stats_list.append(np.max(grp, axis=1, keepdims=True))
        stats_list.append(np.min(grp, axis=1, keepdims=True))
        # Skewness and kurtosis approximations
        mean_ = np.mean(grp, axis=1, keepdims=True)
        std_ = np.std(grp, axis=1, keepdims=True) + 1e-8
        stats_list.append(np.mean(((grp - mean_) / std_) ** 3, axis=1, keepdims=True))
        stats_list.append(
            np.mean(((grp - mean_) / std_) ** 4, axis=1, keepdims=True) - 3
        )

    # Cross-group interactions (mean of products)
    stats_list.append(np.mean(margin * shape, axis=1, keepdims=True))
    stats_list.append(np.mean(margin * texture, axis=1, keepdims=True))
    stats_list.append(np.mean(shape * texture, axis=1, keepdims=True))

    # Concatenate all
    X_enhanced = np.hstack([X] + stats_list)
    return X_enhanced


print("Creating enhanced features...")
X_train_enh = create_features(X_train)
X_test_enh = create_features(X_test)
print(f"Enhanced train shape: {X_train_enh.shape}")

# Robust scaling
scaler = RobustScaler()
X_train_scaled = scaler.fit_transform(X_train_enh)
X_test_scaled = scaler.transform(X_test_enh)

# ============================================================
# 3. LightGBM Training with 5-Fold CV
# ============================================================
params = {
    "objective": "multiclassova",  # One-vs-all for better calibrated probabilities
    "num_class": n_classes,
    "metric": "multi_logloss",
    "boosting_type": "gbdt",
    "learning_rate": 0.02,
    "num_leaves": 63,
    "max_depth": 7,
    "min_child_samples": 5,
    "subsample": 0.8,
    "colsample_bytree": 0.8,
    "reg_alpha": 1.0,
    "reg_lambda": 2.0,
    "min_gain_to_split": 0.01,
    "verbose": -1,
    "seed": 42,
    "deterministic": True,
    "force_col_wise": True,
    "num_threads": 8,
}

n_folds = 5
skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=42)

oof_preds = np.zeros((len(X_train_scaled), n_classes))
test_preds = np.zeros((len(X_test_scaled), n_classes))
cv_scores = []

for fold, (trn_idx, val_idx) in enumerate(skf.split(X_train_scaled, y)):
    print(f"\n--- Fold {fold+1}/{n_folds} ---")

    X_trn, X_val = X_train_scaled[trn_idx], X_train_scaled[val_idx]
    y_trn, y_val = y[trn_idx], y[val_idx]

    # Create datasets
    train_data = lgb.Dataset(X_trn, label=y_trn)
    val_data = lgb.Dataset(X_val, label=y_val, reference=train_data)

    # Train with early stopping
    model = lgb.train(
        params,
        train_data,
        num_boost_round=2000,
        valid_sets=[val_data],
        callbacks=[
            lgb.early_stopping(stopping_rounds=100, verbose=False),
            lgb.log_evaluation(period=200),
        ],
    )

    # Predict
    val_pred = model.predict(X_val, num_iteration=model.best_iteration)
    test_pred = model.predict(X_test_scaled, num_iteration=model.best_iteration)

    oof_preds[val_idx] = val_pred
    test_preds += test_pred / n_folds

    # Fold score
    fold_score = log_loss(y_val, val_pred, labels=list(range(n_classes)))
    cv_scores.append(fold_score)
    print(f"Fold {fold+1} LogLoss: {fold_score:.6f}")

cv_mean = np.mean(cv_scores)
cv_std = np.std(cv_scores)
print(f"\n=== 5-Fold CV LogLoss: {cv_mean:.6f} ± {cv_std:.6f} ===")

# ============================================================
# 4. Temperature Scaling Calibration (on OOF predictions)
# ============================================================
# Simple temperature scaling: find T that minimizes log loss on OOF
from scipy.optimize import minimize_scalar


def temp_scale_loss(T, logits, targets):
    """Log loss after temperature scaling."""
    # Convert probs back to logits (approximate)
    probs = logits / T
    probs = np.exp(probs - np.max(probs, axis=1, keepdims=True))
    probs = probs / np.sum(probs, axis=1, keepdims=True)
    probs = np.clip(probs, 1e-15, 1 - 1e-15)
    return log_loss(targets, probs, labels=list(range(n_classes)))


# We need logits - approximate from probabilities
# For multiclassova, the raw scores are not directly available, so we use a simpler approach:
# Just calibrate using isotonic regression per class on OOF
from sklearn.isotonic import IsotonicRegression

print("Calibrating probabilities...")
oof_calibrated = np.zeros_like(oof_preds)
test_calibrated = np.zeros_like(test_preds)

for c in range(n_classes):
    ir = IsotonicRegression(out_of_bounds="clip")
    ir.fit(oof_preds[:, c], (y == c).astype(float))
    oof_calibrated[:, c] = ir.predict(oof_preds[:, c])
    test_calibrated[:, c] = ir.predict(test_preds[:, c])

# Renormalize
oof_calibrated = oof_calibrated / oof_calibrated.sum(axis=1, keepdims=True)
test_calibrated = test_calibrated / test_calibrated.sum(axis=1, keepdims=True)

# Clip
eps = 1e-15
oof_calibrated = np.clip(oof_calibrated, eps, 1 - eps)
test_calibrated = np.clip(test_calibrated, eps, 1 - eps)

cal_score = log_loss(y, oof_calibrated, labels=list(range(n_classes)))
print(f"Calibrated CV LogLoss: {cal_score:.6f}")

# ============================================================
# 5. Ensemble with Multiple Seeds (3 seeds)
# ============================================================
print("\n=== Training ensemble with 3 seeds ===")
seeds = [42, 123, 456]
all_test_preds = []

for seed in seeds:
    params["seed"] = seed
    fold_test_preds = np.zeros((len(X_test_scaled), n_classes))

    for fold, (trn_idx, val_idx) in enumerate(skf.split(X_train_scaled, y)):
        X_trn, X_val = X_train_scaled[trn_idx], X_train_scaled[val_idx]
        y_trn, y_val = y[trn_idx], y[val_idx]

        train_data = lgb.Dataset(X_trn, label=y_trn)
        val_data = lgb.Dataset(X_val, label=y_val, reference=train_data)

        model = lgb.train(
            params,
            train_data,
            num_boost_round=2000,
            valid_sets=[val_data],
            callbacks=[
                lgb.early_stopping(stopping_rounds=100, verbose=False),
                lgb.log_evaluation(period=0),
            ],
        )

        fold_test_preds += (
            model.predict(X_test_scaled, num_iteration=model.best_iteration) / n_folds
        )

    all_test_preds.append(fold_test_preds)

# Average ensemble
ensemble_test = np.mean(all_test_preds, axis=0)
ensemble_test = ensemble_test / ensemble_test.sum(axis=1, keepdims=True)
ensemble_test = np.clip(ensemble_test, eps, 1 - eps)

# ============================================================
# 6. Create Submission
# ============================================================
submission = pd.DataFrame(ensemble_test, columns=le.classes_)
submission.insert(0, "id", test_ids)
submission.to_csv("submission.csv", index=False)

print(f"\nSubmission saved to submission.csv")
print(f"Shape: {submission.shape}")
print(f"Columns: {list(submission.columns[:5])}...")
print(f"Row sums (should be ~1): {submission.iloc[0, 1:].sum():.6f}")
